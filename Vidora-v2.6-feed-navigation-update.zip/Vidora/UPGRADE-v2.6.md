# Vidora v2.6 — Feed and navigation update

## Included in this source update
- Home is the For You feed; feed can refresh with pull-down gesture.
- Bottom navigation replaces Watch with Shorts. First visit loads the Shorts feed; tapping Shorts again refreshes it.
- Shorts are sourced using Shorts/short-form search queries, displayed in a vertical swipe-style feed, and open in the existing full-screen player. Swipe up/down in the player moves between loaded Shorts.
- Home and Shorts refresh when the app returns to the foreground.
- Feed region defaults to IP geolocation and can be overridden in Settings.
- Video cards provide locally persisted like/dislike preference signals and creator follow controls when the source supplies a stable channel identifier.
- Channel page requests use a validated YouTube channel ID and fetch public uploads.
- Existing in-app mini-player is preserved; Android Back minimizes a loaded player even when paused.
- Version updated to 2.6 / versionCode 7.

## Honest limitations
- Likes/dislikes are local recommendation feedback only. They are not sent to a user's YouTube account; that requires Google OAuth and YouTube Data API authorization.
- Subscriptions are stored locally in Vidora, not synced with YouTube. They require a stable creator/channel ID from the source.
- yt-dlp flat search does not consistently expose portrait dimensions or a Shorts-only flag. Shorts search is biased toward short-form clips and filters known durations over 90 seconds, but cannot guarantee every result is vertical.
- The existing player mini mode is in-app. Android system PiP is not part of this specific feed/navigation patch.
- Device playback, network geolocation, and APK installation must be verified on a physical device.

## Build and signing
The private PKCS#12 file and hard-coded passwords have been removed. Debug builds use Android's standard debug key. This means the resulting APK will not update-install over an app signed with the removed private key. To preserve update compatibility, build using the owner's original keystore through secure Gradle properties or CI secrets; never commit it.
