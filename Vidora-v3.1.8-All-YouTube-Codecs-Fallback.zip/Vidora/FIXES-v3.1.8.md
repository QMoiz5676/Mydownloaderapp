# Vidora v3.1.8 – Broad YouTube codec support

- Removed codec-specific exclusions from direct video and combined audio/video stream selection.
- AVC/H.264 + AAC remains preferred when present, but VP9, AV1, HEVC and other available direct renditions are now fallback candidates instead of being filtered out.
- Preview fallback now asks yt-dlp for the best available combined HTTP rendition when the preferred AVC/AAC MP4 is absent.
- Version code/name advanced to 12 / 3.1.8.

Important limitation: this expands format coverage but cannot guarantee playback of every video on every Android device. The device's hardware/software decoders, protected/DRM playback, region/age restrictions, and YouTube's availability can still prevent playback. A universal guarantee requires a licensed playback path or a software transcoding pipeline; simply selecting every codec cannot make an unsupported decoder support it.
