# Vidora v3.1.7 – Android video compatibility

- Playback stream selection now prefers AVC/H.264 video with AAC audio in MP4, a broadly supported Android WebView combination.
- Separate video streams are restricted to AVC/H.264 MP4; unsupported AV1/HEVC/VP9 streams are no longer selected as the primary player source.
- Preview fallback now requests compatible AVC/H.264 + AAC MP4 instead of arbitrary MP4/HTTP formats.
- Version code/name advanced to 11 / 3.1.7.

Note: devices still cannot play a source if the provider exposes no compatible AVC/AAC stream. This app has no FFmpeg transcoder, so such a source requires server-side conversion or a compatible source rendition.
