# Vidora v3.1.6

- Mini-player shows the selected video thumbnail while a new stream buffers, with a loading indicator over it.
- Mini-player title is at the top; full-screen control is centered; previous/play-next controls are at the bottom.
- Mini-player chrome is hidden by default and toggles on tapping the mini-player surface.
- Replaced the generic download glyph with a Vidora-branded vector mark.
- Added launcher icon safe margins to prevent cropping in adaptive launchers and installer surfaces.

Android build and device verification are still required.
