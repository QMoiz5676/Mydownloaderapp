plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.mydl.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mydl.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 21
        versionName = "3.3.8"
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    // Debug builds use Android's standard local debug keystore.
    // Never commit or hard-code private signing keys or passwords.
    buildTypes {
        getByName("debug") {
            // Default Android debug signing is applied automatically.
        }
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

chaquopy {
    defaultConfig {
        version = "3.12"
        pip {
            install("flask")
            install("yt-dlp")
            install("requests")
        }
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.github.teamnewpipe:NewPipeExtractor:v0.27.1")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    // FFmpeg (community-maintained FFmpegKit fork): converts videos the phone cannot decode
    implementation("dev.ffmpegkit-maintained:ffmpeg-kit-free:6.0.4")
}
