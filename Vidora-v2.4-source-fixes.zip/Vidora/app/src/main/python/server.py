"""Vidora embedded backend (Flask + yt-dlp), runs inside the Android app via Chaquopy."""
import copy
import glob
import hashlib
import itertools
import json
import mimetypes
import os
import re
import threading
import time
import uuid
from urllib.parse import urlparse

import requests
import yt_dlp
from flask import Flask, Response, abort, jsonify, request, send_file

app = Flask(__name__)

ALLOWED_DOMAINS = (
    "youtube.com", "youtu.be", "facebook.com", "fb.watch", "fb.com",
    "instagram.com", "snapchat.com",
)
# Every category is a list of search phrases. Page N of a feed uses a different phrase / modifier,
# so scrolling never runs out and never repeats the same 20 videos.
FEEDS = {
    "trending": ["trending videos today", "viral videos this week", "most popular videos right now", "top videos"],
    "music": ["new music videos", "top songs", "latest songs official video", "music mix"],
    "movies": ["movie trailers", "new movie trailers", "best movie scenes", "short films"],
    "gaming": ["gaming highlights", "gameplay walkthrough", "new game trailers", "funny gaming moments"],
    "funny": ["funny videos", "comedy clips", "funny fails", "stand up comedy"],
    "news": ["latest news", "breaking news today", "news headlines", "world news"],
    "diy": ["diy craft projects", "diy home hacks", "woodworking projects", "easy crafts"],
}
CAT_WORD = {"trending": "", "music": "songs", "movies": "movies", "gaming": "gameplay",
            "funny": "funny", "news": "news", "diy": "diy"}
MODS = ["", "new", "best", "latest", "top", "popular", "full", "mix", "compilation", "this week"]
ID_RE = re.compile(r"^[a-f0-9]{12}$")
PAGE_SIZE = 12  # results asked per search phrase

INDEX_HTML = "<h1>Loading...</h1>"
LIB_DIR = "/tmp"
jobs = {}
info_cache = {}
preview_cache = {}
search_cache = {}


class Cancelled(Exception):
    pass


# YouTube player clients. None of these need a JavaScript runtime (Android has none).
# They are all tried in parallel and their formats are combined, because each one
# exposes a different set of qualities and YouTube changes which ones work.
CLIENT_ARGS = {
    "vr": {"youtube": {"player_client": ["android_vr"]}},
    "default": None,  # yt-dlp's own default clients
    "ios": {"youtube": {"player_client": ["ios"]}},
    "web": {"youtube": {"player_client": ["web_embedded", "mweb"]}},
}
YT_SOURCES = ("vr", "default", "ios", "web")


def base_opts(src=None, **extra):
    o = {
        "quiet": True, "noplaylist": True, "cachedir": False, "no_warnings": True,
        "no_color": True, "socket_timeout": 12, "retries": 2, "fragment_retries": 3,
        "extractor_retries": 1,
        # There is no ffmpeg on the phone: never try to post-process/fix containers.
        "fixup": "never", "postprocessors": [],
    }
    ea = CLIENT_ARGS.get(src)
    if ea:
        o["extractor_args"] = ea
    o.update(extra)
    return o


def clean_err(e):
    s = str(e) or e.__class__.__name__
    s = re.sub(r"\x1b\[[0-9;]*m", "", s)
    s = re.sub(r"^(ERROR:\s*)+", "", s.strip())
    s = re.sub(r"^\[[\w:]+\]\s+[\w-]{3,}:\s*", "", s)  # drop "[youtube] abc123:" prefix
    if "Sign in to confirm" in s or "not a bot" in s:
        s = "YouTube asked for a sign-in check for this video. Try again in a minute."
    return s.strip()[:300]


def is_youtube(url):
    host = (urlparse(url).hostname or "").lower()
    return host.endswith(("youtube.com", "youtu.be"))


def check_url(url):
    try:
        p = urlparse(url)
    except Exception:
        abort(400, "Invalid URL")
    host = (p.hostname or "").lower()
    if p.scheme not in ("http", "https") or not any(
        host == d or host.endswith("." + d) for d in ALLOWED_DOMAINS
    ):
        abort(400, "Unsupported link. Use YouTube, Facebook, Instagram or Snapchat.")
    return url


def youtube_id(url):
    m = re.search(r"(?:v=|youtu\.be/|shorts/|embed/)([A-Za-z0-9_-]{11})", url)
    return m.group(1) if m else None


def safe_name(s):
    return re.sub(r'[\\/:*?"<>|\n\r]+', " ", s or "").strip()[:90] or "video"


@app.errorhandler(400)
def bad_request(e):
    return jsonify(error=getattr(e, "description", "Bad request")), 400


@app.errorhandler(404)
def not_found(e):
    return jsonify(error="Not found"), 404


@app.get("/")
def index():
    return Response(INDEX_HTML, mimetype="text/html")


# ---------------------------------------------------------------- engine status

@app.get("/api/engine")
def engine():
    try:
        from yt_dlp.version import __version__ as ytv
    except Exception:
        ytv = "unknown"
    try:
        from java import jclass  # noqa: F401
        muxer = True
    except Exception:
        muxer = False
    return jsonify(ytdlp=ytv, clients=list(YT_SOURCES), muxer=muxer,
                   cached=len(info_cache), jobs=sum(1 for j in jobs.values() if j.get("status") in ("downloading", "processing")))


# ---------------------------------------------------------------- search / feed

def _entry_to_item(e):
    return {
        "id": e["id"],
        "title": e.get("title"),
        "channel": e.get("channel") or e.get("uploader"),
        "duration": e.get("duration"),
        "views": e.get("view_count"),
        "thumb": f"https://i.ytimg.com/vi/{e['id']}/mqdefault.jpg",
        "url": f"https://www.youtube.com/watch?v={e['id']}",
    }


def yt_search(q, n=PAGE_SIZE):
    """One flat YouTube search (cached for 15 minutes)."""
    key = (q.lower(), n)
    hit = search_cache.get(key)
    if hit and hit[0] > time.time():
        return hit[1]
    with yt_dlp.YoutubeDL(base_opts(extract_flat=True, skip_download=True)) as ydl:
        data = ydl.extract_info(f"ytsearch{n}:{q}", download=False)
    out = [_entry_to_item(e) for e in (data.get("entries") or []) if e and e.get("id")]
    search_cache[key] = (time.time() + 900, out)
    for k in sorted(search_cache, key=lambda x: search_cache[x][0])[:-60]:  # keep the cache small
        search_cache.pop(k, None)
    return out


def multi_search(queries, n=PAGE_SIZE):
    """Run several searches at the same time and weave the results together (A1 B1 C1 A2 B2 ...)."""
    queries = [q for q in dict.fromkeys(q.strip() for q in queries) if q]
    lists, errors = [[] for _ in queries], []

    def work(i, q):
        try:
            lists[i] = yt_search(q, n)
        except Exception as e:  # one bad phrase must not kill the page
            errors.append(clean_err(e))

    threads = [threading.Thread(target=work, args=(i, q), daemon=True) for i, q in enumerate(queries)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(20)
    seen, out = set(), []
    for row in itertools.zip_longest(*lists):
        for item in row:
            if item and item["id"] not in seen:
                seen.add(item["id"])
                out.append(item)
    if not out and errors:
        raise RuntimeError(errors[0])
    return out


def _mod(page, shift=0):
    return MODS[(page + shift) % len(MODS)]


def plan_queries(cat, page, tags, title="", channel=""):
    """Which searches make up page `page` of a feed.

    foryou  : the viewer's own interests (sent by the app) + one discovery search, so every
              person gets a different feed and it still surfaces new things.
    related : "up next" under a playing video: same channel, same topic, plus the viewer's interests.
    others  : the category's phrases, with one of the viewer's interests mixed in.
    """
    year = time.localtime().tm_year
    qs = []
    if cat == "related":
        words = " ".join(re.findall(r"[^\W_]{3,}", title)[:6])
        if channel:
            qs.append(f"{channel} {_mod(page)}")
        if words:
            qs.append(f"{words} {_mod(page, 3)}")
        if tags:
            qs.append(f"{tags[page % len(tags)]} {_mod(page, 5)}")
        return qs or ["trending videos today"]
    if cat == "foryou":
        k = min(len(tags), 3)
        for i in range(k):
            tag = tags[(page * k + i) % len(tags)]
            qs.append(f"{tag} {_mod(page, i)}")
        names = list(FEEDS)
        disc = FEEDS[names[(page + len(tags)) % len(names)]]
        qs.append(f"{disc[page % len(disc)]} {year if page % 2 else ''}")
        return qs
    base = FEEDS[cat]
    qs.append(f"{base[page % len(base)]} {_mod(page // len(base))}")
    if tags:
        qs.append(f"{tags[page % len(tags)]} {CAT_WORD.get(cat, '')} {_mod(page // max(1, len(tags)), 1)}")
    return qs


@app.get("/api/search")
def search():
    q = request.args.get("q", "").strip()
    if not q:
        abort(400, "Empty search")
    try:
        page = max(0, min(int(request.args.get("page", "0")), 9))
    except ValueError:
        page = 0
    size = 20
    try:
        # YouTube has no "page 2" for flat search: ask for more results and keep the new part
        res = yt_search(q, size * (page + 1))[size * page:]
        return jsonify(results=res, next=page + 1 if len(res) >= size - 4 and page < 9 else None)
    except Exception as e:
        return jsonify(error=f"Search failed: {e}"), 502


@app.get("/api/feed")
def feed():
    cat = request.args.get("cat", "foryou")
    if cat not in FEEDS and cat not in ("foryou", "related"):
        abort(400, "Unknown category")
    try:
        page = max(0, min(int(request.args.get("page", "0")), 500))
    except ValueError:
        page = 0
    tags = [t.strip()[:50] for t in request.args.get("tags", "").split("|") if t.strip()][:8]
    if cat == "foryou" and not tags:
        cat = "trending"  # a brand-new viewer: start from what is popular
    queries = plan_queries(cat, page, tags, request.args.get("title", "")[:150], request.args.get("channel", "")[:60])
    try:
        return jsonify(results=multi_search(queries), next=page + 1)
    except Exception as e:
        return jsonify(error=f"Could not load videos: {e}"), 502


# ---------------------------------------------------------------- info / quality options

def _size(f, dur):
    s = f.get("filesize") or f.get("filesize_approx")
    if not s and (f.get("tbr") or f.get("abr")) and dur:
        s = int((f.get("tbr") or f.get("abr")) * 125 * dur)
    return s


def _has_v(f):
    return f.get("vcodec") not in (None, "none")


def _has_a(f):
    return f.get("acodec") not in (None, "none")


def _vc(f):
    return str(f.get("vcodec") or "").lower()


def _ac(f):
    return str(f.get("acodec") or "").lower()


def _res(f):
    """Quality label number. Portrait videos (shorts) are labelled by their short side."""
    h, w = f.get("height"), f.get("width")
    if h and w and h > w:
        return w
    return h


def _tag(h):
    if h >= 4320:
        return "8K"
    if h >= 2160:
        return "4K"
    if h >= 1440:
        return "2K"
    if h >= 1080:
        return "Full HD"
    if h >= 720:
        return "HD"
    return ""


def _rate(f):
    return f.get("tbr") or f.get("abr") or f.get("vbr") or 0


def make_options(i, src):
    """Build the choices shown to the user from one extraction result.

    direct  = one file that already has video and sound (any container).
    merge   = separate video + audio, joined on the phone after download:
              H.264 + AAC -> .mp4        VP9 + Opus -> .webm  (this is how 1440p / 4K ship)
    extract = take the sound track out of a normal video file (when no audio-only stream exists).
    """
    fmts = [f for f in (i.get("formats") or [])
            if "m3u8" not in str(f.get("protocol", "")) and f.get("format_id")]
    dur = i.get("duration") or 0

    aonly = [f for f in fmts if _has_a(f) and not _has_v(f) and "drc" not in str(f["format_id"]).lower()]
    aac = [f for f in aonly if _ac(f).startswith("mp4a")]
    opus = [f for f in aonly if _ac(f).startswith("opus")]

    def best(lst):
        return max(lst, key=lambda f: (f.get("language_preference") or 0, _rate(f))) if lst else None

    best_aac, best_opus = best(aac), best(opus)

    # ---- video: one entry per resolution, best way of getting it wins
    vids = {}

    def offer(res, score, opt, rate):
        cur = vids.get(res)
        if not cur or (score, rate) > (cur["_s"], cur["_r"]):
            opt.update(_s=score, _r=rate)
            vids[res] = opt

    for f in fmts:
        if not _has_v(f):
            continue
        res = _res(f)
        if not res:
            continue
        r = _rate(f)
        if _has_a(f):  # ready-made file with sound
            ext = f.get("ext") or "mp4"
            offer(res, 30 if ext == "mp4" else 10,
                  {"mode": "direct", "fmt": f["format_id"], "ext": ext, "size": _size(f, dur)}, r)
            continue
        vs = _size(f, dur)
        if _vc(f).startswith(("avc1", "h264")) and f.get("ext") == "mp4" and best_aac:
            asz = _size(best_aac, dur)
            offer(res, 20, {"mode": "merge", "vid": f["format_id"], "aid": best_aac["format_id"], "ext": "mp4",
                            "size": (vs + asz) if vs and asz else vs}, r)
        elif _vc(f).startswith(("vp9", "vp09", "vp8")) and best_opus:
            asz = _size(best_opus, dur)
            offer(res, 15, {"mode": "merge", "vid": f["format_id"], "aid": best_opus["format_id"], "ext": "webm",
                            "size": (vs + asz) if vs and asz else vs}, r)

    out = []
    for res, o in vids.items():
        o = {k: v for k, v in o.items()}
        o.update(key=str(res), label=f"{res}p", tag=_tag(res), kind="video", src=src, res=res)
        out.append(o)

    # ---- audio: every real audio stream (bitrate x format)
    seen = {}
    for f in aonly:
        a = _ac(f)
        name = "M4A" if a.startswith("mp4a") else "OPUS" if a.startswith("opus") else (f.get("ext") or "AUDIO").upper()
        abr = int(round(f.get("abr") or f.get("tbr") or 0))
        k = (name, abr)
        cur = seen.get(k)
        if not cur or (f.get("language_preference") or 0) > (cur.get("language_preference") or 0):
            seen[k] = f
    for (name, abr), f in seen.items():
        out.append({"key": "a" + str(f["format_id"]), "label": f"{abr}K" if abr else "Audio", "tag": "",
                    "kind": "audio", "mode": "direct", "fmt": f["format_id"], "ext": name,
                    "size": _size(f, dur), "src": src, "abr": abr})

    if not aonly:
        # no audio-only stream (Instagram, Snapchat...): pull the sound out of the smallest AAC video
        cands = [f for f in fmts if _has_v(f) and _has_a(f) and _ac(f).startswith("mp4a")]
        if cands:
            f = min(cands, key=lambda x: (_res(x) or 9999, _rate(x)))
            abr = int(round(f.get("abr") or 128))
            out.append({"key": "aextract", "label": "Audio", "tag": "", "kind": "audio", "mode": "extract",
                        "fmt": f["format_id"], "ext": "M4A", "size": int(abr * 125 * dur) if dur else None,
                        "src": src, "abr": abr})
    return out


def combine_options(per_src):
    """Merge the option lists of several extractions: best way per resolution, all audio streams."""
    vids, auds = {}, {}
    for src, opts in per_src:
        for o in opts:
            if o["kind"] == "video":
                cur = vids.get(o["key"])
                if not cur or (o["_s"], o["_r"]) > (cur["_s"], cur["_r"]):
                    vids[o["key"]] = o
            else:
                k = (o["ext"], o.get("abr"))
                if k not in auds:
                    auds[k] = o
    v = sorted(vids.values(), key=lambda o: -o["res"])
    if any(o["mode"] != "extract" for o in auds.values()):
        auds = {k: o for k, o in auds.items() if o["mode"] != "extract"}  # real audio streams exist
    a = sorted(auds.values(), key=lambda o: (o["ext"] != "M4A", -(o.get("abr") or 0)))
    opts = v + a
    if not opts:
        opts.append({"key": "best", "label": "Best quality", "tag": "", "kind": "video", "mode": "direct",
                     "fmt": "best", "ext": "mp4", "size": None, "src": "default"})
    for o in opts:
        o.pop("_s", None)
        o.pop("_r", None)
    return opts


def _extract(url, src, results, errors, stamps):
    try:
        # format "b*" always resolves when ANY stream exists, so listing never fails on selection
        o = base_opts(src, skip_download=True, format="b*", ignore_no_formats_error=True)
        with yt_dlp.YoutubeDL(o) as ydl:
            results[src] = ydl.extract_info(url, download=False)
        stamps[src] = time.time()
    except Exception as e:
        errors[src] = clean_err(e)


INFO_TTL = 1800


def get_info(url):
    hit = info_cache.get(url)
    if hit and hit["exp"] > time.time():
        return hit
    srcs = YT_SOURCES if is_youtube(url) else ("default",)
    results, errors, stamps = {}, {}, {}
    threads = [threading.Thread(target=_extract, args=(url, s, results, errors, stamps), daemon=True)
               for s in srcs]
    for t in threads:
        t.start()
    t0 = time.time()
    while any(t.is_alive() for t in threads):
        now = time.time()
        # once one client has answered, give the others a few seconds, then go with what we have
        if stamps and now - min(stamps.values()) > 2:
            break
        if now - t0 > 30:
            break
        time.sleep(0.1)
    infos = {s: results[s] for s in srcs if s in results}
    if not infos:
        raise RuntimeError(next(iter(errors.values()), "No response from the site"))
    per_src, first = [], None
    for s, i in infos.items():
        try:
            per_src.append((s, make_options(i, s)))
            first = first or i
        except Exception as e:
            errors[s] = clean_err(e)
    opts = combine_options(per_src)
    first = first or next(iter(infos.values()))
    entry = {
        "exp": time.time() + INFO_TTL, "infos": infos, "opts": opts,
        "small": {k: first.get(k) for k in ("title", "uploader", "duration", "thumbnail", "view_count")},
        "streams": {},
    }
    info_cache[url] = entry
    for u in sorted(info_cache, key=lambda x: info_cache[x]["exp"])[:-5]:  # keep the 5 newest
        info_cache.pop(u, None)
    return entry


@app.get("/api/info")
def info():
    url = check_url(request.args.get("url", "").strip())
    try:
        e = get_info(url)
    except Exception as ex:
        return jsonify(error=f"Could not read this link: {clean_err(ex)}"), 502
    i = e["small"]
    return jsonify(
        url=url, title=i.get("title"), uploader=i.get("uploader"),
        duration=i.get("duration"), thumb=i.get("thumbnail"),
        youtube_id=youtube_id(url), views=i.get("view_count"),
        play=play_heights(e),
        options=[{k: o.get(k) for k in ("key", "label", "tag", "size", "kind", "mode", "ext")} for o in e["opts"]],
    )


@app.get("/api/preview")
def preview():
    url = check_url(request.args.get("url", "").strip())
    now = time.time()
    cached = preview_cache.get(url)
    if not cached or cached[0] < now:
        opts = base_opts(format="best[protocol^=http][ext=mp4]/best[protocol^=http]")
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                i = ydl.extract_info(url, download=False)
        except Exception:
            abort(400, "Preview unavailable")
        if not i.get("url"):
            abort(400, "Preview unavailable")
        cached = (now + 300, i["url"], i.get("http_headers", {}))
        preview_cache[url] = cached
    _, direct, headers = cached
    h = dict(headers)
    if request.headers.get("Range"):
        h["Range"] = request.headers["Range"]
    r = requests.get(direct, headers=h, stream=True, timeout=20)
    resp = Response(r.iter_content(65536), status=r.status_code)
    for k in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges"):
        if k in r.headers:
            resp.headers[k] = r.headers[k]
    return resp


# ---------------------------------------------------------------- streaming (own player)

def _stream_ok(f):
    """A format the phone's player can open straight from a URL (no DASH / HLS manifests)."""
    proto = str(f.get("protocol", ""))
    return bool(f.get("url")) and f.get("format_id") and "m3u8" not in proto and "dash" not in proto \
        and "drc" not in str(f["format_id"]).lower()


def play_heights(entry):
    """Qualities that can be streamed as ONE file with sound (what the player's quality menu shows)."""
    heights = {}
    for info in entry["infos"].values():
        for f in info.get("formats") or []:
            if _stream_ok(f) and _has_v(f) and _has_a(f) and _res(f):
                heights[_res(f)] = max(heights.get(_res(f), 0), _size(f, entry["small"].get("duration") or 0) or 0)
    return [{"res": h, "label": f"{h}p", "size": heights[h] or None} for h in sorted(heights, reverse=True)]


def pick_stream(entry, mode, q):
    """Choose one streamable format. mode=audio: sound only (small, saves data); mode=video: <= q pixels."""
    cache = entry["streams"]
    if (mode, q) in cache:
        return cache[(mode, q)]
    best, best_key = None, None
    for info in entry["infos"].values():
        for f in info.get("formats") or []:
            if not _stream_ok(f):
                continue
            if mode == "audio":
                if not _has_a(f):
                    continue
                abr = f.get("abr") or f.get("tbr") or 0
                # audio-only first, AAC (plays everywhere) first, then ~128 kbit is plenty for a phone
                key = (not _has_v(f), _ac(f).startswith("mp4a"), -abs(min(abr, 192) - 128))
            else:
                if not (_has_v(f) and _has_a(f)) or not _res(f):
                    continue
                r = _res(f)
                # nearest quality that is not above the wanted one (else the lowest one above it)
                key = (r <= q, r if r <= q else -r, f.get("ext") == "mp4", _rate(f))
            if best_key is None or key > best_key:
                best, best_key = f, key
    pick = None
    if best:
        pick = {"url": best["url"], "headers": best.get("http_headers") or {}}
    cache[(mode, q)] = pick
    return pick


GV_CHUNK = 10 * 1024 * 1024  # YouTube's servers slow down / refuse very long ranges: ask in 10 MB pieces


def proxy_stream(direct, headers, range_hdr):
    """Pass a remote media file through to the player with proper Range support (seeking)."""
    h = dict(headers or {})
    gv = (urlparse(direct).hostname or "").endswith("googlevideo.com")
    m = re.match(r"bytes=(\d*)-(\d*)$", range_hdr or "")
    if gv:
        start = int(m.group(1)) if m and m.group(1) else 0
        end = int(m.group(2)) if m and m.group(2) else None
        cap = start + GV_CHUNK - 1
        h["Range"] = f"bytes={start}-{cap if end is None else min(end, cap)}"
    elif range_hdr:
        h["Range"] = range_hdr
    r = requests.get(direct, headers=h, stream=True, timeout=20)
    resp = Response(r.iter_content(65536), status=r.status_code)
    for k in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges"):
        if k in r.headers:
            resp.headers[k] = r.headers[k]
    resp.headers.setdefault("Accept-Ranges", "bytes")
    resp.call_on_close(r.close)
    return resp, r.status_code


@app.get("/api/stream")
def stream():
    """The player's source. ?url=<page link>&mode=video|audio&q=<max height>"""
    url = check_url(request.args.get("url", "").strip())
    mode = "audio" if request.args.get("mode") == "audio" else "video"
    try:
        q = int(request.args.get("q") or 720)
    except ValueError:
        q = 720
    try:
        entry = get_info(url)
    except Exception as ex:
        return jsonify(error=f"Could not read this link: {clean_err(ex)}"), 502
    pick = pick_stream(entry, mode, q)
    if not pick:
        if mode == "video":
            return preview()  # last resort: let yt-dlp choose a single file itself
        abort(400, "No sound stream for this video")
    range_hdr = request.headers.get("Range")
    try:
        resp, status = proxy_stream(pick["url"], pick["headers"], range_hdr)
        if status in (403, 404, 410):
            # Signed media URLs expire. Re-extract the page and retry once with fresh headers/URL.
            resp.close()
            info_cache.pop(url, None)
            fresh = get_info(url)
            fresh_pick = pick_stream(fresh, mode, q)
            if fresh_pick:
                resp, status = proxy_stream(fresh_pick["url"], fresh_pick["headers"], range_hdr)
                if status not in (403, 404, 410):
                    return resp
            return jsonify(error="The source rejected playback (HTTP 403/expired link). Refresh the video or try another quality."), 502
    except requests.RequestException:
        entry["streams"].pop((mode, q), None)
        return jsonify(error="The video server did not answer. Check your connection and retry."), 502
    return resp


# ---------------------------------------------------------------- downloading

def _merge(video, audio, out):
    from java import jclass  # only exists inside the Android app
    jclass("com.mydl.app.Muxer").merge(video, audio, out)


def _extract_audio(video, out):
    from java import jclass
    jclass("com.mydl.app.Muxer").extractAudio(video, out)


def _find(prefix):
    files = [f for f in glob.glob(glob.escape(prefix) + ".*")
             if not f.endswith((".part", ".ytdl", ".json", ".temp"))]
    return files[0] if files else None


def _rm(*paths):
    for p in paths:
        try:
            if p and os.path.exists(p):
                os.remove(p)
        except OSError:
            pass


def _rm_prefix(prefix):
    for p in glob.glob(glob.escape(prefix) + ".*"):
        if not p.endswith(".json"):
            _rm(p)


def _speed(n):
    if not n:
        return ""
    return f"{n / 1e6:.1f} MB/s" if n >= 1e6 else f"{max(1, int(n / 1e3))} KB/s"


def run_job(jid, url, key):
    job = jobs[jid]
    base = os.path.join(LIB_DIR, jid)

    def make_hook(lo, hi, est):
        def hook(d):
            if job.get("cancel"):
                raise Cancelled()
            if d.get("status") == "downloading":
                total = d.get("total_bytes") or d.get("total_bytes_estimate") or est or 0
                done = d.get("downloaded_bytes") or 0
                if total and done:
                    frac = min(0.99, done / total)
                    job["progress"] = round((lo + (hi - lo) * frac) * 100, 1)
                job["speed"] = _speed(d.get("speed"))
        return hook

    def fetch(entry, src, fmt, prefix, hook):
        """Download one format. First from the already-read info, then by reading the link again."""
        url_src = src if src in CLIENT_ARGS else "default"
        o = base_opts(url_src, format=fmt, outtmpl=prefix + ".%(ext)s", progress_hooks=[hook],
                      http_chunk_size=10 * 1024 * 1024, overwrites=False, continuedl=True,
                      nopart=False, concurrent_fragment_downloads=4)
        errors = []
        # Reuse a completed stage, or let yt-dlp continue its .part file after a network drop.
        completed = _find(prefix)
        if completed and os.path.getsize(completed) > 0:
            return completed
        for attempt in ("info", "url"):
            try:
                with yt_dlp.YoutubeDL(o) as ydl:
                    if attempt == "info" and entry["infos"].get(src):
                        ydl.process_ie_result(copy.deepcopy(entry["infos"][src]), download=True)
                    else:
                        ydl.download([url])
                path = _find(prefix)
                if path and os.path.getsize(path) > 0:
                    return path
                errors.append("Downloaded file not found")
            except Exception as e:
                if job.get("cancel") or isinstance(e, Cancelled):
                    raise Cancelled()
                errors.append(clean_err(e))
        raise RuntimeError(errors[-1] if errors else "Download failed")

    temps = []
    try:
        entry = get_info(url)
        i, opts = entry["small"], entry["opts"]
        opt = next((o for o in opts if o["key"] == key), None) or next((o for o in opts if o["kind"] == "video"), opts[0])
        src = opt.get("src", "default")
        qlabel = opt["label"] if opt["kind"] == "video" else f'{opt["label"]} {opt.get("ext", "")}'.strip()
        job.update(title=i.get("title"), thumb=i.get("thumbnail"), quality=qlabel)
        total = opt.get("size") or 0

        if opt["mode"] == "merge":
            # video is ~90% of the bytes, sound the rest; the last % is for joining them
            vpath = fetch(entry, src, opt["vid"], base + "_v", make_hook(0, 0.9, int(total * 0.9) if total else 0))
            temps.append(vpath)
            apath = fetch(entry, src, opt["aid"], base + "_a", make_hook(0.9, 0.97, int(total * 0.1) if total else 0))
            temps.append(apath)
            job["status"] = "processing"
            job["progress"] = 98
            out = base + "." + (opt.get("ext") or "mp4")
            try:
                _merge(vpath, apath, out)
            except Exception as e:
                _rm(out)
                raise RuntimeError("Could not join video and sound: " + clean_err(e))
            if not os.path.exists(out) or os.path.getsize(out) == 0:
                raise RuntimeError("Could not join video and sound")
        elif opt["mode"] == "extract":
            vpath = fetch(entry, src, opt["fmt"], base + "_v", make_hook(0, 0.95, 0))
            temps.append(vpath)
            job["status"] = "processing"
            job["progress"] = 97
            out = base + ".m4a"
            try:
                _extract_audio(vpath, out)
            except Exception as e:
                _rm(out)
                raise RuntimeError("Could not extract the sound: " + clean_err(e))
        else:
            out = fetch(entry, src, opt["fmt"], base, make_hook(0, 1, total))
        _rm(*temps)

        ext = os.path.splitext(out)[1].lstrip(".")
        meta = {
            "id": jid, "title": safe_name(i.get("title")), "uploader": i.get("uploader"),
            "thumb": i.get("thumbnail"), "duration": i.get("duration"),
            "quality": qlabel, "kind": opt["kind"], "ext": ext,
            "file": os.path.basename(out), "size": os.path.getsize(out),
            "created": time.time(), "source": url,
        }
        with open(base + ".json", "w", encoding="utf-8") as fh:
            json.dump(meta, fh)
        job["item"] = meta
        job["progress"] = 100
        job["status"] = "done"
    except Exception as e:
        # Keep .part/.ytdl files and completed merge stages so Try again can resume
        # instead of throwing away a nearly-finished download.
        if job.get("cancel") or isinstance(e, Cancelled):
            job["status"] = "cancelled"
        else:
            job["status"] = "error"
            job["err"] = clean_err(e) or "Download failed"


@app.post("/api/download")
def download():
    body = request.get_json(silent=True) or {}
    url = check_url(str(body.get("url", "")).strip())
    key = str(body.get("key", ""))
    # A stable ID means a retry (or app process restart) finds the same .part files.
    jid = hashlib.sha256((url + "|" + key).encode("utf-8")).hexdigest()[:12]
    previous = jobs.get(jid, {})
    if previous.get("status") in ("downloading", "processing"):
        return jsonify(id=jid)
    if previous.get("status") == "done":
        jid = uuid.uuid4().hex[:12]
    jobs[jid] = {"status": "downloading", "progress": 0, "created": time.time(),
                 "url": url, "key": key}
    threading.Thread(target=run_job, args=(jid, url, key), daemon=True).start()
    return jsonify(id=jid)


@app.get("/api/progress/<jid>")
def progress(jid):
    j = jobs.get(jid)
    if not j:
        abort(400, "Unknown job")
    # NB: the failure text is sent as "err", not "error": the web UI treats an "error" field as a failed request.
    return jsonify({k: j.get(k) for k in ("status", "progress", "speed", "err", "title", "thumb", "quality", "item")})


@app.post("/api/cancel/<jid>")
def cancel(jid):
    j = jobs.get(jid)
    if j:
        j["cancel"] = True
    return jsonify(ok=True)


# ---------------------------------------------------------------- library

def _meta(item_id):
    if not ID_RE.match(item_id):
        abort(400, "Bad id")
    p = os.path.join(LIB_DIR, item_id + ".json")
    if not os.path.exists(p):
        abort(404)
    with open(p, encoding="utf-8") as fh:
        m = json.load(fh)
    path = os.path.join(LIB_DIR, m["file"])
    if not os.path.exists(path):
        abort(404)
    return m, path


@app.get("/api/library")
def library():
    items, total = [], 0
    for p in glob.glob(os.path.join(LIB_DIR, "*.json")):
        try:
            with open(p, encoding="utf-8") as fh:
                m = json.load(fh)
            if os.path.exists(os.path.join(LIB_DIR, m["file"])):
                items.append(m)
                total += m.get("size") or 0
        except Exception:
            continue
    items.sort(key=lambda m: m.get("created", 0), reverse=True)
    return jsonify(items=items, total=total)


@app.get("/api/media/<item_id>")
def media(item_id):
    m, path = _meta(item_id)
    mime = mimetypes.guess_type(path)[0] or ("audio/mp4" if m["kind"] == "audio" else "video/mp4")
    return send_file(path, mimetype=mime, conditional=True)


@app.get("/api/file/<item_id>")
def get_file(item_id):
    m, path = _meta(item_id)
    return send_file(path, as_attachment=True, download_name=f"{m['title']}.{m['ext']}")


@app.delete("/api/library/<item_id>")
def delete_item(item_id):
    m, path = _meta(item_id)
    _rm(path, os.path.join(LIB_DIR, item_id + ".json"))
    return jsonify(ok=True)


@app.delete("/api/library")
def delete_all():
    for p in glob.glob(os.path.join(LIB_DIR, "*")):
        if os.path.isfile(p):
            _rm(p)
    return jsonify(ok=True)


def cleanup_loop():
    while True:
        time.sleep(600)
        cutoff = time.time() - 3600
        for jid, j in list(jobs.items()):
            if j["created"] < cutoff and j.get("status") in ("done", "error", "cancelled"):
                jobs.pop(jid, None)


def start(html, lib_dir):
    """Called from Kotlin. Blocks while the server runs."""
    global INDEX_HTML, LIB_DIR
    INDEX_HTML = html
    LIB_DIR = lib_dir
    os.makedirs(LIB_DIR, exist_ok=True)
    threading.Thread(target=cleanup_loop, daemon=True).start()
    app.run(host="127.0.0.1", port=5000, threaded=True, use_reloader=False)
