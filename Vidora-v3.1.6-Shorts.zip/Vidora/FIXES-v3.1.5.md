# Vidora v3.1.5 – Mini Player Navigation and Drag Fix

- Preserve the in-app floating video mini-player state when navigating to Next or Previous online videos and local downloads.
- Keep the floating mini-player controls, including Full Screen, visible after each video change.
- Preserve the mini-player's current on-screen position while switching videos.
- Expand drag handling from the title strip to the entire floating player surface, including video and control areas.
- Use pointer capture and suppress accidental button/tap actions after a drag gesture.
- Keep audio-only mini-player behavior separate.

Build and test on an Android device before release.
