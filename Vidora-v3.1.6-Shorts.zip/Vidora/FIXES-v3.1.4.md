# Vidora v3.1.4 – Mini Player Controls

- Added Previous video and Next video controls to the in-app floating video mini-player.
- Added a Full screen control that expands the mini-player and enters the existing full-screen player mode.
- Kept the existing play/pause, close, drag-to-move, swipe-down-to-minimize, and Android PiP behavior.
- Reused the existing queue/history navigation functions and the same video element to preserve playback continuity.

Build and test on an Android device before release.
