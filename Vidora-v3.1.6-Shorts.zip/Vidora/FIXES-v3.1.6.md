# Vidora v3.1.6 – Mini Player Layout and Logo Fixes

Mini player
- Thumbnail is shown while the next/previous video loads (no more black screen with a play-button picture).
- Title at the top, Full Screen button exactly in the centre, Previous / Play-Pause / Next at the bottom.
- Title and buttons hide automatically ~3 s after playback starts; tap the mini player to show them again (they stay visible while paused/loading).
- Dragging still works from anywhere; pointer capture starts only after a real drag so taps always reach the buttons.

Logo
- Launcher (adaptive) icon foreground re-made with the existing Vidora logo inside the safe zone, so the installer, home screen and app drawer no longer cut the sides.
- Notification/status-bar system "download" vector icon replaced by a Vidora logo silhouette (`ic_stat_vidora`) and the full logo as large icon.
- Home header logo is a transparent PNG (no clipped corners); the Home hero "V" vector mark is replaced by the Vidora logo.

Follow-up fixes
- Mini player Full Screen button now just expands back to the normal player (no forced landscape full screen).
- "This video format is not supported by this device": the play() rejection now uses the same fallback chain as the error event (fresh-link retry, then up to 3 automatic quality step-downs).
- Server: combined files prefer H.264; for videos with no H.264 stream at all, a VP9/WebM video-only stream is offered as a last resort instead of failing.

FFmpeg + player glitch
- FFmpeg (community FFmpegKit fork `dev.ffmpegkit-maintained:ffmpeg-kit-free:6.0.4`) added. If a video still cannot be decoded after the automatic retries/quality step-downs, the error screen shows "Convert & play (FFmpeg)". It converts to VP9/WebM (max 480p, with progress %) and plays the result. Works for downloaded files and online videos (read through the app's local http relay, because the free FFmpeg build has no HTTPS / H.264 encoder). Wrapper: `Transcoder.kt` (reflection, so the app still builds/runs if the library is missing). Endpoints: `/api/compat/start|status|file|cancel`.
- Fixed the shifted / shrunken player glitch: the floating player's drag position (inline left/top/right/bottom/width) was left behind after closing it and leaked into the next normal player. It is now cleared when the player opens, closes or expands.

Home / Discover
- The Discover tab and page are removed. Its category chips (All, Music, Movies, Gaming, Comedy, News, DIY) now sit in Home's sticky header under the search bar, above one single feed.
- "For you" and "Trending" are gone as separate feeds: "All" is the one personalised feed (it falls back to popular videos for new users). Home search replaces Discover's search; the site shortcuts (YouTube/Music/Movies/Gaming) now open Home.

Shorts
- New YouTube-Shorts-style feed: full-screen vertical pages, swipe up/down, auto-play, tap to pause, double-tap to like, progress bar; Like / Dislike / Comments / Share / Save on the right, channel + Subscribe + title bottom-left, "Shorts" header.
- Only real 9:16 Shorts: server checks each result with youtube.com/shorts/<id> (the old width/height filter removed every result because search results carry no size, which emptied the feed).
- The list and the first video are loaded at app start; opening the tab plays instantly and the next 2 videos are preloaded.
- Comments sheet via /api/comments (yt-dlp, top 30).
