# Vidora v3.1.3 – YouTube-style Floating Mini Player

- Replaced the video-mode bottom audio-style strip with a compact floating in-app video window.
- The mini player continues using the same HTML video element, preserving playback position and audio/video synchronization.
- Added drag movement using the mini-player title area; it can be repositioned within the app viewport.
- Added downward swipe on the video surface to collapse the watch player into the floating mini player.
- Kept the top down-arrow/minimize button as another way to enter mini-player mode.
- Tapping the mini-player expands the watch player; play/pause and close controls remain available.
- Audio-only mode retains its compact audio control strip. Android system PiP remains separate.

Build note: Android SDK/Gradle are not installed in this environment, so an APK build/device test could not be run here.
