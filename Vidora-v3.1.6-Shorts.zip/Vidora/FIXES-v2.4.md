# Vidora 2.4: bug fixes

Each problem below lists the cause found while testing (YouTube, Nov 2026) and the fix.

## 1. Slow loading and search
**Cause**
- Each video was read by 4 YouTube "clients" at once, and the app always waited 7 s after the first answer.
- Network timeouts were 25 s with 8 retries, so one bad connection could stall a screen for minutes.
- Search page 2 downloaded page 1 again. Nothing was loaded ahead of time.

**Fix (`python/server.py`)**
- Only the clients that still work are used (see 2). The app continues as soon as the main one answers. Late answers are merged in the background.
- Timeouts are now 10 to 15 s with 2 to 5 retries. A slow feed phrase is dropped after 20 s, where it used to block the page for 45 s.
- Search results are cached per phrase, and the next search or feed page loads in the background. Measured: page 2 now opens in 0.07 s (was 1.5 to 2 s).
- One shared connection pool to the video servers makes starting and seeking faster.
- The yt-dlp cache is turned on (`cachedir`), and the engine-start check runs every 100 ms instead of every 500 ms.

## 2. Online playback error and "HTTP Error 403: Forbidden"
**Cause (tested)**
- `android_vr` now returns only format 18 (360p video with sound), and that link answers **403**.
- `ios`, `mweb` and `web_embedded` need a PO token or a JavaScript runtime. They return no formats or 403 links.
- The old player could only play one-file streams (video and sound together). YouTube no longer gives a working one, so every video failed.

**Fix**
- Clients: yt-dlp's own `default` choice (currently `visionos`), with `visionos` as a fallback. Every quality from 144p to 4K is returned and all of them download (checked).
- The player plays **video and sound as two streams kept in sync**: `<video>` gets `mode=vonly`, a hidden `<audio>` gets `mode=audio`. Drift is corrected above 0.3 s, and seek, pause, speed and loop are mirrored.
- Expired or refused links heal themselves:
  - Player: on 403/404/410 the engine fetches a fresh link and retries once. The page also retries once by itself before showing an error.
  - Downloads: the app tries cached info, then a fresh read, then the other client. Each 403 throws away the cached link.
  - Tested by deliberately breaking every cached link: playback and downloads still finished.

## 3. Only one format offered
**Cause:** the same client problem. Only format 18 came back, so the sheet showed just "360P MP4" and one audio.

**Fix:** the full list comes back again, for example on "Tere Liye":
- Video: 2160p and 1440p (WebM), 1080p, 720p, 480p, 360p, 240p and 144p (MP4).
- Audio: M4A 129K and 49K, Opus 140K, 72K and 54K.
- The player's quality menu now offers 144p to 1080p.
- Downloads now play with the correct file type (.m4a, .opus, audio .webm, .mkv and others), so the player no longer refuses them.

## 4. Sound stops on the home screen (high priority)
**Cause**
- Chromium pauses `<video>` once the WebView window is hidden.
- The foreground service had type `dataSync`, which is the wrong type for playback on Android 14.
- There was no MediaSession and no wake lock.

**Fix**
- `BgWebView` keeps reporting "visible" to Chromium while something is loaded in the player (`MainActivity.kt`).
- `KeepAliveService` is now a **mediaPlayback** foreground service with:
  - a MediaSession (notification, lock screen and headset buttons: play, pause, next, previous)
  - a partial wake lock and a Wi-Fi lock.
  - Manifest: `FOREGROUND_SERVICE_MEDIA_PLAYBACK`, `WAKE_LOCK`, and `foregroundServiceType="dataSync|mediaPlayback"`.
- WebView renderer priority is set to IMPORTANT.
- Backup in the page: if Android still pauses playback that the user did not pause, the page switches to sound-only (online) or presses play again. The video comes back when you return.
- New bridge call `Android.setState(downloads, media, playing, title, subtitle, text)` and `window.mediaCmd(cmd)`.

## 5. "App not installed as package conflicts with an existing package"
**Cause:** every GitHub build signed the APK with a new random debug key.

**Fix:** `app/vidora-debug.p12` is one fixed key used by every build (`signingConfigs` in `app/build.gradle.kts`). Version is now 2.4 (code 5).
**One time only:** uninstall the old Vidora, then install this build. After that, updates install over it. Files saved in Downloads/Vidora stay. The in-app library is cleared by the uninstall.
