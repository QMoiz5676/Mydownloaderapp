# Vidora 2.5 - feed, player and launcher fixes

## Feed freshness and pagination
- Added an explicit Refresh action for the Home recommendations feed.
- Refresh requests bypass the backend's 15-minute search-result cache and use YouTube's date-sorted search mode for the first page.
- Existing per-feed ID de-duplication remains in place across pages and across the multiple search phrases woven into a feed.
- The app re-fetches the Home feed at startup and after returning from the background after five minutes.
- Normal pagination remains cacheable so scrolling does not repeatedly fetch the same search results.

## Region-aware recommendations
- Added `/api/region`, which detects country from public-IP geolocation and caches the result for 12 hours.
- If IP lookup is unavailable, device locale and timezone are used as fallbacks.
- The detected country is appended to category and interest searches. It is dynamic and is not hardcoded to Pakistan.
- Regional targeting is a search-ranking hint, not a guarantee that YouTube returns only locally produced videos.

## Player loading and controls
- Fixed a real spinner bug: clearing an old error immediately hid the spinner that had just been shown for a new source.
- The spinner now remains visible through initial load and active buffering, and is hidden on the actual `playing` event or when the user pauses.
- Added `stalled` and seek loading handling. `canplay` no longer hides the spinner prematurely.
- Playback-start promise failures and media decoder/network errors now produce actionable messages.
- Added a volume slider that controls both the video and the paired audio stream.
- Existing play/pause, seeking, time display, quality selection, fullscreen, playback position, and dual-stream synchronization are preserved.

## Launcher icon
- Moved the adaptive icon into `mipmap-anydpi-v26`.
- Added density-specific legacy launcher bitmaps and explicit application/activity icon declarations.
- Set the application round icon to the same Vidora asset.

## Verification status
- Python backend passes `py_compile`.
- Embedded player JavaScript passes `node --check`.
- Android XML files and launcher resource references were checked for consistency.
- A full Android APK build and on-device playback/feed tests were not possible in this environment because neither Gradle nor an Android SDK is installed. The GitHub Actions workflow now performs the source syntax checks and builds the APK when run in GitHub Actions.
