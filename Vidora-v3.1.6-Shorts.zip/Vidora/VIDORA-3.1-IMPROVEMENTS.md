# Vidora 3.1 improvements

- Shorts feed now requires verified portrait metadata (height > width and width/height <= 0.80); landscape videos and results without dimensions are excluded.
- Shorts duration filter allows up to 180 seconds where supported by the source metadata.
- Android/WebView stream selection now prefers H.264/MP4 video-only streams and avoids VP9/WebM decoder compatibility failures.
- Player attempts one lower advertised quality after a decoder error.
- Removed the external Play Audio action; audio-only mode remains inside the player controls.
- App version bumped to 3.1.

Note: this source update has not yet been verified by a full Android Gradle build or on-device playback test.
