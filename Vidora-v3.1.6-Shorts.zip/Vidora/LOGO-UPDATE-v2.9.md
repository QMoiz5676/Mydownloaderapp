# Vidora v2.9 — New Launcher Logo

Updated the Android launcher icon assets using the supplied Vidora logo.

Updated:
- `ic_launcher.png` for mdpi, hdpi, xhdpi, xxhdpi, xxxhdpi
- `ic_launcher_foreground.png` for adaptive launcher icons at all densities

The existing adaptive icon XML, manifest icon references, app code, and other project files are preserved.

After replacing the repository source, build a fresh APK. If the old icon remains on the device, uninstall the previous app before installing the new APK (or clear the launcher's icon cache).
