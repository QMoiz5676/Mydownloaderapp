# Vidora 2.5.1 feed refresh hotfix

- Fixed fresh-feed requests using the unsupported `ytsearchdateN:` pseudo-URL.
- All YouTube searches now use yt-dlp's supported `ytsearchN:` extractor prefix.
- Explicit fresh requests still bypass the app's in-memory search cache, while normal pagination can reuse cached search results.
- This removes the exact `Unsupported url scheme: "ytsearchdate12"` failure shown in the report.

Validation: Python source parsed successfully and ZIP integrity checked. A Gradle/APK build and on-device YouTube request still need to be run in Android/GitHub Actions.
