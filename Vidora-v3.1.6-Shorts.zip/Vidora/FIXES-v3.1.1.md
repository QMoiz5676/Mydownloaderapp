# Vidora 3.1.1 build fix

## Fixed
- Corrected the Android Picture-in-Picture API call in `MainActivity.updatePipParams()`.
- Replaced the nonexistent `updatePictureInPictureParams(...)` reference with the Android `Activity.setPictureInPictureParams(...)` API, guarded by the existing Android 8.0+ check.

## Preserved
- Existing video-only PiP state tracking and aspect-ratio handling.
- PiP Play/Pause remote action.
- Android 12+ auto-enter behavior.
- Existing WebView player, background playback service, widgets, Python backend, and UI assets.

## Validation
- Android XML resources parsed successfully.
- Python backend passed syntax compilation.
- Embedded JavaScript passed `node --check`.
- Full Android Gradle compilation was not run in this workspace because Gradle and the Android SDK are not installed here. Run the repository's GitHub Actions workflow to confirm the APK build.
