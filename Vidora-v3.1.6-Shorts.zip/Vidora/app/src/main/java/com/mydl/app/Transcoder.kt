package com.mydl.app

/**
 * Thin wrapper around the FFmpegKit library (community-maintained fork, Maven Central:
 * dev.ffmpegkit-maintained:ffmpeg-kit-free). It is called through reflection on purpose, so the app
 * still compiles and runs (with the conversion feature reporting "engine missing") if the library
 * is ever removed or its API differs. Called from Python (server.py, the compat endpoints).
 */
object Transcoder {
    private const val KIT = "com.arthenica.ffmpegkit.FFmpegKit"

    @JvmStatic
    fun available(): Boolean = try {
        Class.forName(KIT); true
    } catch (_: Throwable) {
        false
    }

    /** Runs ffmpeg with the given arguments and waits. Returns 0 on success, -2 if FFmpeg is missing, other values = failure. */
    @JvmStatic
    fun run(args: Array<String>): Int = try {
        val kit = Class.forName(KIT)
        val session = kit.getMethod("executeWithArguments", Array<String>::class.java).invoke(null, args as Any)
        val rc = session!!.javaClass.getMethod("getReturnCode").invoke(session)
        if (rc == null) -1 else (rc.javaClass.getMethod("getValue").invoke(rc) as Int)
    } catch (_: ClassNotFoundException) {
        -2
    } catch (_: Throwable) {
        -1
    }

    @JvmStatic
    fun cancel() {
        try {
            Class.forName(KIT).getMethod("cancel").invoke(null)
        } catch (_: Throwable) {
        }
    }
}
