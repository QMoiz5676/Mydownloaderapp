package com.mydl.app

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.nio.ByteBuffer

/**
 * Joins a video-only file and an audio-only file into one file. Called from Python.
 *  - out path ending in ".webm": VP9 video + Opus audio (used for 1440p / 4K on YouTube)
 *  - anything else: MP4 with H.264 video + AAC audio
 */
object Muxer {

    @JvmStatic
    fun merge(videoPath: String, audioPath: String, outPath: String) {
        val vEx = MediaExtractor()
        val aEx = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            vEx.setDataSource(videoPath)
            aEx.setDataSource(audioPath)
            val vTrack = findTrack(vEx, "video/")
            val aTrack = findTrack(aEx, "audio/")
            require(vTrack >= 0) { "No video track found" }
            require(aTrack >= 0) { "No audio track found" }

            val format = if (outPath.endsWith(".webm", ignoreCase = true))
                MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM
            else
                MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
            muxer = MediaMuxer(outPath, format)

            val vFmt = vEx.getTrackFormat(vTrack)
            if (format == MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4 && vFmt.containsKey(MediaFormat.KEY_ROTATION)) {
                muxer.setOrientationHint(vFmt.getInteger(MediaFormat.KEY_ROTATION))
            }
            val vOut = muxer.addTrack(vFmt)
            val aOut = muxer.addTrack(aEx.getTrackFormat(aTrack))
            vEx.selectTrack(vTrack)
            aEx.selectTrack(aTrack)
            muxer.start()
            started = true
            interleave(vEx, vOut, aEx, aOut, muxer)
            muxer.stop()
            started = false
        } finally {
            try { if (started) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
            vEx.release()
            aEx.release()
        }
    }

    /** Copies just the AAC sound track of a video file into a .m4a file. Called from Python. */
    @JvmStatic
    fun extractAudio(videoPath: String, outPath: String) {
        val ex = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            ex.setDataSource(videoPath)
            val track = findTrack(ex, "audio/")
            require(track >= 0) { "No audio track found" }
            muxer = MediaMuxer(outPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val out = muxer.addTrack(ex.getTrackFormat(track))
            ex.selectTrack(track)
            muxer.start()
            started = true
            val buf = ByteBuffer.allocate(2 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            while (true) {
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                info.set(0, size, ex.sampleTime, MediaCodec.BUFFER_FLAG_KEY_FRAME)
                muxer.writeSampleData(out, buf, info)
                ex.advance()
            }
            muxer.stop()
            started = false
        } finally {
            try { if (started) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
            ex.release()
        }
    }

    private fun findTrack(ex: MediaExtractor, prefix: String): Int {
        for (i in 0 until ex.trackCount) {
            val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith(prefix)) return i
        }
        return -1
    }

    /** Writes whichever stream is earlier in time next, so players can stream the result. */
    private fun interleave(
        vEx: MediaExtractor, vOut: Int,
        aEx: MediaExtractor, aOut: Int,
        muxer: MediaMuxer
    ) {
        // 4K key frames can be large; 12 MB is plenty.
        val buf = ByteBuffer.allocate(12 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        var vDone = false
        var aDone = false
        while (!vDone || !aDone) {
            val vT = if (vDone) Long.MAX_VALUE else vEx.sampleTime
            val aT = if (aDone) Long.MAX_VALUE else aEx.sampleTime
            if (vT < 0) { vDone = true; continue }
            if (aT < 0) { aDone = true; continue }
            val useVideo = !vDone && (aDone || vT <= aT)
            val ex = if (useVideo) vEx else aEx
            val track = if (useVideo) vOut else aOut
            buf.clear()
            val size = ex.readSampleData(buf, 0)
            if (size < 0) {
                if (useVideo) vDone = true else aDone = true
                continue
            }
            val flags = if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0)
                MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
            info.set(0, size, ex.sampleTime, flags)
            muxer.writeSampleData(track, buf, info)
            ex.advance()
        }
    }
}
