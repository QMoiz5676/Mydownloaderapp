package com.mydl.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** Small native home-screen controls for the active Vidora media session. */
object PlayerWidgetViews {
    @Volatile private var currentTitle = "Open Vidora to play media"
    @Volatile private var currentSub = "Audio and video controls"
    @Volatile private var isPlaying = false

    fun updateState(context: Context, title: String, sub: String, playing: Boolean) {
        currentTitle = title.ifBlank { "Vidora Player" }
        currentSub = sub
        isPlaying = playing
        update(context, AudioPlayerWidget::class.java, "Audio Player")
        update(context, VideoPlayerWidget::class.java, "Video Player")
    }

    fun update(context: Context, provider: Class<out AppWidgetProvider>, label: String) {
        val manager = AppWidgetManager.getInstance(context)
        val component = ComponentName(context, provider)
        val ids = manager.getAppWidgetIds(component)
        if (ids.isEmpty()) return
        val views = RemoteViews(context.packageName, R.layout.player_widget)
        views.setTextViewText(R.id.widget_label, label)
        views.setTextViewText(R.id.widget_title, currentTitle)
        views.setTextViewText(R.id.widget_subtitle, currentSub.ifBlank { "Ready when you are" })
        views.setImageViewResource(R.id.widget_play, if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        views.setOnClickPendingIntent(R.id.widget_previous, command(context, "prev", 21))
        views.setOnClickPendingIntent(R.id.widget_play, command(context, "toggle", 22))
        views.setOnClickPendingIntent(R.id.widget_next, command(context, "next", 23))
        views.setOnClickPendingIntent(R.id.widget_open, openApp(context))
        manager.updateAppWidget(ids, views)
    }

    private fun command(context: Context, command: String, request: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            action = "com.mydl.app.WIDGET_$command"
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        return PendingIntent.getActivity(context, request, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun openApp(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(context, 20, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}

class AudioPlayerWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        PlayerWidgetViews.update(context, AudioPlayerWidget::class.java, "Audio Player")
    }
}

class VideoPlayerWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        PlayerWidgetViews.update(context, VideoPlayerWidget::class.java, "Video Player")
    }
}
