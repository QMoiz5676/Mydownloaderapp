package com.mydl.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Delivers Android PiP play/pause actions to the existing WebView player. */
class PipActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val command = when (intent?.action) {
            ACTION_PLAY -> "play"
            ACTION_PAUSE -> "pause"
            else -> return
        }
        MainActivity.mediaCommand?.invoke(command)
    }

    companion object {
        const val ACTION_PLAY = "com.mydl.app.PIP_PLAY"
        const val ACTION_PAUSE = "com.mydl.app.PIP_PAUSE"
    }
}
