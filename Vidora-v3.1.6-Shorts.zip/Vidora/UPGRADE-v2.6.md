# Vidora v2.7 — Shorts, PiP and home-screen controls

## Changes in this source update
- Shorts queue is retained when returning from another app; background/foreground refresh no longer clears the active Shorts item and interrupts playback.
- Shorts playback starts automatically when the first feed item arrives (subject to Android/WebView autoplay policy); tapping a Short retries playback if needed.
- Android system Picture-in-Picture is requested when the user leaves Vidora while media is loaded. The existing in-app mini-player remains available.
- Added native Audio Player and Video Player home-screen widgets with previous, play/pause, next and open-app actions. They control the currently loaded Vidora player.
- Removed the technical Engine panel and yt-dlp implementation details from Settings. Replaced the old About text with user-facing app, privacy and usage information.
- Version updated to 2.7 / versionCode 8.

## Important behavior and limitations
- Android may block autoplay until the user has interacted with the app once; if so, the player displays a clear Play prompt.
- The two home-screen widgets are remote controls for the currently loaded player; they do not independently browse or start arbitrary videos. Open Vidora and start a video/audio item first.
- PiP availability and widget appearance depend on Android launcher/device support.
- Shorts availability, video formats and playback depend on the source platform and network.
- Build and test on a physical Android device before release. The debug signing key cannot update-install over an APK signed with a different private key.
