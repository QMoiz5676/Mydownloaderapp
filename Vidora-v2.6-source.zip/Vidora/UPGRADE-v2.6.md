# Vidora v2.6 upgrade report

## Implemented in source
- Updated Android versionCode to 7 and versionName to 2.6.
- Added native Android PiP entry for active playback.
- Hardened WebView settings and external navigation.
- Scoped cleartext HTTP allowance to the local engine address.
- Added buffering-driven Auto Quality, manual quality persistence, and Data Saver caps.
- Added persistent local watch history, resume metadata, removal, and clear-all.
- Added creator subscriptions keyed by YouTube channel ID and public channel-video retrieval.
- Added a Shorts discovery category with full-screen swipe-up/down playback and short-duration filtering.
- Added manual recommendation-region selection and subscription names as feed signals.
- Added source-provided WebVTT subtitle discovery and playback.
- Re-synchronizes audio after video seek completion and pauses audio on video errors.
- Validates downloaded media tracks and rejects library files whose size differs from metadata.
- Removed hardcoded signing passwords and excluded the private keystore from this deliverable.

## Not complete / requires device or source validation
- Shorts: full-screen swipe-up/down playback is implemented, but search results may omit dimensions, so portrait-only filtering cannot be guaranteed. Source-specific likes are not implemented.
- Auto quality is a buffer-health heuristic, not direct throughput measurement.
- Captions require source-provided WebVTT tracks; other formats are not converted.
- Active download pause/resume is not implemented.
- PiP, playback, decoder compatibility, long-session stability, and memory behaviour require real Android device testing.
- Subscriptions rely on public channel pages and may fail when YouTube blocks extraction.

## Verification performed
- Python backend compiled with `py_compile`.
- Embedded JavaScript passed `node --check`.
- AndroidManifest.xml and network_security_config.xml parsed successfully as XML.
- Full Android Gradle build was not run: Gradle and Android SDK are not installed in the execution environment.
