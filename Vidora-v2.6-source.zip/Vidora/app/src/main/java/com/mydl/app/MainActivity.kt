package com.mydl.app

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.net.Uri
import android.util.Rational
import android.content.ActivityNotFoundException
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.os.Build
import android.graphics.Color
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

/**
 * Chromium pauses <video> / hides the page as soon as the WebView's window becomes invisible
 * (home button, screen off). While something is loaded in the player we tell the WebView it is
 * still visible, so playback simply continues in the background (the foreground media service
 * keeps the process alive and shows the controls).
 */
class BgWebView(ctx: Context) : WebView(ctx) {
    @Volatile
    var keepPlaying = false

    override fun onWindowVisibilityChanged(visibility: Int) {
        if (keepPlaying && visibility != View.VISIBLE) {
            super.onWindowVisibilityChanged(View.VISIBLE)
        } else {
            super.onWindowVisibilityChanged(visibility)
        }
    }
}

class MainActivity : AppCompatActivity() {

    companion object {
        /** Notification / lock-screen / headset buttons -> the web player (set while the activity lives). */
        @Volatile
        var mediaCommand: ((String) -> Unit)? = null
    }

    private lateinit var web: BgWebView
    private lateinit var root: FrameLayout
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var pageLoaded = false
    private var pendingShare: String? = null
    @Volatile private var playbackActive = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#000000")) }
        web = BgWebView(this)
        root.addView(web, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            cacheMode = WebSettings.LOAD_DEFAULT
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                safeBrowsingEnabled = true
            }
        }
        // the renderer keeps high priority, so Android does not kill it while sound plays in the background
        web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
        mediaCommand = { cmd ->
            runOnUiThread {
                web.evaluateJavascript("window.mediaCmd && window.mediaCmd(${JSONObject.quote(cmd)})", null)
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            private fun isLocal(url: String?): Boolean {
                val u = Uri.parse(url ?: return false)
                return u.scheme == "http" && u.host == "127.0.0.1" && u.port == 5000
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: android.webkit.WebResourceRequest?): Boolean {
                val target = request?.url?.toString() ?: return true
                if (isLocal(target)) return false
                val uri = Uri.parse(target)
                if (uri.scheme == "https" || uri.scheme == "http") {
                    try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: ActivityNotFoundException) {}
                }
                return true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                pageLoaded = true
                deliverShare()
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                customView = view
                customCallback = callback
                web.visibility = View.GONE
                root.addView(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            }

            override fun onHideCustomView() {
                customView?.let { root.removeView(it) }
                customView = null
                customCallback?.onCustomViewHidden()
                web.visibility = View.VISIBLE
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) {
                    web.webChromeClient?.onHideCustomView()
                    return
                }
                web.evaluateJavascript("(window.onBack && window.onBack()) === true") { handled ->
                    if (handled != "true") moveTaskToBack(true)
                }
            }
        })

        // Android 13+: ask once so the "downloading" notification can be shown
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        readShare(intent)
        startServer()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && web.keepPlaying && playbackActive && !isInPictureInPictureMode) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } catch (_: IllegalStateException) {
                // PiP may be disabled by the user or unsupported by the current device.
            } catch (_: Exception) {
                // Keep normal background playback fallback on devices which reject PiP.
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (::web.isInitialized) {
            web.evaluateJavascript(
                "document.body.classList.toggle('native-pip', $isInPictureInPictureMode)",
                null
            )
        }
    }

    override fun onDestroy() {
        mediaCommand = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        readShare(intent)
        deliverShare()
    }

    private fun readShare(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type == "text/plain") {
            pendingShare = i.getStringExtra(Intent.EXTRA_TEXT)
        }
    }

    private fun deliverShare() {
        val text = pendingShare ?: return
        if (!pageLoaded) return
        pendingShare = null
        runOnUiThread {
            web.evaluateJavascript("window.onSharedText && window.onSharedText(${JSONObject.quote(text)})", null)
        }
    }

    private fun startServer() {
        Thread {
            try {
                if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                val html = assets.open("index.html").bufferedReader().readText()
                val dir = File(filesDir, "library").absolutePath
                val cache = File(cacheDir, "engine").absolutePath
                val module = Python.getInstance().getModule("server")
                Thread { module.callAttr("start", html, dir, cache) }.start()

                var ready = false
                for (i in 0 until 300) { // poll every 100 ms (was 500 ms): the app opens sooner
                    try {
                        Socket().use { it.connect(InetSocketAddress("127.0.0.1", 5000), 200) }
                        ready = true
                        break
                    } catch (_: Exception) {
                        Thread.sleep(100)
                    }
                }
                runOnUiThread {
                    if (ready) web.loadUrl("http://127.0.0.1:5000/")
                    else Toast.makeText(this, "Could not start the downloader engine", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Start error: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun saveToDownloads(url: String, name: String, mime: String?) {
        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime ?: "application/octet-stream")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Vidora")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Cannot create file")
                contentResolver.openOutputStream(uri)!!.use { out ->
                    conn.inputStream.use { it.copyTo(out) }
                }
                runOnUiThread {
                    Toast.makeText(this, "Copy saved to Downloads/Vidora", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    /** Functions the web UI can call as window.Android.* */
    inner class Bridge {
        @JavascriptInterface
        fun clipboard(): String = try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString() ?: ""
        } catch (_: Exception) {
            ""
        }

        @JavascriptInterface
        fun exportFile(id: String, name: String, mime: String) {
            saveToDownloads("http://127.0.0.1:5000/api/file/$id", name, mime)
        }

        @JavascriptInterface
        fun setLandscape(on: Boolean) {
            runOnUiThread {
                requestedOrientation = if (on) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }

        @JavascriptInterface
        fun immersive(on: Boolean) {
            runOnUiThread {
                val c = WindowCompat.getInsetsController(window, window.decorView)
                if (on) {
                    c.hide(WindowInsetsCompat.Type.systemBars())
                    c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                } else {
                    c.show(WindowInsetsCompat.Type.systemBars())
                }
            }
        }

        /** Old bridge call (kept so an older web UI still works). */
        @JavascriptInterface
        fun setBusy(on: Boolean, text: String) {
            val playing = text.startsWith("Playing")
            setState(if (on && !playing) 1 else 0, on && playing, on && playing, "", "", text)
        }

        /**
         * Called by the web UI whenever downloads or the player change.
         * media = something is loaded in the player (playing or paused).
         */
        @JavascriptInterface
        fun setState(downloads: Int, media: Boolean, playing: Boolean, title: String, sub: String, text: String) {
            web.keepPlaying = media
            playbackActive = media && playing
            runOnUiThread {
                try {
                    val i = Intent(this@MainActivity, KeepAliveService::class.java)
                    if (downloads > 0 || media) {
                        i.putExtra(KeepAliveService.EXTRA_DOWNLOADS, downloads)
                        i.putExtra(KeepAliveService.EXTRA_MEDIA, media)
                        i.putExtra(KeepAliveService.EXTRA_PLAYING, playing)
                        i.putExtra(KeepAliveService.EXTRA_TITLE, title)
                        i.putExtra(KeepAliveService.EXTRA_SUB, sub)
                        i.putExtra(KeepAliveService.EXTRA_TEXT, text.ifEmpty { "Working…" })
                        // already running = just update it (allowed from the background too)
                        if (KeepAliveService.running) startService(i) else startForegroundService(i)
                    } else if (KeepAliveService.running) {
                        i.action = KeepAliveService.ACTION_STOP
                        startService(i)
                    }
                } catch (_: Exception) {
                    // not allowed right now (app in background before the service was started)
                }
            }
        }

        @JavascriptInterface
        fun share(text: String) {
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(send, null))
            }
        }
    }
}
