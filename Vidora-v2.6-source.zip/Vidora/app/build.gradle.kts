plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.mydl.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mydl.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 7
        versionName = "2.6"
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    // Optional stable signing key. Never store signing secrets in source control.
    // Signing secrets must be supplied through Gradle properties or environment variables.
    // If they are absent, Android's normal debug signing is used.
    val vidoraStorePassword = project.providers.gradleProperty("VIDORA_STORE_PASSWORD").orNull
        ?: System.getenv("VIDORA_STORE_PASSWORD")
    val vidoraKeyPassword = project.providers.gradleProperty("VIDORA_KEY_PASSWORD").orNull
        ?: System.getenv("VIDORA_KEY_PASSWORD")
    val vidoraKeyAlias = project.providers.gradleProperty("VIDORA_KEY_ALIAS").orNull
        ?: System.getenv("VIDORA_KEY_ALIAS")
    if (!vidoraStorePassword.isNullOrBlank() && !vidoraKeyPassword.isNullOrBlank() &&
        !vidoraKeyAlias.isNullOrBlank() && file("vidora-debug.p12").exists()) {
        signingConfigs {
            create("vidora") {
                storeFile = file("vidora-debug.p12")
                storePassword = vidoraStorePassword
                keyAlias = vidoraKeyAlias
                keyPassword = vidoraKeyPassword
                storeType = "pkcs12"
            }
        }
        buildTypes {
            getByName("debug") { signingConfig = signingConfigs.getByName("vidora") }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

chaquopy {
    defaultConfig {
        version = "3.12"
        pip {
            install("flask")
            install("yt-dlp")
            install("requests")
        }
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.13.1")
}
