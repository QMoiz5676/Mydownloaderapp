# Vidora v3.3.9 — WorkManager import fix

The GitHub Actions compiler log for v3.3.8 reports `Unresolved reference: WorkManager` in `MainActivity.kt`. The subsequent `forEach`, `id`, `state`, `put`, `progress`, `inputData`, and `outputData` errors are cascading because the receiver type cannot be resolved.

Fix:
- Import `androidx.work.WorkManager` in `MainActivity.kt`.
- Keep the existing `androidx.work:work-runtime-ktx:2.9.1` dependency.
- Increment app version to 3.3.9 / versionCode 22.

This source patch has not been verified by a full Android Gradle build. Run the GitHub Actions workflow to check for any further independent compiler errors.
