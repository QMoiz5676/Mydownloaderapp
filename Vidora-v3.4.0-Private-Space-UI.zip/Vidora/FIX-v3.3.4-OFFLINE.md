# Vidora v3.3.4 — Offline screen, no sideways scrolling

## Problem (from your recording)
With no network, a very long error text ("Could not load videos: query ... Failed to resolve 'www.youtube.com' ...")
was wider than the screen, so the whole Home page slid left and right.

## Changes
- No sideways page scrolling anywhere: `overflow-x:hidden` on the page and every view, and long text always wraps.
  (The category chips still scroll sideways inside their own row, as before.)
- Offline detection from Android itself (`Bridge.isOnline`) plus an instant callback when the phone goes
  online/offline (`watchNetwork` -> `window.onNetChange`), with a 5 s safety check. New permission:
  `ACCESS_NETWORK_STATE`.
- Home and Shorts: when offline (or when the failure is a DNS/"no address" error) the raw error is replaced by a
  clean "Connect to the network" screen with a **Network settings** button (opens Android's network settings,
  fallback: main Settings) and **Try again**.
- A red "Current network is unavailable! — Network settings ›" bar appears under the Home header while
  offline. The shortcut grid, the welcome card and the clipboard banner are hidden while offline, so only the
  message and the button remain.
- When the connection returns, a failed Home feed or an empty Shorts screen reloads by itself.
- Other long error messages are cut to 140–160 characters.

## Not verified
No APK build or device test here (JavaScript syntax check only).
