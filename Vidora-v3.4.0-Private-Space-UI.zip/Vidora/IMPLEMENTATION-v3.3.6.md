# Vidora v3.3.6 — Native feature implementation

This update adds Kotlin Android implementations and a WebView-accessible native panel.

## Implemented

### Private Vault
- AES-256-GCM file encryption with a non-exportable Android Keystore AES key.
- Per-file random 96-bit GCM nonce and file-ID authenticated associated data.
- PIN verifier derived with PBKDF2-HMAC-SHA256 (310,000 iterations, unique 128-bit salt); constant-time verifier comparison.
- PIN change requires the current PIN.
- SAF document picker import, encrypted app-private storage, authenticated listing/deletion, and PIN-protected SAF export.
- Vault ciphertext and PIN verifier preferences excluded from cloud backup and device transfer.
- Temporary decrypted cache files are removed on vault initialization and after successful export.

### Local Media Library
- MediaStore video/audio queries through ContentResolver.
- Runtime permission requests for Android 10–14 permission models.
- Content URIs and metadata (duration, size, modified time, relative path, resolution, album and artist).
- Folder grouping for video and artist/album grouping for audio in the native panel.

### Advanced Download Manager
- WorkManager unique work requests, persistent work database, connected-network constraint, exponential retry/backoff and foreground notifications.
- Worker bootstraps the existing Chaquopy Python server when necessary, calls the existing `/api/download` endpoint with the selected format key, and polls `/api/progress`.
- The existing yt-dlp extraction and video/audio merge code remains the download engine; existing UI quality/audio format selection is passed to WorkManager.
- Active queue state is restored from WorkManager after the WebView reloads; cancellation is wired to both WorkManager and the Python job.
- Downloaded items remain in the existing Vidora library.

## Current limitations / next pass

- The queue has cancellation and automatic retry, but does not yet implement a true pause/resume control. yt-dlp job cancellation currently stops the backend job; resuming safely requires resumable checkpoint support in the Python engine.
- The Private Vault supports secure import, authenticated listing/deletion and export. It does not yet include in-app media preview or biometric unlock.
- Local MediaStore results are scanned on demand; a ContentObserver-based live refresh, paging UI, richer search/sort filters and direct handoff into the player remain follow-up work.
- A PIN is an app-level access gate; Android Keystore protects the AES key. This is not protection against a fully compromised/rooted device or malicious code executing inside the app process.

## Validation

- Embedded JavaScript syntax: `node --check` passed.
- Android XML resources and manifest: XML parsing passed.
- A Gradle/Android build was **not run in this environment** because this archive has no Gradle wrapper script and the environment has no installed Gradle/Android SDK. Use the included GitHub Actions workflow or run `gradle :app:assembleDebug` with Java 17, Android SDK 34 and Python 3.12. Do not treat this source package as a tested installable APK until that build succeeds.
