# Vidora v3.3.3 — Snapchat error and missing video qualities on other sites

## Snapchat "Unable to extract next.js data" / "No response from the site"
- Cause: yt-dlp's Snapchat reader no longer understands Snapchat's page. This is a yt-dlp/site problem, not a
  link problem.
- Fix: when a non-YouTube site's reader fails or finds no video, Vidora now reads the page's own `og:video`
  tag (the direct MP4 that the Snapchat share page still contains) and uses it for play, download and sound.
  Offline test: a Snapchat-style page gives a "540p" video choice plus an Audio choice, and it can be streamed.

## Only Audio shown on Instagram and other platforms
- Cause: many sites give files with no codec information. They were treated as "not video", so only the audio
  track was listed.
- Fix: such files are now recognised as normal video files; the quality is read from the size or the name
  ("720p", "hd", "sd"). A progressive file with unknown sound is offered as a one-file download when the site has
  no separate audio streams. If nothing can be listed, "Best quality" is still added (v3.3.2).

## Limits
- Instagram, Facebook and Snapchat sometimes require a login or block phones; the page then has no video
  tag and no download is possible (private or login-only content, as stated in the README).
- Not verified on a device: no APK build here. Python syntax and offline option tests passed.
