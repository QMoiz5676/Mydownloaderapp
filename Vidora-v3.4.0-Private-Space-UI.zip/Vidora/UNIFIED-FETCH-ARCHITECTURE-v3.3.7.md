# Vidora v3.3.7 — Unified YouTube Fetch Architecture

## Provider order

### Feed and search metadata
1. **InnerTube** — anonymous YouTube internal search endpoint; normalized into Vidora's existing feed item schema.
2. **Piped** — fallback search endpoint using configured public Piped API instances.
3. **yt-dlp** — last-resort search provider; existing feed ranking and pagination code continues to consume the same item shape.

### Stream metadata
1. **NewPipe Extractor** — bundled Android library; Kotlin bridge calls the extractor off the UI thread and returns direct audio/video format metadata.
2. **Piped** — fallback `/streams/{videoId}` response normalized into the same format model.
3. **yt-dlp** — existing final fallback, preserving current format selection, stream filtering and download behavior.

## Unified Extraction Manager
- Shared cache for successful search results.
- Provider-specific counters and last-error diagnostics at `/api/fetch-status`.
- Provider failures are isolated; the next provider is attempted.
- Existing feed UI and player/download API response schemas are preserved.

## Operational limitations
- InnerTube is a private, undocumented API, not a stable public developer API.
- Public Piped instances can disappear, rate-limit or return incomplete streams.
- NewPipe Extractor may fail on anti-bot challenges or upstream YouTube changes; yt-dlp remains the last fallback.
- This integration does not bypass age gates, private-video restrictions, paid access or platform authorization.
- NewPipe Extractor is GPL-3.0-or-later. Review distribution/license compatibility before shipping Vidora.

## Validation performed on source package
- Python source syntax compiled successfully.
- XML resources/manifest parsed successfully.
- Gradle compilation and device playback tests were not available in this environment; the build must be verified in GitHub Actions/Android Studio before installation.
