# Vidora v3.3.5

## Zooming removed
- Cause: the page allowed pinch / double-tap zoom, and the WebView zoom was on.
- Fix: viewport locked (`maximum-scale=1, user-scalable=no`), `touch-action: pan-x pan-y` on the page, and the
  WebView's own zoom turned off (`setSupportZoom(false)`, no zoom controls).

## Offline icon
- The old icon was a filled path that rendered as broken pieces. Replaced by a clean stroked Wi-Fi-off icon
  (three arcs, a dot and a slash), checked in a rendering.

## Header shaking
- Cause: hiding the logo + search row changed the page height, which moved the scroll position, which toggled
  the header again (a feedback loop; visible as jumping in your recording).
- Fix: the header now slides with a transform (no layout change), only after a real 40 px swipe in one
  direction, and always shows at the top of the page.

## Not verified
No APK build or device test here (syntax check and a rendering of the icon only).
