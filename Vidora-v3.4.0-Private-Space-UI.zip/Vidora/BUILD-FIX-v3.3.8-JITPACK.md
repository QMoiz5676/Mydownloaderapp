# Vidora v3.3.8 — JitPack repository fix

## Build failure addressed
GitHub Actions could not resolve `com.github.teamnewpipe:NewPipeExtractor:v0.27.1` because the dependency was declared but JitPack was not configured in dependency resolution repositories.

## Change
Added `maven { url = uri("https://jitpack.io") }` to `dependencyResolutionManagement.repositories` in `settings.gradle.kts`. Kept the existing NewPipe Extractor coordinate unchanged.

## Verification
The project configuration was inspected and the repository declaration was patched. A successful remote GitHub Actions build has **not** been observed from this environment. Run the workflow again to confirm artifact resolution and then address any subsequent compilation/runtime errors.
