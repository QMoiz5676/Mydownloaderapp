package com.mydl.app

import org.json.JSONArray
import org.json.JSONObject
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.Charset

/**
 * Thin NewPipe Extractor adapter. All extraction is performed on the caller's background thread.
 * Reflection is intentionally used for stream metadata so minor upstream model additions do not
 * break this adapter; required direct stream URLs are still validated before returning.
 */
object NewPipeExtractionBridge {
    @JvmStatic
    fun extractJson(pageUrl: String): String {
        NewPipe.init(object : Downloader() {
            override fun execute(request: Request): Response {
                val connection = (URL(request.url()).openConnection() as HttpURLConnection).apply {
                    requestMethod = request.httpMethod()
                    connectTimeout = 12_000
                    readTimeout = 18_000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", USER_AGENT)
                    setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                    request.headers()?.forEach { (key, values) ->
                        if (!key.equals("Host", true) && !key.equals("Content-Length", true)) {
                            setRequestProperty(key, values.joinToString(","))
                        }
                    }
                }
                request.dataToSend()?.let { bytes ->
                    connection.doOutput = true
                    connection.outputStream.use { it.write(bytes) }
                }
                val code = connection.responseCode
                val bodyStream = if (code >= 400) connection.errorStream else connection.inputStream
                val body = bodyStream?.use { it.readBytes().toString(Charset.forName("UTF-8")) } ?: ""
                val headers = connection.headerFields.filterKeys { it != null }
                    .mapValues { (_, values) -> values ?: emptyList() }
                val response = Response(code, connection.responseMessage ?: "", headers, body, connection.url.toString())
                connection.disconnect()
                return response
            }
        })

        val service = NewPipe.getServiceByUrl(pageUrl)
        val extractor = service.getStreamExtractor(pageUrl)
        extractor.fetchPage()

        val formats = JSONArray()
        fun addStreams(method: String, video: Boolean, audio: Boolean) {
            val list = invoke(extractor, method) as? Iterable<*> ?: return
            var index = 0
            for (stream in list) {
                if (stream == null) continue
                val content = invoke(stream, "getContent")?.toString()?.takeIf { it.startsWith("http") } ?: continue
                val resolution = invoke(stream, "getResolution")?.toString()
                val bitrate = (invoke(stream, "getAverageBitrate") as? Number)?.toInt()
                    ?: (invoke(stream, "getBitrate") as? Number)?.toInt()
                val mime = invoke(stream, "getFormat")?.let { invoke(it, "getMimeType")?.toString() }
                    ?: invoke(stream, "getMimeType")?.toString().orEmpty()
                val ext = when {
                    mime.contains("webm", true) -> "webm"
                    mime.contains("mp4", true) -> "mp4"
                    mime.contains("3gpp", true) -> "3gp"
                    else -> "mp4"
                }
                val height = Regex("(\\d{3,4})p").find(resolution.orEmpty())?.groupValues?.get(1)?.toIntOrNull()
                val codec = invoke(stream, "getCodec")?.toString().orEmpty()
                val f = JSONObject()
                    .put("format_id", "newpipe_${method}_$index")
                    .put("url", content)
                    .put("ext", ext)
                    .put("width", JSONObject.NULL)
                    .put("height", height ?: JSONObject.NULL)
                    .put("vcodec", if (video) (codec.ifBlank { "unknown" }) else "none")
                    .put("acodec", if (audio) (codec.ifBlank { "unknown" }) else "none")
                    .put("abr", if (audio) bitrate ?: JSONObject.NULL else JSONObject.NULL)
                    .put("tbr", bitrate ?: JSONObject.NULL)
                formats.put(f)
                index++
            }
        }
        addStreams("getVideoStreams", video = true, audio = true)
        addStreams("getVideoOnlyStreams", video = true, audio = false)
        addStreams("getAudioStreams", video = false, audio = true)

        val result = JSONObject()
            .put("title", invoke(extractor, "getName")?.toString() ?: "YouTube video")
            .put("uploader", invoke(extractor, "getUploaderName")?.toString() ?: "")
            .put("duration", (invoke(extractor, "getLength") as? Number)?.toLong() ?: 0L)
            .put("thumbnail", invoke(extractor, "getThumbnailUrl")?.toString() ?: "")
            .put("views", (invoke(extractor, "getViewCount") as? Number)?.toLong() ?: 0L)
            .put("formats", formats)
        return result.toString()
    }

    private fun invoke(target: Any, method: String): Any? = try {
        target.javaClass.methods.firstOrNull { it.name == method && it.parameterCount == 0 }?.invoke(target)
    } catch (_: Throwable) { null }

    private const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36"
}
