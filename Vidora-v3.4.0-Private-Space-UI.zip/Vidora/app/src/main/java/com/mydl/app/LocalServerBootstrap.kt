package com.mydl.app

import android.content.Context
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket

/** One process-wide bootstrap shared by the Activity and WorkManager workers. */
object LocalServerBootstrap {
    @Synchronized fun ensure(context: Context) {
        if (ready()) return
        val app = context.applicationContext
        if (!Python.isStarted()) Python.start(AndroidPlatform(app))
        val html = app.assets.open("index.html").bufferedReader().use { it.readText() }
        val library = File(app.filesDir, "library").apply { mkdirs() }.absolutePath
        val cache = File(app.cacheDir, "engine").apply { mkdirs() }.absolutePath
        val module = Python.getInstance().getModule("server")
        Thread({ try { module.callAttr("start", html, library, cache) } catch (_: Exception) { } }, "Vidora-Python-Server").apply {
            isDaemon = true
            start()
        }
        var attempts = 0
        while (!ready() && attempts++ < 150) Thread.sleep(100)
        check(ready()) { "Vidora download engine could not start" }
    }

    private fun ready(): Boolean = try {
        Socket().use { it.connect(InetSocketAddress("127.0.0.1", 5000), 250) }
        true
    } catch (_: Exception) { false }
}
