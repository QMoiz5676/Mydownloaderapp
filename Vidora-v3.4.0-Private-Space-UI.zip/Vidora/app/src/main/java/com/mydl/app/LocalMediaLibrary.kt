package com.mydl.app

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject

class LocalMediaLibrary(private val context: Context) {
    fun scan(kind: String, limit: Int = 500): String {
        val video = kind.equals("video", true)
        val collection: Uri = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = if (video) arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE, MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.RELATIVE_PATH, MediaStore.Video.Media.WIDTH, MediaStore.Video.Media.HEIGHT)
        else arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.RELATIVE_PATH)
        val result = JSONArray()
        val sort = "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        context.contentResolver.query(collection, projection, null, null, sort)?.use { c ->
            var count = 0
            while (c.moveToNext() && count++ < limit.coerceIn(1, 2000)) {
                val id = c.long(MediaStore.MediaColumns._ID)
                val item = JSONObject().put("id", id).put("uri", ContentUris.withAppendedId(collection, id).toString())
                    .put("name", c.string(MediaStore.MediaColumns.DISPLAY_NAME)).put("mime", c.string(MediaStore.MediaColumns.MIME_TYPE))
                    .put("durationMs", c.long(MediaStore.MediaColumns.DURATION)).put("sizeBytes", c.long(MediaStore.MediaColumns.SIZE))
                    .put("modified", c.long(MediaStore.MediaColumns.DATE_MODIFIED)).put("path", c.string(MediaStore.MediaColumns.RELATIVE_PATH))
                if (!video) item.put("album", c.string(MediaStore.Audio.AudioColumns.ALBUM)).put("artist", c.string(MediaStore.Audio.AudioColumns.ARTIST))
                else item.put("width", c.long(MediaStore.Video.VideoColumns.WIDTH)).put("height", c.long(MediaStore.Video.VideoColumns.HEIGHT))
                result.put(item)
            }
        }
        return JSONObject().put("kind", if (video) "video" else "audio").put("count", result.length()).put("items", result).toString()
    }

    private fun Cursor.long(name: String): Long = try { getLong(getColumnIndexOrThrow(name)) } catch (_: Exception) { 0L }
    private fun Cursor.string(name: String): String = try { getString(getColumnIndexOrThrow(name)) ?: "" } catch (_: Exception) { "" }
}
