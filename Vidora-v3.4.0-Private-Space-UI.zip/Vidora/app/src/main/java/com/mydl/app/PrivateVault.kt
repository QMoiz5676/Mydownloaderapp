package com.mydl.app

import android.content.Context
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.File
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec

/** Encrypted app-private vault. SAF is used only as the import boundary; stored blobs are AES-GCM ciphertext. */
class PrivateVault(private val context: Context) {
    private val prefs = context.getSharedPreferences("private_vault", Context.MODE_PRIVATE)
    private val dir = File(context.filesDir, "vault_ciphertext").apply { mkdirs() }
    private val alias = "vidora_private_vault_aes"
    private val random = SecureRandom()
    init { context.cacheDir.listFiles()?.filter { it.name.startsWith("vault_") && it.name.endsWith(".tmp") }?.forEach { it.delete() } }

    @Synchronized fun setPin(pin: String) {
        require(!hasPin()) { "Vault PIN already exists; verify the old PIN to change it" }
        require(pin.length in 4..12 && pin.all(Char::isDigit)) { "Password must be 4–12 digits" }
        val salt = ByteArray(16).also(random::nextBytes)
        val hash = derive(pin, salt)
        getOrCreateKey()
        prefs.edit().putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", Base64.encodeToString(hash, Base64.NO_WRAP)).apply()
    }

    fun hasPin(): Boolean = prefs.contains("pin_hash")

    fun verifyPin(pin: String): Boolean = if (pin.length !in 4..12 || !pin.all(Char::isDigit)) false else try {
        val salt = Base64.decode(prefs.getString("pin_salt", "")!!, Base64.NO_WRAP)
        val expected = Base64.decode(prefs.getString("pin_hash", "")!!, Base64.NO_WRAP)
        MessageDigest.isEqual(expected, derive(pin, salt))
    } catch (_: Exception) { false }


    @Synchronized fun changePin(oldPin: String, newPin: String) {
        require(verifyPin(oldPin)) { "Incorrect current PIN" }
        require(newPin.length in 4..12 && newPin.all(Char::isDigit)) { "Password must be 4–12 digits" }
        val salt = ByteArray(16).also(random::nextBytes)
        val hash = derive(newPin, salt)
        prefs.edit().putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", Base64.encodeToString(hash, Base64.NO_WRAP)).apply()
    }

    /** Import selected SAF content into the encrypted vault. Returns an opaque vault ID. */
    @Synchronized fun importFile(uri: Uri, displayName: String): String {
        check(hasPin()) { "Set a vault PIN first" }
        val id = java.util.UUID.randomUUID().toString()
        val nonce = ByteArray(12).also(random::nextBytes)
        val target = File(dir, "$id.vlt")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, nonce))
        cipher.updateAAD(id.toByteArray(Charsets.UTF_8))
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { raw ->
                    raw.write(byteArrayOf('V'.code.toByte(), 'L'.code.toByte(), 'T'.code.toByte(), 1))
                    raw.write(nonce)
                    javax.crypto.CipherOutputStream(raw, cipher).use { encrypted -> input.copyTo(encrypted) }
                }
            } ?: throw IllegalStateException("Cannot open selected file")
            prefs.edit().putString("name_$id", displayName.take(180)).apply()
            return id
        } catch (e: Exception) { target.delete(); throw e }
    }

    /** Decrypts only after caller has authenticated the PIN; output remains in app cache. */
    @Synchronized fun decryptToCache(id: String, pin: String): File {
        check(verifyPin(pin)) { "Incorrect PIN" }
        require(id.matches(Regex("[a-f0-9-]{36}"))) { "Invalid vault item" }
        val source = File(dir, "$id.vlt")
        require(source.isFile) { "Vault item not found" }
        val out = File(context.cacheDir, "vault_${id}.tmp")
        try {
            source.inputStream().use { raw ->
                val header = ByteArray(16); java.io.DataInputStream(raw).readFully(header)
                require(header[0] == 'V'.code.toByte() && header[1] == 'L'.code.toByte() && header[2] == 'T'.code.toByte() && header[3] == 1.toByte()) { "Invalid vault file" }
                val nonce = header.copyOfRange(4, 16)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, nonce))
                cipher.updateAAD(id.toByteArray(Charsets.UTF_8))
                javax.crypto.CipherInputStream(raw, cipher).use { input -> out.outputStream().use { input.copyTo(it) } }
            }
            return out
        } catch (e: Exception) { out.delete(); throw e }
    }

    fun list(): List<Map<String, String>> = dir.listFiles()?.filter { it.extension == "vlt" }?.map {
        val id = it.nameWithoutExtension
        mapOf("id" to id, "name" to (prefs.getString("name_$id", "Private media") ?: "Private media"), "bytes" to it.length().toString())
    } ?: emptyList()

    @Synchronized fun delete(id: String) {
        require(id.matches(Regex("[a-f0-9-]{36}")))
        File(dir, "$id.vlt").delete(); prefs.edit().remove("name_$id").apply()
    }

    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 310_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded } finally { spec.clearPassword() }
    }

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).setRandomizedEncryptionRequired(true).build())
        return gen.generateKey()
    }
}
