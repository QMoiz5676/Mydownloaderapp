package com.mydl.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.WorkManager
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.Constraints
import androidx.work.workDataOf
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.UUID
import java.util.concurrent.TimeUnit

/** WorkManager wrapper around Vidora's existing Python/yt-dlp API. */
class VidoraDownloadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    @Volatile private var backendJob: String? = null

    override suspend fun doWork(): Result {
        val source = inputData.getString(KEY_URL) ?: return Result.failure()
        val formatKey = inputData.getString(KEY_FORMAT_KEY) ?: ""
        val titleHint = inputData.getString(KEY_TITLE) ?: "Vidora download"
        return try {
            setForeground(foreground("Starting $titleHint", 0, true))
            ensureBackend()
            val body = JSONObject().put("url", source).put("key", formatKey)
            val started = request("POST", "/api/download", body.toString())
            val jid = started.getString("id")
            backendJob = jid
            while (!isStopped) {
                val p = request("GET", "/api/progress/$jid")
                val status = p.optString("status")
                val progress = p.optDouble("progress", 0.0).toInt().coerceIn(0, 100)
                val title = p.optString("title").ifBlank { titleHint }
                setProgress(workDataOf("progress" to progress, "title" to title, "status" to status, "quality" to p.optString("quality")))
                setForeground(foreground("$title · ${progress}%", progress, false))
                when (status) {
                    "done" -> return Result.success(workDataOf("item" to p.optJSONObject("item")?.toString().orEmpty(), "title" to title, "quality" to p.optString("quality")))
                    "error" -> return Result.failure(workDataOf("error" to p.optString("err", "Download failed")))
                    "cancelled" -> return Result.failure(workDataOf("error" to "Cancelled"))
                }
                kotlinx.coroutines.delay(900)
            }
            backendJob?.let { request("POST", "/api/cancel/$it", "{}") }
            Result.failure(workDataOf("error" to "Cancelled"))
        } catch (e: Exception) {
            if (isStopped) {
                backendJob?.let { try { request("POST", "/api/cancel/$it", "{}") } catch (_: Exception) { } }
                Result.failure(workDataOf("error" to "Cancelled"))
            } else if (runAttemptCount < 3) Result.retry()
            else Result.failure(workDataOf("error" to (e.message ?: "Download failed")))
        }
    }

    private fun ensureBackend() { LocalServerBootstrap.ensure(applicationContext) }

    private fun request(method: String, path: String, body: String? = null): JSONObject {
        val c = (URL("http://127.0.0.1:5000$path").openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 15_000; readTimeout = 20_000
            if (body != null) { doOutput = true; setRequestProperty("Content-Type", "application/json; charset=utf-8") }
        }
        try {
            if (body != null) c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (c.responseCode !in 200..299) throw IllegalStateException("Download engine HTTP ${c.responseCode}: ${text.take(240)}")
            return JSONObject(text)
        } finally { c.disconnect() }
    }

    private fun foreground(title: String, progress: Int, indeterminate: Boolean): ForegroundInfo {
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, "Vidora downloads", NotificationManager.IMPORTANCE_LOW))
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle(title).setOngoing(true).setOnlyAlertOnce(true)
            .setProgress(100, progress, indeterminate).build()
        return ForegroundInfo(4107 + (id.hashCode() and 0x3fff), notification)
    }

    companion object {
        const val KEY_URL = "url"; const val KEY_FORMAT_KEY = "format_key"; const val KEY_TITLE = "title"; const val CHANNEL = "vidora_downloads"
    }
}

object VidoraDownloads {
    fun enqueue(context: Context, url: String, formatKey: String = "", title: String = "Vidora download"): String {
        require(url.startsWith("https://") || url.startsWith("http://")) { "Only HTTP(S) URLs are supported" }
        val request = OneTimeWorkRequestBuilder<VidoraDownloadWorker>().setInputData(workDataOf(
            VidoraDownloadWorker.KEY_URL to url, VidoraDownloadWorker.KEY_FORMAT_KEY to formatKey, VidoraDownloadWorker.KEY_TITLE to title))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .addTag("vidora_downloads").build()
        WorkManager.getInstance(context).enqueueUniqueWork("vidora_download_${request.id}", ExistingWorkPolicy.KEEP, request)
        return request.id.toString()
    }
    fun cancel(context: Context, id: String) { WorkManager.getInstance(context).cancelWorkById(UUID.fromString(id)) }
}
