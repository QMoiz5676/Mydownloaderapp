# Vidora v3.3.2

## 1. Video qualities missing in the Download sheet (only Audio shown)
- Cause: some videos (often Shorts) come from YouTube as HLS streams only. The app threw every HLS format
  away, so only the one audio-only stream was left.
- Now: muxed HLS formats are listed as video choices (yt-dlp downloads them itself); a normal MP4/merged choice
  for the same quality still wins. If no quality can be listed at all, a "Best quality" video entry is added.
  The Download sheet can no longer be audio-only.
- Same cause behind many "This Short could not be played": for short clips (<= 200 s) that have no normal
  stream, the server now downloads the small clip once and plays it from the phone (seekable).

## 2. Home search bar
- Logo and search field are now ONE header row (the "Vidora" text next to the logo was removed to make room).
- Scrolling down slides that row away and keeps only the category chips; scrolling up (or tapping the
  search again) brings it back.

## 3. Theme "Match phone"
- Cause: the WebView often reports "light" even when the phone is in dark mode.
- Now the app asks Android itself (Bridge.isDark) and is told when the phone switches (uiMode config change +
  onSystemTheme), so Match phone follows the phone instantly without restarting.

## Not verified
No APK build or device test here. Python and JavaScript syntax checks passed, and the download-option builder
was tested offline with HLS-only and audio-only inputs (video choices appear in both cases).
