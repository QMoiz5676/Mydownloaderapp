pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // NewPipe Extractor is published under the com.github.teamnewpipe coordinate on JitPack.
        maven { url = uri("https://jitpack.io") }
    }
}
rootProject.name = "Vidora"
include(":app")
