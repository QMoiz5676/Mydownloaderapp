# Vidora v3.3.9 — Shorts Unified Playback Fix

## Changes
- Shorts playback now requests `/api/info` before selecting a stream, matching the Home Feed's shared extraction path.
- Shorts chooses an available quality from the extracted `play` formats instead of assuming every Short supports 720p.
- When extraction reports separate video/audio streams, Shorts uses `vonly` + `audio` at the selected resolution, synchronized by the existing player logic.
- When extraction reports a muxed stream, Shorts uses the muxed `video` stream.
- Pending extraction requests are invalidated when a Shorts page is dropped, preventing an old request from attaching playback to a recycled page.
- Existing vertical swipe UI, feed endpoint, and Home Feed behavior are preserved.

## Root cause identified
The Home Feed uses the shared `/api/info` extraction result and selects a compatible stream using the available format metadata. The Shorts pager had a separate playback implementation that skipped `/api/info`, hardcoded 720p, and attempted a muxed stream first before falling back to split streams after a delay. That mismatch could request a stream mode/quality that was not actually available for a given Short.

## Validation
- Source-level JavaScript syntax check: passed with Node.js `--check`.
- Python backend syntax compilation: passed.
- Android XML resource parsing: passed.
- Android Gradle build and on-device playback test: not run in this environment.
- Test at least: muxed-only Short, split audio/video Short, lower-than-720p Short, expired stream URL, and network interruption/retry.
