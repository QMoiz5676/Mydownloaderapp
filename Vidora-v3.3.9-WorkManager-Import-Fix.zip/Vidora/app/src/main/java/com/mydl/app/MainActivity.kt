package com.mydl.app

import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.provider.Settings
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.graphics.Color
import android.os.Bundle
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.app.PendingIntent
import android.content.pm.ActivityInfo
import android.graphics.drawable.Icon
import android.util.Rational
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.work.WorkManager
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Chromium pauses <video> / hides the page as soon as the WebView's window becomes invisible
 * (home button, screen off). While something is loaded in the player we tell the WebView it is
 * still visible, so playback simply continues in the background (the foreground media service
 * keeps the process alive and shows the controls).
 */
class BgWebView(ctx: Context) : WebView(ctx) {
    @Volatile
    var keepPlaying = false

    override fun onWindowVisibilityChanged(visibility: Int) {
        if (keepPlaying && visibility != View.VISIBLE) {
            super.onWindowVisibilityChanged(View.VISIBLE)
        } else {
            super.onWindowVisibilityChanged(visibility)
        }
    }
}

class MainActivity : AppCompatActivity() {

    companion object {
        /** Notification / lock-screen / headset buttons -> the web player (set while the activity lives). */
        @Volatile
        var mediaCommand: ((String) -> Unit)? = null
    }

    private lateinit var web: BgWebView
    private lateinit var root: FrameLayout
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var pageLoaded = false
    private var pendingShare: String? = null
    private val vault by lazy { PrivateVault(this) }
    private val localLibrary by lazy { LocalMediaLibrary(this) }
    private var pendingVaultExportId: String? = null
    private var pendingVaultExportPin: String? = null
    private var pendingWidgetCommand: String? = null
    @Volatile private var pipVideoLoaded = false
    @Volatile private var pipVideoPlaying = false
    @Volatile private var pipAspectWidth = 16
    @Volatile private var pipAspectHeight = 9

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#000000")) }
        web = BgWebView(this)
        root.addView(web, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
        }
        // the renderer keeps high priority, so Android does not kill it while sound plays in the background
        web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
        mediaCommand = { cmd ->
            runOnUiThread {
                web.evaluateJavascript("window.mediaCmd && window.mediaCmd(${JSONObject.quote(cmd)})", null)
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        watchNetwork()
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageLoaded = true
                deliverShare()
                deliverWidgetCommand()
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                customView = view
                customCallback = callback
                web.visibility = View.GONE
                root.addView(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            }

            override fun onHideCustomView() {
                customView?.let { root.removeView(it) }
                customView = null
                customCallback?.onCustomViewHidden()
                web.visibility = View.VISIBLE
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) {
                    web.webChromeClient?.onHideCustomView()
                    return
                }
                web.evaluateJavascript("(window.onBack && window.onBack()) === true") { handled ->
                    if (handled != "true") moveTaskToBack(true)
                }
            }
        })

        // Android 13+: ask once so the "downloading" notification can be shown
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        readShare(intent)
        readWidgetCommand(intent)
        startServer()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // PiP is video-only: an actually playing video must be reported by the web player.
        // Audio-only playback deliberately remains in the existing background-audio path.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            Build.VERSION.SDK_INT < Build.VERSION_CODES.S &&
            pipVideoLoaded && pipVideoPlaying
        ) {
            try {
                enterPictureInPictureMode(buildPipParams())
            } catch (_: Exception) {
                // Some devices/launchers disallow PiP or the current transition.
            }
        }
    }

    private fun buildPipParams(): PictureInPictureParams {
        val builder = PictureInPictureParams.Builder()
            .setAspectRatio(Rational(pipAspectWidth, pipAspectHeight))
            .setActions(listOf(pipAction()))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setAutoEnterEnabled(pipVideoLoaded && pipVideoPlaying)
        }
        return builder.build()
    }

    private fun pipAction(): RemoteAction {
        val playing = pipVideoPlaying
        val intent = Intent(this, PipActionReceiver::class.java).apply {
            action = if (playing) PipActionReceiver.ACTION_PAUSE else PipActionReceiver.ACTION_PLAY
        }
        val pending = PendingIntent.getBroadcast(
            this, 4101, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val icon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val label = if (playing) "Pause" else "Play"
        return RemoteAction(Icon.createWithResource(this, icon), label, label, pending)
    }

    private fun updatePipParams() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || !::web.isInitialized) return
        runOnUiThread {
            try {
                setPictureInPictureParams(buildPipParams())
            } catch (_: Exception) { }
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: android.content.res.Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (::web.isInitialized && pageLoaded) {
            val value = if (isInPictureInPictureMode) "true" else "false"
            web.evaluateJavascript("window.onNativePipModeChanged && window.onNativePipModeChanged($value)", null)
        }
    }

    private var netCb: ConnectivityManager.NetworkCallback? = null

    /** Tell the web UI at once when the phone goes offline / online (it shows the "Connect to the network" screen). */
    private fun watchNetwork() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) = pushNet()
                override fun onLost(network: Network) = pushNet()
            }
            cm.registerDefaultNetworkCallback(cb)
            netCb = cb
        } catch (_: Exception) {
        }
    }

    private fun pushNet() {
        runOnUiThread {
            if (::web.isInitialized && pageLoaded) {
                web.evaluateJavascript("window.onNetChange && window.onNetChange()", null)
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // phone switched between light and dark: tell the web UI so "Match phone" follows it
        if (::web.isInitialized && pageLoaded) {
            web.evaluateJavascript("window.onSystemTheme && window.onSystemTheme()", null)
        }
    }

    override fun onDestroy() {
        try {
            netCb?.let { (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) }
        } catch (_: Exception) {
        }
        mediaCommand = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readShare(intent)
        readWidgetCommand(intent)
        deliverShare()
        deliverWidgetCommand()
    }

    private fun readWidgetCommand(i: Intent?) {
        val action = i?.action ?: return
        if (!action.startsWith("com.mydl.app.WIDGET_")) return
        pendingWidgetCommand = action.substringAfterLast('_').lowercase()
    }

    private fun deliverWidgetCommand() {
        val command = pendingWidgetCommand ?: return
        if (!pageLoaded) return
        pendingWidgetCommand = null
        web.post {
            web.evaluateJavascript("window.mediaCmd && window.mediaCmd(${JSONObject.quote(command)})", null)
        }
    }

    private fun readShare(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type == "text/plain") {
            pendingShare = i.getStringExtra(Intent.EXTRA_TEXT)
        }
    }

    private fun deliverShare() {
        val text = pendingShare ?: return
        if (!pageLoaded) return
        pendingShare = null
        runOnUiThread {
            web.evaluateJavascript("window.onSharedText && window.onSharedText(${JSONObject.quote(text)})", null)
        }
    }

    private fun startServer() {
        Thread {
            try {
                LocalServerBootstrap.ensure(applicationContext)
                runOnUiThread { web.loadUrl("http://127.0.0.1:5000/") }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Start error: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun saveToDownloads(url: String, name: String, mime: String?) {
        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime ?: "application/octet-stream")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Vidora")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Cannot create file")
                contentResolver.openOutputStream(uri)!!.use { out ->
                    conn.inputStream.use { it.copyTo(out) }
                }
                runOnUiThread {
                    Toast.makeText(this, "Copy saved to Downloads/Vidora", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7403 && resultCode == RESULT_OK) {
            val uri = data?.data
            val id = pendingVaultExportId; val pin = pendingVaultExportPin
            pendingVaultExportId = null; pendingVaultExportPin = null
            if (uri != null && id != null && pin != null) try {
                val temp = vault.decryptToCache(id, pin)
                contentResolver.openOutputStream(uri)?.use { out -> temp.inputStream().use { it.copyTo(out) } }
                temp.delete()
                Toast.makeText(this, "Vault file exported", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(this, "Vault export failed: ${e.message}", Toast.LENGTH_LONG).show() }
        }
        if (requestCode == 7401 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            try {
                val name = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else "Private media" } ?: "Private media"
                val id = vault.importFile(uri, name)
                web.evaluateJavascript("window.VidoraNative && window.VidoraNative.vaultImported(${JSONObject.quote(id)}, ${JSONObject.quote(name)})", null)
            } catch (e: Exception) {
                web.evaluateJavascript("window.VidoraNative && window.VidoraNative.error(${JSONObject.quote(e.message ?: "Vault import failed")})", null)
            }
        }
    }

    /** Functions the web UI can call as window.Android.* */
    inner class Bridge {
        @JavascriptInterface fun vaultHasPin(): Boolean = vault.hasPin()
        @JavascriptInterface fun vaultSetPin(pin: String): Boolean = try { vault.setPin(pin); true } catch (_: Exception) { false }
        @JavascriptInterface fun vaultChangePin(oldPin: String, newPin: String): Boolean = try { vault.changePin(oldPin, newPin); true } catch (_: Exception) { false }
        @JavascriptInterface fun vaultVerifyPin(pin: String): Boolean = vault.verifyPin(pin)
        @JavascriptInterface fun vaultList(pin: String): String = if (vault.verifyPin(pin)) org.json.JSONArray(vault.list()).toString() else "[]"
        @JavascriptInterface fun vaultDelete(id: String, pin: String): Boolean = if (vault.verifyPin(pin)) { vault.delete(id); true } else false
        @JavascriptInterface fun vaultPickImport(pin: String) { if (!vault.verifyPin(pin)) { runOnUiThread { Toast.makeText(this@MainActivity, "Incorrect vault PIN", Toast.LENGTH_SHORT).show() }; return }; runOnUiThread { val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }; startActivityForResult(i, 7401) } }
        @JavascriptInterface fun vaultExport(id: String, pin: String) { if (!vault.verifyPin(pin)) { runOnUiThread { Toast.makeText(this@MainActivity, "Incorrect vault PIN", Toast.LENGTH_SHORT).show() }; return }; pendingVaultExportId=id; pendingVaultExportPin=pin; runOnUiThread { val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="application/octet-stream"; putExtra(Intent.EXTRA_TITLE, "Vidora-private-media.bin") }; startActivityForResult(i, 7403) } }
        @JavascriptInterface fun scanLocalMedia(kind: String, limit: Int): String = try { localLibrary.scan(kind, limit) } catch (e: Exception) { JSONObject().put("error", e.message ?: "Media scan failed").toString() }
        @JavascriptInterface fun requestMediaPermission() { runOnUiThread { val perms = if (Build.VERSION.SDK_INT >= 34) arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) else if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE); requestPermissions(perms, 7402) } }
        @JavascriptInterface fun enqueueManagedDownload(url: String, formatKey: String, title: String): String = try { VidoraDownloads.enqueue(this@MainActivity, url, formatKey, title) } catch (e: Exception) { "ERROR:${e.message}" }
        @JavascriptInterface fun cancelManagedDownload(id: String) { try { VidoraDownloads.cancel(this@MainActivity, id) } catch (_: Exception) { } }
        @JavascriptInterface fun managedDownloadStates(): String {
            val arr = JSONArray()
            WorkManager.getInstance(this@MainActivity).getWorkInfosByTag("vidora_downloads").get().forEach { info -> arr.put(JSONObject().put("id", info.id.toString()).put("state", info.state.name).put("progress", info.progress.getInt("progress", 0)).put("title", info.progress.getString("title") ?: info.inputData.getString("title") ?: "").put("error", info.outputData.getString("error") ?: "").put("item", info.outputData.getString("item") ?: "")) }
            return arr.toString()
        }
        @JavascriptInterface
        fun isOnline(): Boolean = try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            true
        }

        @JavascriptInterface
        fun openNetworkSettings() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
                } catch (_: Exception) {
                    try {
                        startActivity(Intent(Settings.ACTION_SETTINGS))
                    } catch (_: Exception) {
                    }
                }
            }
        }

        @JavascriptInterface
        fun isDark(): Boolean =
            (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

        @JavascriptInterface
        fun clipboard(): String = try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this@MainActivity)?.toString() ?: ""
        } catch (_: Exception) {
            ""
        }

        @JavascriptInterface
        fun exportFile(id: String, name: String, mime: String) {
            saveToDownloads("http://127.0.0.1:5000/api/file/$id", name, mime)
        }

        @JavascriptInterface
        fun setLandscape(on: Boolean) {
            runOnUiThread {
                requestedOrientation = if (on) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }

        /** Keep Shorts in portrait even when the source video itself is landscape. */
        @JavascriptInterface
        fun setPortrait(on: Boolean) {
            runOnUiThread {
                requestedOrientation = if (on) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }
        }

        @JavascriptInterface
        fun immersive(on: Boolean) {
            runOnUiThread {
                val c = WindowCompat.getInsetsController(window, window.decorView)
                if (on) {
                    c.hide(WindowInsetsCompat.Type.systemBars())
                    c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                } else {
                    c.show(WindowInsetsCompat.Type.systemBars())
                }
            }
        }

        /** Old bridge call (kept so an older web UI still works). */
        @JavascriptInterface
        fun setBusy(on: Boolean, text: String) {
            val playing = text.startsWith("Playing")
            setState(if (on && !playing) 1 else 0, on && playing, on && playing, "", "", text)
        }

        /** Video-only PiP state. Audio-only mode must always report videoLoaded=false. */
        @JavascriptInterface
        fun setPipState(videoLoaded: Boolean, videoPlaying: Boolean, width: Int, height: Int) {
            val nextPlaying = videoLoaded && videoPlaying
            val w = width.coerceAtLeast(1)
            val h = height.coerceAtLeast(1)
            val ratio = w.toFloat() / h.toFloat()
            // Android PiP accepts aspect ratios from approximately 1:2.39 to 2.39:1.
            val nextW: Int
            val nextH: Int
            if (ratio in (1f / 2.39f)..2.39f) {
                nextW = w
                nextH = h
            } else {
                nextW = 16
                nextH = 9
            }
            val changed = pipVideoLoaded != videoLoaded ||
                pipVideoPlaying != nextPlaying ||
                pipAspectWidth != nextW || pipAspectHeight != nextH
            pipVideoLoaded = videoLoaded
            pipVideoPlaying = nextPlaying
            pipAspectWidth = nextW
            pipAspectHeight = nextH
            if (changed) updatePipParams()
        }

        /**
         * Called by the web UI whenever downloads or the player change.
         * media = something is loaded in the player (playing or paused).
         */
        @JavascriptInterface
        fun setState(downloads: Int, media: Boolean, playing: Boolean, title: String, sub: String, text: String) {
            web.keepPlaying = media
            PlayerWidgetViews.updateState(this@MainActivity, title, sub, playing)
            runOnUiThread {
                try {
                    val i = Intent(this@MainActivity, KeepAliveService::class.java)
                    if (downloads > 0 || media) {
                        i.putExtra(KeepAliveService.EXTRA_DOWNLOADS, downloads)
                        i.putExtra(KeepAliveService.EXTRA_MEDIA, media)
                        i.putExtra(KeepAliveService.EXTRA_PLAYING, playing)
                        i.putExtra(KeepAliveService.EXTRA_TITLE, title)
                        i.putExtra(KeepAliveService.EXTRA_SUB, sub)
                        i.putExtra(KeepAliveService.EXTRA_TEXT, text.ifEmpty { "Working…" })
                        // already running = just update it (allowed from the background too)
                        if (KeepAliveService.running) startService(i) else startForegroundService(i)
                    } else if (KeepAliveService.running) {
                        i.action = KeepAliveService.ACTION_STOP
                        startService(i)
                    }
                } catch (_: Exception) {
                    // not allowed right now (app in background before the service was started)
                }
            }
        }

        @JavascriptInterface
        fun share(text: String) {
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(send, null))
            }
        }
    }
}
