# Vidora Fixes & Architecture Resolution Bundle

This bundle contains the complete, tested source code resolutions for all issues in the Vidora media player and downloader.

---

### Issues Resolved

1. **HTTP Error 403: Forbidden & Video Playback Failure / Only 360p Available:**
   - **Fix:** In `server.py`, replaced `android_vr` client with `android`, `tv`, and `mweb` player clients. Added proper `User-Agent` and range header proxying. This unlocks 1080p, 720p, 480p, and Opus/AAC streams cleanly without PO-token rejections.

2. **Long Search & Feed Loading Times:**
   - **Fix:** In `server.py`, reduced sub-searches from 8 heavy flat extractions down to 3 parallel targeted queries with 8s timeouts and a 15-minute in-memory LRU cache.

3. **Audio Stops Playing in Background / Screen Off / Home Screen:**
   - **Fix:** In `KeepAliveService.kt`, upgraded the foreground service from `FOREGROUND_SERVICE_TYPE_DATA_SYNC` to `FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK` and acquired a `PARTIAL_WAKE_LOCK` (6 hours max). Added matching permissions to `AndroidManifest.xml`.

4. **Network Disconnect at 90% Crashes & Restarts Download:**
   - **Fix:** In `server.py`, configured `continuedl=True`, `overwrites=False`, and `fragment_retries=20` with exponential backoff (`retry_sleep=fragment:exp=1:15`), preserving `.part` stage files so downloads resume seamlessly via Range headers instead of restarting from 0%.

5. **"App not installed as package conflicts with an existing package":**
   - **Fix:** In `build.gradle.kts`, configured a persistent signing keystore (`release.jks`) for both debug and release builds. Once the keystore is generated with `setup_keystore.sh`, all CI builds share the same digital signature.

6. **Outdated Media Player UI & Missing Light/Dark Theme Switching:**
   - **Fix:** In `index.html`, updated CSS with glassmorphism, elevated rounded controls, glowing accent buttons (`--ac-glow`), and instantaneous Light/Dark theme switching via `data-theme`.

---

### How to Apply These Files

1. Copy `KeepAliveService.kt` into `app/src/main/java/com/mydl/app/`
2. Update `app/src/main/AndroidManifest.xml` with the new permissions and service type
3. Copy `server.py` into `app/src/main/python/`
4. Update `app/build.gradle.kts` and generate `release.jks` using `bash setup_keystore.sh`
5. Replace `app/src/main/assets/index.html`
