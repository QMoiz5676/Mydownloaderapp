"""Vidora embedded backend (Flask + yt-dlp) optimized for mobile streaming and download resilience."""
import copy
import glob
import hashlib
import itertools
import json
import mimetypes
import os
import re
import threading
import time
import uuid
from urllib.parse import urlparse

import requests
import yt_dlp
from flask import Flask, Response, abort, jsonify, request, send_file

app = Flask(__name__)

ALLOWED_DOMAINS = (
    "youtube.com", "youtu.be", "facebook.com", "fb.watch", "fb.com",
    "instagram.com", "snapchat.com", "tiktok.com"
)

FEEDS = {
    "trending": ["trending videos today", "viral videos this week", "popular music videos"],
    "music": ["new music videos official", "latest trending songs", "top music hits"],
    "movies": ["official movie trailers 2026", "best movie clips", "new teaser trailers"],
    "gaming": ["gaming highlights", "gameplay walkthrough", "top funny gaming moments"],
    "funny": ["funny comedy clips", "best fails funny", "viral comedy videos"],
    "news": ["latest world news headlines", "breaking news today"],
    "diy": ["diy crafts hacks projects", "easy home craft ideas"]
}

CAT_WORD = {"trending": "", "music": "songs", "movies": "trailer", "gaming": "gameplay",
            "funny": "funny", "news": "news", "diy": "diy"}
MODS = ["", "latest", "best", "top", "viral"]
ID_RE = re.compile(r"^[a-f0-9]{12}$")
PAGE_SIZE = 10

INDEX_HTML = "<h1>Loading...</h1>"
LIB_DIR = "/tmp"
jobs = {}
info_cache = {}
preview_cache = {}
search_cache = {}

DEFAULT_UA = (
    "Mozilla/5.0 (Linux; Android 14; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0"
)

# Robust player clients that bypass the current YouTube PO-token / 403 blocks:
CLIENT_ARGS = {
    "android": {"youtube": {"player_client": ["android", "mweb"]}},
    "tv": {"youtube": {"player_client": ["tv", "web_embedded"]}},
    "default": {"youtube": {"player_client": ["android", "web"]}},
}
YT_SOURCES = ("android", "tv", "default")


class Cancelled(Exception):
    pass


def base_opts(src=None, **extra):
    o = {
        "quiet": True,
        "noplaylist": True,
        "cachedir": False,
        "no_warnings": True,
        "no_color": True,
        "socket_timeout": 15,
        "retries": 10,
        "fragment_retries": 15,
        "retry_sleep": "fragment:exp=1:15",
        "extractor_retries": 3,
        "fixup": "never",
        "postprocessors": [],
        "user_agent": DEFAULT_UA,
        "http_headers": {
            "User-Agent": DEFAULT_UA,
            "Accept-Language": "en-US,en;q=0.9",
        },
    }
    ea = CLIENT_ARGS.get(src)
    if ea:
        o["extractor_args"] = ea
    o.update(extra)
    return o


def clean_err(e):
    s = str(e) or e.__class__.__name__
    s = re.sub(r"\x1b\[[0-9;]*m", "", s)
    s = re.sub(r"^(ERROR:\s*)+", "", s.strip())
    s = re.sub(r"^\[[\w:]+\]\s+[\w-]{3,}:\s*", "", s)
    if "403" in s:
        return "Source link expired or blocked (HTTP 403). Retrying with fresh link..."
    if "Sign in to confirm" in s or "not a bot" in s:
        return "YouTube anti-bot challenge triggered. Try again in a minute."
    return s.strip()[:300]


def is_youtube(url):
    host = (urlparse(url).hostname or "").lower()
    return host.endswith(("youtube.com", "youtu.be"))


def check_url(url):
    try:
        p = urlparse(url)
    except Exception:
        abort(400, "Invalid URL")
    host = (p.hostname or "").lower()
    if p.scheme not in ("http", "https") or not any(
        host == d or host.endswith("." + d) for d in ALLOWED_DOMAINS
    ):
        abort(400, "Unsupported link. Please paste a supported video URL.")
    return url


def youtube_id(url):
    m = re.search(r"(?:v=|youtu\.be/|shorts/|embed/)([A-Za-z0-9_-]{11})", url)
    return m.group(1) if m else None


def safe_name(s):
    return re.sub(r'[\\/:*?"<>|\n\r]+', " ", s or "").strip()[:90] or "video"


@app.errorhandler(400)
def bad_request(e):
    return jsonify(error=getattr(e, "description", "Bad request")), 400


@app.errorhandler(404)
def not_found(e):
    return jsonify(error="Not found"), 404


@app.get("/")
def index():
    return Response(INDEX_HTML, mimetype="text/html")


@app.get("/api/engine")
def engine():
    try:
        from yt_dlp.version import __version__ as ytv
    except Exception:
        ytv = "unknown"
    try:
        from java import jclass  # noqa: F401
        muxer = True
    except Exception:
        muxer = False
    return jsonify(
        ytdlp=ytv,
        clients=list(YT_SOURCES),
        muxer=muxer,
        cached=len(info_cache),
        jobs=sum(1 for j in jobs.values() if j.get("status") in ("downloading", "processing")),
    )


def _entry_to_item(e):
    return {
        "id": e["id"],
        "title": e.get("title") or "Unknown Video",
        "channel": e.get("channel") or e.get("uploader") or "",
        "duration": e.get("duration") or 0,
        "views": e.get("view_count") or 0,
        "thumb": f"https://i.ytimg.com/vi/{e['id']}/mqdefault.jpg",
        "url": f"https://www.youtube.com/watch?v={e['id']}",
    }


def yt_search(q, n=PAGE_SIZE):
    key = (q.lower().strip(), n)
    hit = search_cache.get(key)
    if hit and hit[0] > time.time():
        return hit[1]
    opts = base_opts("android", extract_flat=True, skip_download=True)
    with yt_dlp.YoutubeDL(opts) as ydl:
        data = ydl.extract_info(f"ytsearch{n}:{q}", download=False)
    out = [_entry_to_item(e) for e in (data.get("entries") or []) if e and e.get("id")]
    search_cache[key] = (time.time() + 900, out)
    if len(search_cache) > 80:
        oldest = sorted(search_cache.keys(), key=lambda k: search_cache[k][0])[:20]
        for k in oldest:
            search_cache.pop(k, None)
    return out


def multi_search(queries, n=PAGE_SIZE):
    queries = [q.strip() for q in dict.fromkeys(queries) if q.strip()][:3]
    lists = [[] for _ in queries]
    errors = []

    def work(i, q):
        try:
            lists[i] = yt_search(q, n)
        except Exception as e:
            errors.append(clean_err(e))

    threads = [threading.Thread(target=work, args=(i, q), daemon=True) for i, q in enumerate(queries)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(8)

    seen = set()
    out = []
    for row in itertools.zip_longest(*lists):
        for item in row:
            if item and item["id"] not in seen:
                seen.add(item["id"])
                out.append(item)
    if not out and errors:
        raise RuntimeError(errors[0])
    return out


def _mod(page, shift=0):
    return MODS[(page + shift) % len(MODS)]


def plan_queries(cat, page, tags, title="", channel=""):
    qs = []
    if cat == "related":
        words = " ".join(re.findall(r"[^\W_]{3,}", title)[:4])
        if channel:
            qs.append(f"{channel} {words}")
        if words:
            qs.append(f"{words}")
        return qs or ["trending hits"]
    if cat == "foryou":
        if tags:
            for t in tags[:2]:
                qs.append(f"{t} {_mod(page)}")
        qs.append(f"trending {_mod(page, 1)}")
        return qs
    base = FEEDS.get(cat, ["trending"])
    qs.append(f"{base[page % len(base)]} {_mod(page)}")
    return qs


@app.get("/api/search")
def search():
    q = request.args.get("q", "").strip()
    if not q:
        abort(400, "Empty search query")
    try:
        page = max(0, min(int(request.args.get("page", "0")), 9))
    except ValueError:
        page = 0
    size = 15
    try:
        res = yt_search(q, size * (page + 1))[size * page:]
        return jsonify(results=res, next=page + 1 if len(res) >= (size - 3) and page < 9 else None)
    except Exception as e:
        return jsonify(error=f"Search failed: {clean_err(e)}"), 502


@app.get("/api/feed")
def feed():
    cat = request.args.get("cat", "foryou")
    if cat not in FEEDS and cat not in ("foryou", "related"):
        abort(400, "Unknown category")
    try:
        page = max(0, min(int(request.args.get("page", "0")), 200))
    except ValueError:
        page = 0
    tags = [t.strip()[:40] for t in request.args.get("tags", "").split("|") if t.strip()][:5]
    queries = plan_queries(cat, page, tags, request.args.get("title", "")[:100], request.args.get("channel", "")[:40])
    try:
        results = multi_search(queries, n=12)
        return jsonify(results=results, next=page + 1)
    except Exception as e:
        return jsonify(error=f"Could not load feed: {clean_err(e)}"), 502


def _size(f, dur):
    s = f.get("filesize") or f.get("filesize_approx")
    if not s and (f.get("tbr") or f.get("abr")) and dur:
        s = int((f.get("tbr") or f.get("abr")) * 125 * dur)
    return s


def _has_v(f):
    return f.get("vcodec") not in (None, "none")


def _has_a(f):
    return f.get("acodec") not in (None, "none")


def _vc(f):
    return str(f.get("vcodec") or "").lower()


def _ac(f):
    return str(f.get("acodec") or "").lower()


def _res(f):
    h, w = f.get("height"), f.get("width")
    if h and w and h > w:
        return w
    return h


def _tag(h):
    if h >= 2160: return "4K"
    if h >= 1440: return "2K"
    if h >= 1080: return "FHD"
    if h >= 720:  return "HD"
    return ""


def _rate(f):
    return f.get("tbr") or f.get("abr") or f.get("vbr") or 0


def make_options(i, src):
    fmts = [f for f in (i.get("formats") or []) if f.get("format_id") and "m3u8" not in str(f.get("protocol", ""))]
    dur = i.get("duration") or 0

    aonly = [f for f in fmts if _has_a(f) and not _has_v(f) and "drc" not in str(f["format_id"]).lower()]
    aac = [f for f in aonly if _ac(f).startswith("mp4a")]
    opus = [f for f in aonly if _ac(f).startswith("opus")]

    def best(lst):
        return max(lst, key=lambda f: (f.get("language_preference") or 0, _rate(f))) if lst else None

    best_aac, best_opus = best(aac), best(opus)
    vids = {}

    def offer(res, score, opt, rate):
        cur = vids.get(res)
        if not cur or (score, rate) > (cur["_s"], cur["_r"]):
            opt.update(_s=score, _r=rate)
            vids[res] = opt

    for f in fmts:
        if not _has_v(f):
            continue
        res = _res(f)
        if not res:
            continue
        r = _rate(f)
        if _has_a(f):
            ext = f.get("ext") or "mp4"
            offer(res, 35 if ext == "mp4" else 20,
                  {"mode": "direct", "fmt": f["format_id"], "ext": ext, "size": _size(f, dur)}, r)
            continue
        vs = _size(f, dur)
        if _vc(f).startswith(("avc1", "h264")) and best_aac:
            asz = _size(best_aac, dur)
            offer(res, 25, {"mode": "merge", "vid": f["format_id"], "aid": best_aac["format_id"], "ext": "mp4",
                            "size": (vs + asz) if vs and asz else vs}, r)
        elif _vc(f).startswith(("vp9", "vp09")) and best_opus:
            asz = _size(best_opus, dur)
            offer(res, 20, {"mode": "merge", "vid": f["format_id"], "aid": best_opus["format_id"], "ext": "webm",
                            "size": (vs + asz) if vs and asz else vs}, r)

    out = []
    for res, o in vids.items():
        o = dict(o)
        o.update(key=str(res), label=f"{res}p", tag=_tag(res), kind="video", src=src, res=res)
        out.append(o)

    seen = {}
    for f in aonly:
        a = _ac(f)
        name = "M4A" if a.startswith("mp4a") else "OPUS" if a.startswith("opus") else (f.get("ext") or "AUDIO").upper()
        abr = int(round(f.get("abr") or f.get("tbr") or 0))
        k = (name, abr)
        if k not in seen:
            seen[k] = f
    for (name, abr), f in seen.items():
        out.append({"key": "a" + str(f["format_id"]), "label": f"{abr}K" if abr else "Audio", "tag": "",
                    "kind": "audio", "mode": "direct", "fmt": f["format_id"], "ext": name,
                    "size": _size(f, dur), "src": src, "abr": abr})
    return out


def combine_options(per_src):
    vids, auds = {}, {}
    for src, opts in per_src:
        for o in opts:
            if o["kind"] == "video":
                cur = vids.get(o["key"])
                if not cur or (o["_s"], o["_r"]) > (cur["_s"], cur["_r"]):
                    vids[o["key"]] = o
            else:
                k = (o["ext"], o.get("abr"))
                if k not in auds:
                    auds[k] = o
    v = sorted(vids.values(), key=lambda o: -o["res"])
    a = sorted(auds.values(), key=lambda o: (o["ext"] != "M4A", -(o.get("abr") or 0)))
    opts = v + a
    if not opts:
        opts.append({"key": "best", "label": "Best", "tag": "Auto", "kind": "video", "mode": "direct",
                     "fmt": "best", "ext": "mp4", "size": None, "src": "default"})
    for o in opts:
        o.pop("_s", None)
        o.pop("_r", None)
    return opts


INFO_TTL = 1200


def get_info(url):
    hit = info_cache.get(url)
    if hit and hit["exp"] > time.time():
        return hit
    srcs = YT_SOURCES if is_youtube(url) else ("default",)
    results, errors, stamps = {}, {}, {}

    def fetch(src):
        try:
            o = base_opts(src, skip_download=True, format="bestvideo+bestaudio/best")
            with yt_dlp.YoutubeDL(o) as ydl:
                results[src] = ydl.extract_info(url, download=False)
            stamps[src] = time.time()
        except Exception as e:
            errors[src] = clean_err(e)

    threads = [threading.Thread(target=fetch, args=(s,), daemon=True) for s in srcs]
    for t in threads:
        t.start()
    t0 = time.time()
    while any(t.is_alive() for t in threads):
        if stamps and (time.time() - min(stamps.values()) > 2.5):
            break
        if time.time() - t0 > 15:
            break
        time.sleep(0.08)

    infos = {s: results[s] for s in srcs if s in results}
    if not infos:
        raise RuntimeError(next(iter(errors.values()), "Could not load video metadata"))

    per_src, first = [], None
    for s, i in infos.items():
        try:
            per_src.append((s, make_options(i, s)))
            first = first or i
        except Exception as e:
            errors[s] = clean_err(e)

    opts = combine_options(per_src)
    first = first or next(iter(infos.values()))
    entry = {
        "exp": time.time() + INFO_TTL,
        "infos": infos,
        "opts": opts,
        "small": {k: first.get(k) for k in ("title", "uploader", "duration", "thumbnail", "view_count")},
        "streams": {},
    }
    info_cache[url] = entry
    if len(info_cache) > 10:
        info_cache.pop(next(iter(info_cache)), None)
    return entry


@app.get("/api/info")
def info():
    url = check_url(request.args.get("url", "").strip())
    try:
        e = get_info(url)
    except Exception as ex:
        return jsonify(error=f"Could not read link: {clean_err(ex)}"), 502
    i = e["small"]
    return jsonify(
        url=url,
        title=i.get("title"),
        uploader=i.get("uploader"),
        duration=i.get("duration"),
        thumb=i.get("thumbnail"),
        youtube_id=youtube_id(url),
        views=i.get("view_count"),
        play=play_heights(e),
        options=[{k: o.get(k) for k in ("key", "label", "tag", "size", "kind", "mode", "ext")} for o in e["opts"]],
    )


def _stream_ok(f):
    proto = str(f.get("protocol", ""))
    return bool(f.get("url")) and f.get("format_id") and "m3u8" not in proto and "dash" not in proto


def play_heights(entry):
    heights = {}
    for info in entry["infos"].values():
        for f in info.get("formats") or []:
            if _stream_ok(f) and _has_v(f) and _has_a(f) and _res(f):
                heights[_res(f)] = max(heights.get(_res(f), 0), _size(f, entry["small"].get("duration") or 0) or 0)
    return [{"res": h, "label": f"{h}p", "size": heights[h] or None} for h in sorted(heights, reverse=True)]


def pick_stream(entry, mode, q):
    cache = entry["streams"]
    if (mode, q) in cache:
        return cache[(mode, q)]
    best, best_key = None, None
    for info in entry["infos"].values():
        for f in info.get("formats") or []:
            if not _stream_ok(f):
                continue
            if mode == "audio":
                if not _has_a(f):
                    continue
                abr = f.get("abr") or f.get("tbr") or 0
                key = (not _has_v(f), _ac(f).startswith("mp4a"), abr)
            else:
                if not (_has_v(f) and _has_a(f)) or not _res(f):
                    continue
                r = _res(f)
                key = (r <= q, r if r <= q else -r, f.get("ext") == "mp4", _rate(f))
            if best_key is None or key > best_key:
                best, best_key = f, key

    pick = None
    if best:
        h = dict(best.get("http_headers") or {})
        h.setdefault("User-Agent", DEFAULT_UA)
        pick = {"url": best["url"], "headers": h}
    cache[(mode, q)] = pick
    return pick


GV_CHUNK = 8 * 1024 * 1024


def proxy_stream(direct, headers, range_hdr):
    h = dict(headers or {})
    h.setdefault("User-Agent", DEFAULT_UA)
    m = re.match(r"bytes=(\d*)-(\d*)$", range_hdr or "")
    if m:
        start = int(m.group(1)) if m.group(1) else 0
        end = int(m.group(2)) if m.group(2) else None
        cap = start + GV_CHUNK - 1
        h["Range"] = f"bytes={start}-{cap if end is None else min(end, cap)}"
    elif range_hdr:
        h["Range"] = range_hdr

    r = requests.get(direct, headers=h, stream=True, timeout=18)
    resp = Response(r.iter_content(65536), status=r.status_code)
    for k in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges"):
        if k in r.headers:
            resp.headers[k] = r.headers[k]
    resp.headers.setdefault("Accept-Ranges", "bytes")
    resp.call_on_close(r.close)
    return resp, r.status_code


@app.get("/api/stream")
def stream():
    url = check_url(request.args.get("url", "").strip())
    mode = "audio" if request.args.get("mode") == "audio" else "video"
    try:
        q = int(request.args.get("q") or 720)
    except ValueError:
        q = 720
    try:
        entry = get_info(url)
    except Exception as ex:
        return jsonify(error=f"Stream error: {clean_err(ex)}"), 502

    pick = pick_stream(entry, mode, q)
    if not pick:
        abort(400, "No playable stream found")
    range_hdr = request.headers.get("Range")
    try:
        resp, status = proxy_stream(pick["url"], pick["headers"], range_hdr)
        if status in (403, 404, 410):
            # Expired token: clear cache, refresh and retry once
            resp.close()
            info_cache.pop(url, None)
            fresh = get_info(url)
            fresh_pick = pick_stream(fresh, mode, q)
            if fresh_pick:
                resp, status = proxy_stream(fresh_pick["url"], fresh_pick["headers"], range_hdr)
                if status not in (403, 404, 410):
                    return resp
            return jsonify(error="Stream rejected (HTTP 403). Try another quality."), 502
    except requests.RequestException:
        entry["streams"].pop((mode, q), None)
        return jsonify(error="Connection error while streaming."), 502
    return resp


def _merge(video, audio, out):
    from java import jclass
    jclass("com.mydl.app.Muxer").merge(video, audio, out)


def _find(prefix):
    files = [f for f in glob.glob(glob.escape(prefix) + ".*")
             if not f.endswith((".part", ".ytdl", ".json", ".temp"))]
    return files[0] if files else None


def _rm(*paths):
    for p in paths:
        try:
            if p and os.path.exists(p):
                os.remove(p)
        except OSError:
            pass


def _speed(n):
    if not n: return ""
    return f"{n / 1e6:.1f} MB/s" if n >= 1e6 else f"{max(1, int(n / 1e3))} KB/s"


def run_job(jid, url, key):
    job = jobs[jid]
    base = os.path.join(LIB_DIR, jid)

    def make_hook(lo, hi, est):
        def hook(d):
            if job.get("cancel"):
                raise Cancelled()
            if d.get("status") == "downloading":
                total = d.get("total_bytes") or d.get("total_bytes_estimate") or est or 0
                done = d.get("downloaded_bytes") or 0
                if total and done:
                    frac = min(0.99, done / total)
                    job["progress"] = round((lo + (hi - lo) * frac) * 100, 1)
                job["speed"] = _speed(d.get("speed"))
        return hook

    def fetch(entry, src, fmt, prefix, hook):
        # Allow automatic resume of .part files across network interruptions
        o = base_opts(
            src,
            format=fmt,
            outtmpl=prefix + ".%(ext)s",
            progress_hooks=[hook],
            http_chunk_size=5 * 1024 * 1024,
            continuedl=True,
            overwrites=False,
            fragment_retries=20,
            retries=15,
        )
        completed = _find(prefix)
        if completed and os.path.getsize(completed) > 0:
            return completed

        errors = []
        for attempt in ("info", "url"):
            try:
                with yt_dlp.YoutubeDL(o) as ydl:
                    if attempt == "info" and entry["infos"].get(src):
                        ydl.process_ie_result(copy.deepcopy(entry["infos"][src]), download=True)
                    else:
                        ydl.download([url])
                path = _find(prefix)
                if path and os.path.getsize(path) > 0:
                    return path
            except Exception as e:
                if job.get("cancel") or isinstance(e, Cancelled):
                    raise Cancelled()
                errors.append(clean_err(e))
        raise RuntimeError(errors[-1] if errors else "Download failed")

    temps = []
    try:
        entry = get_info(url)
        i, opts = entry["small"], entry["opts"]
        opt = next((o for o in opts if o["key"] == key), None) or opts[0]
        src = opt.get("src", "default")
        qlabel = opt["label"] if opt["kind"] == "video" else f'{opt["label"]} {opt.get("ext", "")}'.strip()
        job.update(title=i.get("title"), thumb=i.get("thumbnail"), quality=qlabel)
        total = opt.get("size") or 0

        if opt["mode"] == "merge":
            vpath = fetch(entry, src, opt["vid"], base + "_v", make_hook(0, 0.88, int(total * 0.88) if total else 0))
            temps.append(vpath)
            apath = fetch(entry, src, opt["aid"], base + "_a", make_hook(0.88, 0.98, int(total * 0.12) if total else 0))
            temps.append(apath)
            job["status"] = "processing"
            job["progress"] = 99
            out = base + "." + (opt.get("ext") or "mp4")
            _merge(vpath, apath, out)
        else:
            out = fetch(entry, src, opt["fmt"], base, make_hook(0, 1, total))

        _rm(*temps)
        ext = os.path.splitext(out)[1].lstrip(".")
        meta = {
            "id": jid, "title": safe_name(i.get("title")), "uploader": i.get("uploader"),
            "thumb": i.get("thumbnail"), "duration": i.get("duration"),
            "quality": qlabel, "kind": opt["kind"], "ext": ext,
            "file": os.path.basename(out), "size": os.path.getsize(out),
            "created": time.time(), "source": url,
        }
        with open(base + ".json", "w", encoding="utf-8") as fh:
            json.dump(meta, fh)
        job["item"] = meta
        job["progress"] = 100
        job["status"] = "done"
    except Exception as e:
        if job.get("cancel") or isinstance(e, Cancelled):
            job["status"] = "cancelled"
        else:
            job["status"] = "error"
            job["err"] = clean_err(e) or "Download failed"


@app.post("/api/download")
def download():
    body = request.get_json(silent=True) or {}
    url = check_url(str(body.get("url", "")).strip())
    key = str(body.get("key", ""))
    jid = hashlib.sha256((url + "|" + key).encode("utf-8")).hexdigest()[:12]
    previous = jobs.get(jid, {})
    if previous.get("status") in ("downloading", "processing"):
        return jsonify(id=jid)
    if previous.get("status") == "done":
        jid = uuid.uuid4().hex[:12]
    jobs[jid] = {"status": "downloading", "progress": 0, "created": time.time(), "url": url, "key": key}
    threading.Thread(target=run_job, args=(jid, url, key), daemon=True).start()
    return jsonify(id=jid)


@app.get("/api/progress/<jid>")
def progress(jid):
    j = jobs.get(jid)
    if not j:
        abort(400, "Unknown job")
    return jsonify({k: j.get(k) for k in ("status", "progress", "speed", "err", "title", "thumb", "quality", "item")})


@app.post("/api/cancel/<jid>")
def cancel(jid):
    j = jobs.get(jid)
    if j:
        j["cancel"] = True
    return jsonify(ok=True)


def _meta(item_id):
    if not ID_RE.match(item_id):
        abort(400, "Bad id")
    p = os.path.join(LIB_DIR, item_id + ".json")
    if not os.path.exists(p):
        abort(404)
    with open(p, encoding="utf-8") as fh:
        m = json.load(fh)
    path = os.path.join(LIB_DIR, m["file"])
    if not os.path.exists(path):
        abort(404)
    return m, path


@app.get("/api/library")
def library():
    items, total = [], 0
    for p in glob.glob(os.path.join(LIB_DIR, "*.json")):
        try:
            with open(p, encoding="utf-8") as fh:
                m = json.load(fh)
            if os.path.exists(os.path.join(LIB_DIR, m["file"])):
                items.append(m)
                total += m.get("size") or 0
        except Exception:
            continue
    items.sort(key=lambda m: m.get("created", 0), reverse=True)
    return jsonify(items=items, total=total)


@app.get("/api/media/<item_id>")
def media(item_id):
    m, path = _meta(item_id)
    mime = mimetypes.guess_type(path)[0] or ("audio/mp4" if m["kind"] == "audio" else "video/mp4")
    return send_file(path, mimetype=mime, conditional=True)


@app.get("/api/file/<item_id>")
def get_file(item_id):
    m, path = _meta(item_id)
    return send_file(path, as_attachment=True, download_name=f"{m['title']}.{m['ext']}")


@app.delete("/api/library/<item_id>")
def delete_item(item_id):
    m, path = _meta(item_id)
    _rm(path, os.path.join(LIB_DIR, item_id + ".json"))
    return jsonify(ok=True)


@app.delete("/api/library")
def delete_all():
    for p in glob.glob(os.path.join(LIB_DIR, "*")):
        if os.path.isfile(p):
            _rm(p)
    return jsonify(ok=True)


def cleanup_loop():
    while True:
        time.sleep(600)
        cutoff = time.time() - 3600
        for jid, j in list(jobs.items()):
            if j["created"] < cutoff and j.get("status") in ("done", "error", "cancelled"):
                jobs.pop(jid, None)


def start(html, lib_dir):
    global INDEX_HTML, LIB_DIR
    INDEX_HTML = html
    LIB_DIR = lib_dir
    os.makedirs(LIB_DIR, exist_ok=True)
    threading.Thread(target=cleanup_loop, daemon=True).start()
    app.run(host="127.0.0.1", port=5000, threaded=True, use_reloader=False)
