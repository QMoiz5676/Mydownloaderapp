#!/usr/bin/env bash
# Generate persistent release keystore to fix package signature conflicts
set -euo pipefail

echo "Generating Vidora release.jks in root directory..."
keytool -genkeypair -v \
  -keystore release.jks \
  -alias vidorakey \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -storepass vidorapass123 \
  -keypass vidorapass123 \
  -dname "CN=Vidora, OU=Mobile, O=App, L=City, S=State, C=US"

echo "Done! release.jks successfully created."
