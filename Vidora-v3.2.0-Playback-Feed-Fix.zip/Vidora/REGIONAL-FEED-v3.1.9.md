# Vidora v3.1.9 — Region-aware discovery

- Added country/language-aware viral search profiles for major regions.
- Home and Shorts now mix localized trend searches with global and personal-interest searches.
- Regional results are discovery hints, not hard country filters.
- Localized search profiles cover Urdu/Hindi/English, Bangla, Arabic, Turkish, Korean, Japanese, Spanish, French, German, Portuguese and other language markets.
- Automatic region continues to use public-IP detection with device locale/timezone fallback; users can still choose a region manually in Settings.

Validation: Python syntax compilation and regional query unit checks passed. Android APK/live feed testing still required.
