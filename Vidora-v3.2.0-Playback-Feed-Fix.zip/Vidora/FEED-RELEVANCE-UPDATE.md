# Feed relevance update

## Changes
- For You recommendations now prioritize the viewer's strongest learned interests instead of injecting unrelated random categories on every page.
- Shorts searches now use learned interests first and keep the search focused on actual Shorts.
- New viewers retain a broad trending fallback until they build an interest profile.
- Interest extraction ignores more generic title words and ranks useful terms by frequency.
- Learned interests are selected by strongest weight rather than random weighted sampling, making the feed more consistent.

## Important limitation
Vidora's feed is built from public YouTube search results via yt-dlp, not from YouTube's private recommendation API. Personalization therefore improves query relevance but cannot guarantee the same ranking or inventory as YouTube's native Home/Shorts feed. Users should like/dislike, follow creators, and watch videos they enjoy to build a better local profile.
