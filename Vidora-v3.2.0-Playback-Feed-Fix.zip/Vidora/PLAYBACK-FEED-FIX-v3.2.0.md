# Vidora 3.2.0 — Shorts playback and feed diversity

## Changes
- Shorts now request a single muxed audio+video stream first. This avoids relying on a second detached audio element during autoplay, which can be blocked by Android WebView autoplay policy.
- If the muxed stream is unavailable, Shorts fall back to adaptive video-only + audio streams; retry requests a fresh muxed stream.
- Feed requests exclude recently shown video IDs and recent creator/channel IDs, and the backend applies channel diversity when weaving overlapping yt-dlp search results.
- Explicit likes now add a stronger interest signal and boost broad topics inferred from title keywords, so later Home and Shorts requests can include similar categories.
- Existing dislikes remain excluded from recommendations.

## Verification
- Python backend passed `py_compile`.
- Inline JavaScript passed `node --check`.
- ZIP integrity checked after packaging.
- An Android APK build and live playback test on-device have not been run in this environment. The two supplied Shorts IDs should be tested on the target phone after building the APK; YouTube can change or restrict individual streams independently of app code.
