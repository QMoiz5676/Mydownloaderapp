# Vidora v3.1.8 — Global cold-start feed

## Why this update
The supplied VidMate reference shows a mixed discovery feed: popular entertainment, music, comedy and other creator content from more than one language/region. Vidora's previous new-user fallback included `popular videos in Pakistan`, and the detected country was appended to every query. That unintentionally made a Pakistan install heavily Pakistan-centric.

## Changes
- New-install Home feed now starts with three rotating global discovery topics per page (comedy, animals, sports, movies, music, gaming, food, science, technology, travel, satisfying videos, talent, history and DIY).
- New-install Shorts use varied short-form topics instead of depending on generic `#shorts` searches.
- Country is now only a light local-discovery hint on one query every four pages, not appended to every search.
- Returning users still get their strongest learned interests first, with an adjacent discovery query to avoid a narrow filter bubble.
- Corrected Python regex escaping in query cleanup so whitespace and word-character filtering work as intended.

## VidMate implementation note
VidMate's production recommendation/ranking backend is proprietary and is not publicly documented. The reference video can be used to reproduce the visible discovery approach (a diverse, popular, mixed-region feed), but its private API or exact ranking model cannot be copied from the video. This update uses public YouTube search through yt-dlp; yt-dlp remains an extractor/search interface, not a recommendation engine.

## Limitations
YouTube search inventory and ranking can change. Some search results may be unavailable or fail the real-Shorts verification. A production-grade personalized ranking system would need reliable engagement telemetry, candidate scoring, freshness/popularity signals and ongoing evaluation.
