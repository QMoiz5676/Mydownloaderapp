# Vidora v3.2.1 — Home Feed & Shorts Playback Hotfix

## Fixed
- Home, category, search, and related-feed fetchers now return request URL strings. The previous release returned already-started API Promises, then treated them as URLs and called `.includes()`, causing `baseUrl.includes is not a function` and an empty Home Feed.
- Added a defensive type check around feed request URL construction so future fetcher contract mistakes surface as a readable feed error instead of a JavaScript type exception.
- Shorts playback now has a timed fallback from a muxed video+audio stream to separate video-only and audio-only streams when the initial stream stalls without emitting a media error.
- Added a final loading timeout so the Shorts spinner cannot run forever; failed streams enter the retry/error state.
- Clear playback watchdog timers when a Short is removed from the active window.

## Verification
- `server.py` Python syntax: passed.
- Inline JavaScript syntax: passed with Node.js `--check`.
- ZIP integrity: verified after packaging.

## Device testing still required
A real Android/WebView run is required to confirm playback against current YouTube stream responses, audio synchronization, and device-specific codec support. No APK build or live playback test is claimed here.
