# Vidora v3.3.1 — Faster feed, Shorts that play

## Feed speed
- A feed page no longer waits for the slowest search: it returns once ~12 videos are ready (after 2.5 s) or after
  12 s at most (was up to 20 s). Slow searches still finish into the cache for the next page.
- Fewer searches per page (4 instead of 6 on a new install) and only ~20% use the newest-first mode.
- The last Home feed is saved on the phone and shown instantly at start, then replaced by fresh videos.
- Shorts: clips of 60 s or less are accepted without an extra YouTube request per video.

## Shorts "could not be played"
- Cause: most Shorts have no single audio+video file. The app waited 12 s for it, then switched to separate
  video + audio, and by then the 4 Shorts it pre-loaded at once were fighting over a slow connection.
- Now: the single-file request answers immediately (HTTP 404) when it does not exist, so the app switches to
  separate video + audio at once (stall timer 9 s, final timer 30 s).
- Only the current Short and the next one (started 1.8 s later) are loaded; at most 3 YouTube page reads run at
  the same time; the video-info cache keeps 60 entries (was 20).
- A Short that still fails is retried once quietly, then the app moves on to the next Short with a short message.

## Not verified
No APK build and no on-device test were possible here (syntax checks and the query planner test only). If a
Short still fails, send a screen recording; the next step would be logging the yt-dlp error per Short.
