# Vidora v3.3 — Feed that actually changes

## Why the old feed repeated
The backend chose its search phrases from the page number alone (fixed lists + `page % len`). The same
phrases always went to YouTube, so the same top results came back on every refresh and after every
reinstall. "full" in the modifier list and "movie"/"drama" queries also filled the feed with 1–2 hour films.

## Changes
- **Random seed per refresh/launch** (`seed`): every refresh, pull-to-refresh and app start produces a
  different set of searches. The same seed + page stays stable, so the next-page prefetch still works.
- **Big topic pools** (`GLOBAL_POOL`, `REGION_POOLS`): each page draws a random mix (~60% regional such as
  Urdu naat, Pakistani songs, news, kids, drama clips, cricket; ~40% global). Pakistan, India, Bangladesh and
  other language regions are covered; unknown regions fall back to global topics.
- **No more "full" movie walls**: "full" removed from the modifiers; Home and category feeds hide videos longer
  than 25 minutes and "full movie" titles (the Movies chip and search are unchanged).
- **Fresh uploads**: about a third of the searches use YouTube's upload-date sort (`@recent`), with automatic
  fallback to the normal search.
- **Channel RSS** (free, no API key): latest uploads of channels you subscribed to are mixed into Home and
  category feeds (only real `UC…` channel IDs are used; nothing is hard-coded).
- **Remembered "already shown"** (`vidora.seen`, last 3 days, 900 items) so a video does not come back on the
  next refresh. If everything on a page was already seen, the app falls back to showing it rather than an
  empty screen. Shorts keep their own seen list.
- **Cleaner cards**: Like / Dislike / Channel / Subscribe moved behind a ⋮ button; Dislike now removes the card.
- **Refresh behaviour**: returning to the app reshuffles only after being away for more than 1 minute.
- Version 3.3 (versionCode 13).

## Verification (this environment)
- `server.py` compiles; the query planner was tested offline (different seeds give different searches, the
  same seed is stable, 200 distinct searches over 40 refreshes).
- Inline JavaScript checked with `node --check`.
- NOT tested: APK build, live YouTube searches, on-device playback. YouTube's upload-date search URL and the
  channel RSS call are wrapped in fallbacks, but please test on the phone.
