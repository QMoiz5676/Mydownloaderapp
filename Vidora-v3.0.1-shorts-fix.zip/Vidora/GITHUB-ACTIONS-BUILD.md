# Build Vidora 3.0 debug APK with GitHub Actions

## What this workflow does
- Uses Java 17, Gradle 8.9, Android SDK 34 and Python 3.12.
- Checks the embedded Python and JavaScript syntax.
- Parses Android XML resources.
- Runs `:app:assembleDebug`.
- Uploads `app/build/outputs/apk/debug/app-debug.apk` as the workflow artifact `Vidora-3.0-debug-apk`.

## Run it
1. Extract the contents of this `Vidora` folder into the root of your GitHub repository (so `app/`, `build.gradle.kts`, `settings.gradle.kts` and `.github/` are at repository root).
2. Commit and push to the `main` branch, or open **Actions → Build Vidora debug APK → Run workflow**.
3. Open the completed workflow run.
4. Under **Artifacts**, download `Vidora-3.0-debug-apk`.
5. Extract the artifact and install `app-debug.apk` on an Android device.

## Important
- This is a debug APK signed with Android's automatically generated debug key. It is for testing, not a Play Store release.
- GitHub Actions has not been run from this workspace. The first remote run is the authoritative Android/Gradle build result.
- `minSdk` is 29 and the Python runtime ABI is currently `arm64-v8a`; this build is intended for 64-bit ARM Android phones.
- Keep the existing premium UI, app ID, PiP, widgets and downloader source files when replacing the repository contents.
