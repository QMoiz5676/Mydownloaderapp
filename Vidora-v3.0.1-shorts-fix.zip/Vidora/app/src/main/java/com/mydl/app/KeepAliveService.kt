package com.mydl.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager

/**
 * Keeps Vidora running while something is loaded in the player or downloads run.
 *
 * - Media: a "mediaPlayback" foreground service + MediaSession, so Android treats Vidora like a
 *   music app: sound keeps playing on the home screen / with the screen off, and the notification,
 *   lock screen and headset buttons control it (play / pause / next / previous).
 * - Downloads: a "dataSync" foreground service, as before.
 * - A partial wake lock + Wi-Fi lock stop the CPU / Wi-Fi from sleeping mid-song.
 */
class KeepAliveService : Service() {

    private var session: MediaSession? = null
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        session = MediaSession(this, "Vidora").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() = send("play")
                override fun onPause() = send("pause")
                override fun onSkipToNext() = send("next")
                override fun onSkipToPrevious() = send("prev")
                override fun onStop() = send("stop")
            })
            isActive = true
        }
    }

    private fun send(cmd: String) {
        MainActivity.mediaCommand?.invoke(cmd)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                shutdown()
                return START_NOT_STICKY
            }
            ACTION_PLAY, ACTION_PAUSE, ACTION_NEXT, ACTION_PREV -> {
                send(intent.action!!.substringAfterLast('.').lowercase())
                return START_NOT_STICKY
            }
        }

        val downloads = intent?.getIntExtra(EXTRA_DOWNLOADS, 0) ?: 0
        val media = intent?.getBooleanExtra(EXTRA_MEDIA, false) ?: false
        val playing = intent?.getBooleanExtra(EXTRA_PLAYING, false) ?: false
        val title = intent?.getStringExtra(EXTRA_TITLE).orEmpty()
        val sub = intent?.getStringExtra(EXTRA_SUB).orEmpty()
        val text = intent?.getStringExtra(EXTRA_TEXT) ?: "Working…"

        if (!media && downloads == 0) {
            shutdown()
            return START_NOT_STICKY
        }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Playback and downloads", NotificationManager.IMPORTANCE_LOW))

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = Notification.Builder(this, CHANNEL)
            .setContentIntent(open)
            .setOngoing(playing || downloads > 0)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)

        var type = 0
        if (media) {
            type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            session?.setMetadata(
                MediaMetadata.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, title.ifEmpty { "Vidora" })
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, sub)
                    .build()
            )
            session?.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(
                        PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                            PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_STOP
                    )
                    .setState(
                        if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                        PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f
                    )
                    .build()
            )
            b.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title.ifEmpty { "Vidora" })
                .setContentText(if (downloads > 0) "$sub · $text".trim(' ', '·') else sub)
                .addAction(action(android.R.drawable.ic_media_previous, "Previous", ACTION_PREV, 1))
                .addAction(
                    if (playing) action(android.R.drawable.ic_media_pause, "Pause", ACTION_PAUSE, 2)
                    else action(android.R.drawable.ic_media_play, "Play", ACTION_PLAY, 3)
                )
                .addAction(action(android.R.drawable.ic_media_next, "Next", ACTION_NEXT, 4))
            val style = Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2)
            session?.sessionToken?.let { style.setMediaSession(it) }
            b.setStyle(style)
        } else {
            b.setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("Vidora")
                .setContentText(text)
        }
        if (downloads > 0) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC

        try {
            startForeground(NOTIF_ID, b.build(), type)
        } catch (e: Exception) {
            // Android refused (e.g. started from the background): keep the notification at least
            nm.notify(NOTIF_ID, b.build())
        }
        holdLocks(playing || downloads > 0)
        return START_NOT_STICKY
    }

    private fun action(icon: Int, label: String, act: String, req: Int): Notification.Action {
        val pi = PendingIntent.getService(
            this, req, Intent(this, KeepAliveService::class.java).setAction(act),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, icon), label, pi).build()
    }

    @Suppress("DEPRECATION")
    private fun holdLocks(on: Boolean) {
        if (on) {
            if (wake == null) {
                wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                    .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Vidora:playback").apply { setReferenceCounted(false) }
            }
            if (wake?.isHeld != true) wake?.acquire(6 * 60 * 60 * 1000L)
            if (wifi == null) {
                wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                    .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "Vidora:stream").apply { setReferenceCounted(false) }
            }
            if (wifi?.isHeld != true) wifi?.acquire()
        } else {
            if (wake?.isHeld == true) wake?.release()
            if (wifi?.isHeld == true) wifi?.release()
        }
    }

    private fun shutdown() {
        holdLocks(false)
        session?.setPlaybackState(PlaybackState.Builder().setState(PlaybackState.STATE_STOPPED, 0, 0f).build())
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // swiping Vidora away from recent apps stops playback, like most players
        send("pause")
        shutdown()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        running = false
        holdLocks(false)
        session?.release()
        session = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var running = false
        const val ACTION_STOP = "com.mydl.app.STOP"
        const val ACTION_PLAY = "com.mydl.app.PLAY"
        const val ACTION_PAUSE = "com.mydl.app.PAUSE"
        const val ACTION_NEXT = "com.mydl.app.NEXT"
        const val ACTION_PREV = "com.mydl.app.PREV"
        const val EXTRA_TEXT = "text"
        const val EXTRA_DOWNLOADS = "downloads"
        const val EXTRA_MEDIA = "media"
        const val EXTRA_PLAYING = "playing"
        const val EXTRA_TITLE = "title"
        const val EXTRA_SUB = "sub"
        private const val CHANNEL = "vidora_media"
        private const val NOTIF_ID = 1
    }
}
