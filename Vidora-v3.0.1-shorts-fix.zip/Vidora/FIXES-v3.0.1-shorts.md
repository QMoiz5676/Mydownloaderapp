# Shorts feed fix
- Shorts tab is now a real full-screen 9:16 vertical feed: one video per card, swipe to change, snaps one video per swipe.
- The first Short autoplays as soon as the tab opens; each newly visible Short autoplays and the previous one pauses. Next one is pre-warmed.
- Tap = pause/play, speaker button = mute (auto-falls back to muted if the device blocks sound autoplay). Progress bar at the bottom.
- Landscape or non-Short results are no longer forced into the 16:9 watch page: landscape clips are letterboxed on a blurred backdrop, clips over ~3 min are skipped.
- Shorts pause when you leave the tab or background the app.
- Shorts tab icon replaced with the YouTube Shorts glyph.
