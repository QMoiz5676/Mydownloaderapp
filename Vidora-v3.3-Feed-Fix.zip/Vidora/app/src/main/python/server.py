"""Vidora embedded backend (Flask + yt-dlp), runs inside the Android app via Chaquopy."""
import copy
import glob
import itertools
import json
import mimetypes
import os
import random
import re
import threading
import time
import uuid
from urllib.parse import quote_plus, urlparse
import xml.etree.ElementTree as ET

import requests
import yt_dlp
from flask import Flask, Response, abort, jsonify, request, send_file

app = Flask(__name__)

ALLOWED_DOMAINS = (
    "youtube.com", "youtu.be", "facebook.com", "fb.watch", "fb.com",
    "instagram.com", "snapchat.com",
)
# Every category is a list of search phrases. Page N of a feed uses a different phrase / modifier,
# so scrolling never runs out and never repeats the same 20 videos.
FEEDS = {
    "trending": ["trending videos today", "viral videos this week", "most popular videos right now", "top videos",
                 "funny viral clips", "amazing moments caught on camera", "best clips of the day", "must watch videos"],
    "music": ["new music videos", "top songs", "latest songs official video", "music mix", "live performance music",
              "acoustic cover songs", "new song lyrics video", "evergreen hit songs"],
    "movies": ["movie trailers", "new movie trailers", "best movie scenes", "short films", "web series clips",
               "movie review", "upcoming movies teaser", "best action scenes"],
    "gaming": ["gaming highlights", "gameplay walkthrough", "new game trailers", "funny gaming moments",
               "mobile gaming clips", "pro gamer clutch moments", "game review", "esports highlights"],
    "funny": ["funny videos", "comedy clips", "funny fails", "stand up comedy", "funny pranks", "comedy sketch",
              "funny animals", "try not to laugh"],
    "news": ["latest news", "breaking news today", "news headlines", "world news", "news analysis today",
             "sports news today", "technology news today", "business news today"],
    "diy": ["diy craft projects", "diy home hacks", "woodworking projects", "easy crafts", "satisfying restoration",
            "cardboard crafts", "paper crafts easy", "mini diy ideas"],
    "shorts": ["#shorts", "#shorts viral", "#shorts funny", "#youtubeshorts trending", "#shorts new", "#shorts comedy"],
}
CAT_WORD = {"trending": "", "music": "songs", "movies": "movies", "gaming": "gameplay",
            "funny": "funny", "news": "news", "diy": "diy", "shorts": "#shorts"}
# NOTE: no "full" here: it pulled 2-hour full movies into every feed.
MODS = ["", "new", "best", "latest", "popular", "mix", "compilation", "this week", "viral", "recent", "2026"]
ID_RE = re.compile(r"^[a-f0-9]{12}$")
PAGE_SIZE = 16  # results asked per search phrase

INDEX_HTML = "<h1>Loading...</h1>"
LIB_DIR = "/tmp"
CACHE_DIR = None  # yt-dlp's own cache (player data etc.), set from Kotlin
jobs = {}
info_cache = {}
preview_cache = {}
search_cache = {}
region_cache = {"value": None, "exp": 0}
_locks = {}
_locks_guard = threading.Lock()

# One shared HTTP connection pool for the player proxy: re-using connections to the video
# servers makes starting and seeking much faster than opening a new connection every time.
HTTP = requests.Session()
HTTP.mount("https://", requests.adapters.HTTPAdapter(pool_connections=8, pool_maxsize=32, max_retries=1))
HTTP.mount("http://", requests.adapters.HTTPAdapter(pool_connections=4, pool_maxsize=16, max_retries=1))


def key_lock(key):
    """One lock per key, so two screens asking for the same video/search do the work once."""
    with _locks_guard:
        lk = _locks.get(key)
        if lk is None:
            if len(_locks) > 200:
                _locks.clear()
            lk = _locks[key] = threading.Lock()
        return lk


class Cancelled(Exception):
    pass


# YouTube player clients (no JavaScript runtime on the phone).
#   default : yt-dlp's own "no JavaScript" client choice (currently visionos). yt-dlp keeps this
#             working as YouTube changes, so rebuilding the APK picks up fixes. It returns every
#             quality (144p ... 4K) as SEPARATE video and sound streams, and no "one file" stream.
#   vision  : visionos asked for directly; only used when "default" returned no qualities.
# Removed (tested Nov 2026, they are the cause of the 403 / "could not be played" errors):
#   android_vr : only returns format 18 (360p with sound) and that link now answers 403.
#   ios / mweb / web_embedded : need a PO token or a JS runtime, links answer 403 or are empty.
CLIENT_ARGS = {
    "default": None,
    "vision": {"youtube": {"player_client": ["visionos"]}},
}
YT_SOURCES = ("default",)
YT_FALLBACK = ("vision",)


def base_opts(src=None, fast=False, **extra):
    o = {
        "quiet": True, "noplaylist": True, "no_warnings": True, "no_color": True, "noprogress": True,
        # Short timeouts + few retries: a slow answer is retried quickly instead of hanging
        # the screen for minutes (25 s x 8 retries before).
        "socket_timeout": 10 if fast else 15,
        "retries": 2 if fast else 5, "fragment_retries": 6, "extractor_retries": 1,
        "cachedir": CACHE_DIR or False,
        # There is no ffmpeg on the phone: never try to post-process/fix containers.
        "fixup": "never", "postprocessors": [],
    }
    ea = CLIENT_ARGS.get(src)
    if ea:
        o["extractor_args"] = ea
    o.update(extra)
    return o


def clean_err(e):
    s = str(e) or e.__class__.__name__
    s = re.sub(r"\x1b\[[0-9;]*m", "", s)
    s = re.sub(r"^(ERROR:\s*)+", "", s.strip())
    s = re.sub(r"^\[[\w:]+\]\s+[\w-]{3,}:\s*", "", s)  # drop "[youtube] abc123:" prefix
    if "Sign in to confirm" in s or "not a bot" in s:
        s = "YouTube asked for a sign-in check for this video. Try again in a minute."
    elif "HTTP Error 403" in s:
        s = "YouTube refused the video link (403) even after getting a fresh one. Try another quality or try again later."
    return s.strip()[:300]


def is_youtube(url):
    host = (urlparse(url).hostname or "").lower()
    return host.endswith(("youtube.com", "youtu.be"))


def check_url(url):
    try:
        p = urlparse(url)
    except Exception:
        abort(400, "Invalid URL")
    host = (p.hostname or "").lower()
    if p.scheme not in ("http", "https") or not any(
        host == d or host.endswith("." + d) for d in ALLOWED_DOMAINS
    ):
        abort(400, "Unsupported link. Use YouTube, Facebook, Instagram or Snapchat.")
    return url


def youtube_id(url):
    m = re.search(r"(?:v=|youtu\.be/|shorts/|embed/)([A-Za-z0-9_-]{11})", url)
    return m.group(1) if m else None


def safe_name(s):
    return re.sub(r'[\\/:*?"<>|\n\r]+', " ", s or "").strip()[:90] or "video"


@app.errorhandler(400)
def bad_request(e):
    return jsonify(error=getattr(e, "description", "Bad request")), 400


@app.errorhandler(404)
def not_found(e):
    return jsonify(error="Not found"), 404


@app.get("/")
def index():
    return Response(INDEX_HTML, mimetype="text/html")


# ---------------------------------------------------------------- engine status

@app.get("/api/engine")
def engine():
    try:
        from yt_dlp.version import __version__ as ytv
    except Exception:
        ytv = "unknown"
    try:
        from java import jclass  # noqa: F401
        muxer = True
    except Exception:
        muxer = False
    return jsonify(ytdlp=ytv, clients=list(YT_SOURCES), muxer=muxer,
                   cached=len(info_cache), jobs=sum(1 for j in jobs.values() if j.get("status") in ("downloading", "processing")))


# ---------------------------------------------------------------- search / feed

def _entry_to_item(e):
    return {
        "id": e["id"],
        "title": e.get("title"),
        "channel": e.get("channel") or e.get("uploader"),
        "channel_id": e.get("channel_id") or e.get("uploader_id"),
        "uploader_id": e.get("uploader_id"),
        "channel_url": e.get("channel_url"),
        "duration": e.get("duration"),
        "width": e.get("width"),
        "height": e.get("height"),
        "views": e.get("view_count"),
        "thumb": f"https://i.ytimg.com/vi/{e['id']}/mqdefault.jpg",
        "url": f"https://www.youtube.com/watch?v={e['id']}",
    }


def yt_search(q, n=PAGE_SIZE, fresh=False):
    """One YouTube search. Normal pagination is cached; an explicit feed refresh bypasses it.

    A phrase that starts with "@recent " is searched newest-first (YouTube's own upload-date
    sort) so the feed shows videos that were just published instead of the same all-time top
    results. If that mode fails for any reason, it falls back to the normal search.
    """
    recent = q.startswith("@recent ")
    if recent:
        q = q[len("@recent "):]
    key = ("r:" if recent else "") + " ".join(q.lower().split())
    with key_lock("s:" + key):
        hit = search_cache.get(key)
        if not fresh and hit and hit[0] > time.time() and (len(hit[1]) >= n or hit[2]):
            return hit[1][:n]
        data = None
        if recent:
            try:
                url = "https://www.youtube.com/results?search_query=" + quote_plus(q) + "&sp=CAI%3D"
                with yt_dlp.YoutubeDL(base_opts(fast=True, extract_flat=True, skip_download=True, playlistend=n)) as ydl:
                    data = ydl.extract_info(url, download=False)
            except Exception:
                data = None
        if not data or not (data.get("entries") or []):
            with yt_dlp.YoutubeDL(base_opts(fast=True, extract_flat=True, skip_download=True)) as ydl:
                data = ydl.extract_info(f"ytsearch{n}:{q}", download=False)
        out = [_entry_to_item(e) for e in (data.get("entries") or []) if e and e.get("id")][:n]
        search_cache[key] = (time.time() + 900, out, len(out) < n)  # fewer than asked = no more results
        for k in sorted(search_cache, key=lambda x: search_cache[x][0])[:-120]:  # keep the cache small
            search_cache.pop(k, None)
        return out


# ---- channel RSS (free, no key, no quota): latest uploads of channels the viewer follows
rss_cache = {}
CHANNEL_ID_RE = re.compile(r"^UC[\w-]{22}$")
_ATOM = {"a": "http://www.w3.org/2005/Atom", "yt": "http://www.youtube.com/xml/schemas/2015",
         "m": "http://search.yahoo.com/mrss/"}


def channel_rss(cid):
    hit = rss_cache.get(cid)
    if hit and hit[0] > time.time():
        return hit[1]
    out = []
    try:
        r = HTTP.get(f"https://www.youtube.com/feeds/videos.xml?channel_id={cid}", timeout=6)
        r.raise_for_status()
        root = ET.fromstring(r.content)
        for e in root.findall("a:entry", _ATOM)[:12]:
            vid = e.findtext("yt:videoId", default="", namespaces=_ATOM)
            title = e.findtext("a:title", default="", namespaces=_ATOM)
            if not vid or "#short" in title.lower():
                continue
            views = None
            st = e.find("m:group/m:community/m:statistics", _ATOM)
            if st is not None and st.get("views", "").isdigit():
                views = int(st.get("views"))
            out.append({
                "id": vid, "title": title,
                "channel": e.findtext("a:author/a:name", default="", namespaces=_ATOM),
                "channel_id": cid, "uploader_id": cid,
                "channel_url": f"https://www.youtube.com/channel/{cid}",
                "duration": None, "width": None, "height": None, "views": views,
                "thumb": f"https://i.ytimg.com/vi/{vid}/mqdefault.jpg",
                "url": f"https://www.youtube.com/watch?v={vid}",
            })
    except Exception:
        out = []
    rss_cache[cid] = (time.time() + 600, out)
    if len(rss_cache) > 200:
        rss_cache.clear()
    return out


def rss_items(channel_ids, rng, per_channel=2, max_channels=3):
    ids = [c for c in dict.fromkeys(channel_ids) if CHANNEL_ID_RE.match(c)]
    if not ids:
        return []
    picks = rng.sample(ids, min(max_channels, len(ids)))
    lists = [[] for _ in picks]

    def work(i, c):
        lists[i] = channel_rss(c)

    threads = [threading.Thread(target=work, args=(i, c), daemon=True) for i, c in enumerate(picks)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(7)
    out = []
    for lst in lists:
        lst = list(lst)
        rng.shuffle(lst)          # newest uploads mixed, not always the very same first video
        out.extend(lst[:per_channel])
    return out


def prefetch(fn, *args):
    """Warm the cache for what the user will most likely ask next (the next page)."""
    def run():
        try:
            fn(*args)
        except Exception:
            pass
    threading.Thread(target=run, daemon=True).start()


def multi_search(queries, n=PAGE_SIZE, fresh=False):
    """Run several searches at the same time and weave the results together (A1 B1 C1 A2 B2 ...)."""
    queries = [q for q in dict.fromkeys(q.strip() for q in queries) if q]
    lists, errors = [[] for _ in queries], []

    def work(i, q):
        try:
            lists[i] = yt_search(q, n, fresh=fresh)
        except Exception as e:  # one bad phrase must not kill the page
            errors.append(clean_err(e))

    threads = [threading.Thread(target=work, args=(i, q), daemon=True) for i, q in enumerate(queries)]
    for t in threads:
        t.start()
    deadline = time.time() + 20
    for t in threads:
        t.join(max(0.1, deadline - time.time()))  # one slow phrase no longer blocks the page for 45 s
    seen, out = set(), []
    for row in itertools.zip_longest(*lists):
        for item in row:
            if item and item["id"] not in seen:
                seen.add(item["id"])
                out.append(item)
    if not out and errors:
        raise RuntimeError(errors[0])
    return out


def _mod(page, shift=0):
    return MODS[(page + shift) % len(MODS)]


# Country-aware discovery profiles. These are search hints, not hard country filters:
# a viewer in one country should see what is trending there, while still discovering
# globally popular creators and languages.
REGION_LANGUAGES = {
    "pakistan": "Urdu Hindi English", "india": "Hindi English", "bangladesh": "Bangla English",
    "united states": "English", "united kingdom": "English", "canada": "English French",
    "australia": "English", "new zealand": "English", "ireland": "English",
    "united arab emirates": "Arabic English Hindi", "saudi arabia": "Arabic English",
    "qatar": "Arabic English", "kuwait": "Arabic English", "oman": "Arabic English",
    "turkiye": "Turkish English", "turkey": "Turkish English", "indonesia": "Indonesian English",
    "malaysia": "Malay English", "philippines": "Filipino English", "sri lanka": "Sinhala Tamil English",
    "nepal": "Nepali Hindi English", "south korea": "Korean English", "japan": "Japanese English",
    "nigeria": "English", "south africa": "English", "egypt": "Arabic English",
    "france": "French English", "germany": "German English", "spain": "Spanish English",
    "brazil": "Portuguese English", "mexico": "Spanish English", "italy": "Italian English",
}


def regional_queries(cat, page, region, tags, rng=None):
    """Return two localized trend searches; never restrict results to this country."""
    country = re.sub(r"[^A-Za-z0-9 .'-]", "", str(region or ""))[:60].strip()
    if not country:
        return []
    language = REGION_LANGUAGES.get(country.lower(), "English")
    topic = {
        "shorts": "Shorts short videos",
        "music": "music songs performances",
        "movies": "movie scenes trailers entertainment",
        "gaming": "gaming highlights gameplay",
        "funny": "comedy funny moments",
        "news": "most watched news stories",
        "diy": "DIY satisfying how-to videos",
        "related": "popular related videos",
    }.get(cat, "viral popular entertaining videos")
    clean_tag = next((re.sub(r"[^\w .'-]", " ", str(t), flags=re.UNICODE).strip()[:45]
                      for t in (tags or []) if str(t).strip()), "")
    if clean_tag:
        first = f"{clean_tag} {topic} trending in {country} {language}"
    else:
        first = f"{topic} trending in {country} {language}"
    second = f"{topic} {country} {language} {(rng.choice(['new', 'latest', 'best', 'viral']) if rng else 'viral')}"
    # Rotate order so page refreshes do not always privilege the same localized query.
    flip = (rng.random() < 0.5) if rng else (page % 2 == 0)
    return [first, second] if flip else [second, first]


# ---- discovery pools. Every page draws a RANDOM sample (seeded per refresh), so the feed changes
# whenever it is refreshed and after a reinstall; nothing is a fixed list by page number any more.
GLOBAL_POOL = [
    "funny comedy moments", "amazing facts science inventions", "cute animals wildlife", "best movie scenes",
    "football basketball highlights", "viral music performances", "gaming funny moments", "street food cooking",
    "satisfying restoration craftsmanship", "travel nature beautiful places", "technology gadgets reviews",
    "talent magic performances", "history mysteries documentary", "diy life hacks", "car and bike reviews",
    "kids cartoon stories", "motivational speech", "daily vlog", "cricket highlights", "new trailers",
    "fashion and makeup tips", "health and fitness workout", "podcast clips interesting", "dance performance",
]
REGION_POOLS = {
    "pakistan": ["Urdu naat sharif new", "Pakistani songs new", "Urdu news headlines today", "Urdu kids cartoon stories",
                 "Pakistani drama best scenes", "Urdu funny clips", "cricket highlights Pakistan", "Pakistani street food",
                 "Punjabi songs new", "Pakistani vlog", "Urdu motivational bayan", "Pakistani stage drama comedy clips",
                 "Quran recitation beautiful", "Pashto songs new", "Urdu poetry shayari", "Pakistani cooking recipe Urdu",
                 "Hindi Urdu romantic songs", "Pakistan technology review Urdu", "Pakistani talk show clips",
                 "Coke Studio Pakistan", "PSL cricket highlights"],
    "india": ["Bollywood songs new", "Hindi comedy clips", "Hindi news today", "Indian street food", "IPL cricket highlights",
              "Hindi kids cartoon", "Punjabi songs new", "Tamil songs new", "Telugu movie scenes", "Hindi web series clips",
              "Indian vlog", "Hindi motivational speech", "Indian cooking recipe Hindi", "Hindi tech review"],
    "bangladesh": ["Bangla songs new", "Bangla natok clips", "Bangla news today", "Bangla funny video", "Bangladesh cricket highlights"],
}


def _pool_for(region):
    r = (region or "").strip().lower()
    if r in REGION_POOLS:
        return REGION_POOLS[r]
    lang = REGION_LANGUAGES.get(r, "").split(" ")[0]
    if lang and lang != "English":
        return [f"{lang} songs new", f"{lang} comedy clips", f"{lang} news today", f"{lang} viral videos",
                f"{lang} cooking recipe", f"{lang} movie scenes", f"{lang} vlog"]
    return []


FRESH_WORDS = ["", "", "new", "latest", "best", "today", "this week", "viral", "recent"]


def _discovery(rng, region, k, suffix=""):
    """k random topics: about 60% local/regional, the rest global, each with a random freshness word and
    some of them searched newest-first. Returns search phrases."""
    local = _pool_for(region)
    n_local = min(len(local), max(0, round(k * 0.6))) if local else 0
    topics = rng.sample(local, n_local) + rng.sample(GLOBAL_POOL, k - n_local)
    rng.shuffle(topics)
    out = []
    for t in topics:
        word = rng.choice(FRESH_WORDS)
        q = f"{t} {word} {suffix}".replace("  ", " ").strip()
        if rng.random() < 0.35:
            q = "@recent " + q
        out.append(q)
    return out


def plan_queries(cat, page, tags, title="", channel="", rng=None, region=""):
    """Build the feed searches for one page.

    rng is seeded from (refresh seed, category, page): same refresh + same page = same result (so the
    prefetch cache works), but every refresh / reinstall / new launch gives a different feed.
    """
    rng = rng or random.Random()
    year = time.localtime().tm_year
    qs = []
    clean_tags = []
    for tag in tags or []:
        tag = re.sub(r"[^\w .'-]", " ", str(tag), flags=re.UNICODE).strip()
        tag = re.sub(r"\s+", " ", tag)[:50]
        if len(tag) >= 3 and tag.lower() not in {x.lower() for x in clean_tags}:
            clean_tags.append(tag)
    if cat == "related":
        words = " ".join(re.findall(r"[^\W_]{3,}", title)[:6])
        if channel:
            qs.append(f"{channel} videos {rng.choice(MODS)}".strip())
        if words:
            qs.append(f"{words} videos {rng.choice(MODS)}".strip())
        if clean_tags:
            qs.append(f"{rng.choice(clean_tags)} videos {rng.choice(MODS)}".strip())
        return qs or ["popular videos today"]
    if cat == "shorts":
        if clean_tags:
            for tag in rng.sample(clean_tags, min(3, len(clean_tags))):
                qs.append(f"{tag} vertical short video {rng.choice(MODS)}".strip())
            qs.append(f"{rng.choice(clean_tags)} viral short clips")
            qs.extend(_discovery(rng, region, 1, "shorts"))
        else:
            qs.extend(_discovery(rng, region, 4, "shorts"))
        return qs
    if cat == "foryou":
        if clean_tags:
            # Personal interests lead (random subset each time); two discovery slots avoid a filter bubble.
            for tag in rng.sample(clean_tags, min(3, len(clean_tags))):
                qs.append(f"{tag} {rng.choice(['popular', 'new', 'best', 'latest'])} videos")
            if len(clean_tags) >= 2:
                a, b = rng.sample(clean_tags, 2)
                qs.append(f"{a} {b} trending videos")
            qs.extend(_discovery(rng, region, 2))
        else:
            # Brand-new viewer (or after a reinstall): a wide, random mix of local + global topics.
            qs.extend(_discovery(rng, region, 6))
        return qs
    base = FEEDS[cat]
    for ph in rng.sample(base, min(2, len(base))):
        qs.append(f"{ph} {rng.choice(MODS)}".strip())
    if clean_tags:
        qs.append(f"{rng.choice(clean_tags)} {CAT_WORD.get(cat, '')} {rng.choice(MODS)}".strip())
    local = _pool_for(region)
    if local and cat in ("music", "funny", "news", "movies"):
        key = {"music": "song", "funny": "funny", "news": "news", "movies": "drama"}[cat]
        hits = [t for t in local if key in t.lower()] or local
        qs.append(rng.choice(hits))
    return qs


@app.get("/api/search")
def search():
    q = request.args.get("q", "").strip()
    if not q:
        abort(400, "Empty search")
    try:
        page = max(0, min(int(request.args.get("page", "0")), 9))
    except ValueError:
        page = 0
    size = 20
    try:
        # YouTube has no "page 2" for flat search: ask for more results and keep the new part
        res = yt_search(q, size * (page + 1))[size * page:]
        more = len(res) >= size - 4 and page < 9
        if more:
            prefetch(yt_search, q, size * (page + 2))  # next page is ready before you scroll to it
        return jsonify(results=res, next=page + 1 if more else None)
    except Exception as e:
        return jsonify(error=f"Search failed: {clean_err(e)}"), 502



@app.get("/api/channel")
def channel_videos():
    """Fetch a creator's actual channel uploads using the stable YouTube channel ID."""
    channel_id = request.args.get("id", "")[:80]
    if not re.fullmatch(r"UC[A-Za-z0-9_-]{20,30}", channel_id):
        abort(400, "A valid YouTube channel ID is required")
    try:
        page = max(0, min(int(request.args.get("page", "0")), 20))
    except ValueError:
        page = 0
    try:
        with yt_dlp.YoutubeDL(base_opts(fast=True, extract_flat=True, skip_download=True)) as ydl:
            data = ydl.extract_info(f"https://www.youtube.com/channel/{channel_id}/videos", download=False)
        entries = [e for e in (data.get("entries") or []) if e and e.get("id")]
        start, end = page * PAGE_SIZE, (page + 1) * PAGE_SIZE
        rows = [_entry_to_item(e) for e in entries[start:end]]
        return jsonify(results=rows, next=page + 1 if end < len(entries) else None,
                       channel_id=channel_id, channel=data.get("title"))
    except Exception as e:
        return jsonify(error=f"Could not load channel videos: {clean_err(e)}"), 502


@app.get("/api/region")
def region():
    """Detect the visitor's country from the public IP; fall back to the device locale."""
    now = time.time()
    if region_cache["value"] and region_cache["exp"] > now:
        return jsonify(region_cache["value"])
    result = None
    try:
        response = HTTP.get("https://ipwho.is/", timeout=(1.5, 2.0),
                            headers={"User-Agent": "Vidora/2.5"})
        data = response.json()
        if response.ok and data.get("success") and data.get("country_code"):
            result = {"country_code": str(data["country_code"]).upper(),
                      "country": str(data.get("country") or data["country_code"])[:60],
                      "source": "ip"}
    except Exception:
        pass
    if not result:
        locale = request.args.get("locale", "")
        match = re.search(r"(?:-|_)([A-Za-z]{2})$", locale)
        code = match.group(1).upper() if match else ""
        timezone = request.args.get("timezone", "")[:80]
        zone_codes = {"Asia/Karachi":"PK", "Asia/Dhaka":"BD", "Asia/Kolkata":"IN",
                      "Asia/Dubai":"AE", "Asia/Riyadh":"SA", "Europe/London":"GB",
                      "America/New_York":"US", "America/Chicago":"US", "America/Denver":"US",
                      "America/Los_Angeles":"US", "America/Toronto":"CA", "Australia/Sydney":"AU",
                      "Europe/Istanbul":"TR", "Asia/Kuala_Lumpur":"MY", "Asia/Manila":"PH",
                      "Asia/Jakarta":"ID", "Asia/Colombo":"LK", "Africa/Lagos":"NG"}
        if not code:
            code = zone_codes.get(timezone, "")
        names = {"PK":"Pakistan", "US":"United States", "GB":"United Kingdom", "IN":"India",
                 "AE":"United Arab Emirates", "SA":"Saudi Arabia", "BD":"Bangladesh",
                 "CA":"Canada", "AU":"Australia", "TR":"Türkiye", "NG":"Nigeria",
                 "ID":"Indonesia", "MY":"Malaysia", "PH":"Philippines", "LK":"Sri Lanka"}
        result = {"country_code": code or None, "country": names.get(code), "source": "device"}
    region_cache["value"], region_cache["exp"] = result, now + 43200
    return jsonify(result)

_short_cache = {}  # video id -> bool


def _is_short(vid):
    if vid in _short_cache:
        return _short_cache[vid]
    ok = False
    try:
        r = HTTP.head(f"https://www.youtube.com/shorts/{vid}", allow_redirects=False, timeout=6,
                      headers={"User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36",
                               "Accept-Language": "en-US,en;q=0.8"})
        loc = r.headers.get("Location", "")
        ok = r.status_code == 200 or (r.status_code in (301, 302, 303, 307, 308) and "/shorts/" in loc)
    except requests.RequestException:
        return False  # unknown right now: leave it out, do not cache
    _short_cache[vid] = ok
    if len(_short_cache) > 4000:
        _short_cache.clear()
    return ok


def filter_shorts(items):
    """Keep only real vertical Shorts (checked in parallel, remembered per video)."""
    flags = {}

    def work(v):
        flags[v["id"]] = _is_short(str(v["id"]))

    threads = [threading.Thread(target=work, args=(v,), daemon=True) for v in items]
    for th in threads:
        th.start()
    deadline = time.time() + 8
    for th in threads:
        th.join(max(0.1, deadline - time.time()))
    out = []
    for v in items:
        if flags.get(v["id"]):
            v = dict(v)
            v["url"] = f"https://www.youtube.com/shorts/{v['id']}"
            out.append(v)
    return out


def _page_rng(seed, cat, page):
    """Deterministic per (refresh seed, category, page) so prefetching works; seed 0 = fully random."""
    if not seed:
        return random.Random()
    return random.Random(f"{seed}:{cat}:{page}")


def _plan_all(cat, page, tags, title, channel, region, seed):
    rng = _page_rng(seed, cat, page)
    queries = plan_queries(cat, page, tags, title, channel, rng=rng, region=region)
    # Warm viewers also get two localized trend searches; brand-new viewers already get a
    # local + global mix from plan_queries, so adding more would only slow the page down.
    if region and cat in ("foryou", "shorts") and tags:
        queries = queries[:4] + regional_queries(cat, page, region, tags, rng)[:2]
    elif region and cat not in ("related", "foryou", "shorts"):
        queries = queries[:3] + regional_queries(cat, page, region, tags, rng)[:1]
    return queries


@app.get("/api/feed")
def feed():
    cat = request.args.get("cat", "foryou")
    if cat not in FEEDS and cat not in ("foryou", "related"):
        abort(400, "Unknown category")
    try:
        page = max(0, min(int(request.args.get("page", "0")), 500))
    except ValueError:
        page = 0
    try:
        seed = int(request.args.get("seed", "0"))
    except ValueError:
        seed = 0
    tags = [t.strip()[:50] for t in request.args.get("tags", "").split("|") if t.strip()][:8]
    subs = [t.strip()[:50] for t in request.args.get("subs", "").split("|") if t.strip()][:5]
    sub_ids = [t.strip() for t in request.args.get("subids", "").split("|") if t.strip()][:40]
    tags = list(dict.fromkeys(tags + subs))[:8]
    excluded = {x.strip()[:80] for x in request.args.get("exclude", "").split("|") if x.strip()}
    excluded.update(x.strip()[:80] for x in request.args.get("exclude_seen", "").split("|") if x.strip())
    excluded_channels = {x.strip()[:100].lower() for x in request.args.get("exclude_channels", "").split("|") if x.strip()}
    title, channel = request.args.get("title", "")[:150], request.args.get("channel", "")[:60]
    region = re.sub(r"[^A-Za-z0-9 .'-]", "", request.args.get("region", "")[:60]).strip()
    fresh = request.args.get("fresh", "0") == "1" and page == 0
    queries = _plan_all(cat, page, tags, title, channel, region, seed)
    try:
        res = multi_search(queries, fresh=fresh)
        # Newest uploads of channels the viewer follows (channel RSS: free, no quota), mixed in.
        if cat in ("foryou", "music", "movies", "funny", "news", "gaming", "diy") and sub_ids:
            extra = rss_items(sub_ids, _page_rng(seed, "rss" + cat, page))
            res = [v for pair in itertools.zip_longest(res, extra) for v in pair if v]
        if cat == "shorts":
            # Search results carry no video size, so the old width/height filter removed everything.
            # YouTube answers /shorts/<id> with 200 only for real (vertical) Shorts and redirects
            # every other video to /watch, so one cheap request per video tells them apart.
            res = filter_shorts([v for v in res if not v.get("duration") or v.get("duration") <= 185])
        elif cat not in ("movies", "related"):
            # Home and category feeds: no 2-hour "full movie" walls. Long videos stay in Movies / search.
            res = [v for v in res if not v.get("duration") or v["duration"] <= 1500]
            res = [v for v in res if "full movie" not in (v.get("title") or "").lower()]
        if excluded:
            res = [v for v in res if str(v.get("id", "")) not in excluded]
        if excluded_channels:
            res = [v for v in res if str(v.get("channel_id") or v.get("uploader_id") or "").lower() not in excluded_channels]
        # Search phrases overlap heavily. Weave creators as well as video IDs so a
        # single prolific channel cannot occupy most of a feed page.
        creator_seen, diverse, overflow = set(), [], []
        for item in res:
            creator = str(item.get("channel_id") or item.get("uploader_id") or item.get("channel") or item.get("id") or "").lower()
            if creator not in creator_seen:
                creator_seen.add(creator)
                diverse.append(item)
            else:
                overflow.append(item)
        res = diverse + overflow[:max(0, 4 - len(diverse))]
        # A light shuffle of the page (keeps the strongest hits near the top, but no two refreshes match).
        if seed and len(res) > 6:
            head, tail = res[:3], res[3:]
            _page_rng(seed, "mix" + cat, page).shuffle(tail)
            res = head + tail
        if cat != "related":
            prefetch(multi_search, _plan_all(cat, page + 1, tags, title, channel, region, seed))
        return jsonify(results=res, next=page + 1, region=region or None, fresh=fresh)
    except Exception as e:
        return jsonify(error=f"Could not load videos: {clean_err(e)}"), 502


# ---------------------------------------------------------------- comments (Shorts comment sheet)
comment_cache = {}


@app.get("/api/comments")
def comments():
    url = check_url(request.args.get("url", "").strip())
    hit = comment_cache.get(url)
    if hit and hit[0] > time.time():
        return jsonify(results=hit[1])
    opts = base_opts(fast=True, skip_download=True, getcomments=True, extract_flat=False,
                     extractor_args={"youtube": {"max_comments": ["30", "0", "0", "0"], "comment_sort": ["top"],
                                                 "skip": ["dash", "hls", "translated_subs"]}})
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            i = ydl.extract_info(url, download=False)
    except Exception as e:
        return jsonify(error="Comments are unavailable right now: " + clean_err(e)), 502
    out = []
    for c in (i.get("comments") or [])[:30]:
        if c.get("parent") not in (None, "root"):
            continue
        out.append({"author": c.get("author"), "text": (c.get("text") or "")[:600], "likes": c.get("like_count") or 0,
                    "time": c.get("_time_text") or ""})
    comment_cache[url] = (time.time() + 600, out)
    if len(comment_cache) > 60:
        comment_cache.pop(next(iter(comment_cache)), None)
    return jsonify(results=out, total=i.get("comment_count"))


# ---------------------------------------------------------------- info / quality options

def _size(f, dur):
    s = f.get("filesize") or f.get("filesize_approx")
    if not s and (f.get("tbr") or f.get("abr")) and dur:
        s = int((f.get("tbr") or f.get("abr")) * 125 * dur)
    return s


def _has_v(f):
    return f.get("vcodec") not in (None, "none")


def _has_a(f):
    return f.get("acodec") not in (None, "none")


def _vc(f):
    return str(f.get("vcodec") or "").lower()


def _ac(f):
    return str(f.get("acodec") or "").lower()


def _res(f):
    """Quality label number. Portrait videos (shorts) are labelled by their short side."""
    h, w = f.get("height"), f.get("width")
    if h and w and h > w:
        return w
    return h


def _tag(h):
    if h >= 4320:
        return "8K"
    if h >= 2160:
        return "4K"
    if h >= 1440:
        return "2K"
    if h >= 1080:
        return "Full HD"
    if h >= 720:
        return "HD"
    return ""


def _rate(f):
    return f.get("tbr") or f.get("abr") or f.get("vbr") or 0


def make_options(i, src):
    """Build the choices shown to the user from one extraction result.

    direct  = one file that already has video and sound (any container).
    merge   = separate video + audio, joined on the phone after download:
              H.264 + AAC -> .mp4        VP9 + Opus -> .webm  (this is how 1440p / 4K ship)
    extract = take the sound track out of a normal video file (when no audio-only stream exists).
    """
    fmts = [f for f in (i.get("formats") or [])
            if "m3u8" not in str(f.get("protocol", "")) and f.get("format_id")]
    dur = i.get("duration") or 0

    aonly = [f for f in fmts if _has_a(f) and not _has_v(f) and "drc" not in str(f["format_id"]).lower()]
    aac = [f for f in aonly if _ac(f).startswith("mp4a")]
    opus = [f for f in aonly if _ac(f).startswith("opus")]

    def best(lst):
        return max(lst, key=lambda f: (f.get("language_preference") or 0, _rate(f))) if lst else None

    best_aac, best_opus = best(aac), best(opus)

    # ---- video: one entry per resolution, best way of getting it wins
    vids = {}

    def offer(res, score, opt, rate):
        cur = vids.get(res)
        if not cur or (score, rate) > (cur["_s"], cur["_r"]):
            opt.update(_s=score, _r=rate)
            vids[res] = opt

    for f in fmts:
        if not _has_v(f):
            continue
        res = _res(f)
        if not res:
            continue
        r = _rate(f)
        if _has_a(f):  # ready-made file with sound
            ext = f.get("ext") or "mp4"
            offer(res, 30 if ext == "mp4" else 10,
                  {"mode": "direct", "fmt": f["format_id"], "ext": ext, "size": _size(f, dur)}, r)
            continue
        vs = _size(f, dur)
        if _vc(f).startswith(("avc1", "h264")) and f.get("ext") == "mp4" and best_aac:
            asz = _size(best_aac, dur)
            offer(res, 20, {"mode": "merge", "vid": f["format_id"], "aid": best_aac["format_id"], "ext": "mp4",
                            "size": (vs + asz) if vs and asz else vs}, r)
        elif _vc(f).startswith(("vp9", "vp09", "vp8")) and best_opus:
            asz = _size(best_opus, dur)
            offer(res, 15, {"mode": "merge", "vid": f["format_id"], "aid": best_opus["format_id"], "ext": "webm",
                            "size": (vs + asz) if vs and asz else vs}, r)

    out = []
    for res, o in vids.items():
        o = {k: v for k, v in o.items()}
        o.update(key=str(res), label=f"{res}p", tag=_tag(res), kind="video", src=src, res=res)
        out.append(o)

    # ---- audio: every real audio stream (bitrate x format)
    seen = {}
    for f in aonly:
        a = _ac(f)
        name = "M4A" if a.startswith("mp4a") else "OPUS" if a.startswith("opus") else (f.get("ext") or "AUDIO").upper()
        abr = int(round(f.get("abr") or f.get("tbr") or 0))
        k = (name, abr)
        cur = seen.get(k)
        if not cur or (f.get("language_preference") or 0) > (cur.get("language_preference") or 0):
            seen[k] = f
    for (name, abr), f in seen.items():
        out.append({"key": "a" + str(f["format_id"]), "label": f"{abr}K" if abr else "Audio", "tag": "",
                    "kind": "audio", "mode": "direct", "fmt": f["format_id"], "ext": name,
                    "size": _size(f, dur), "src": src, "abr": abr})

    if not aonly:
        # no audio-only stream (Instagram, Snapchat...): pull the sound out of the smallest AAC video
        cands = [f for f in fmts if _has_v(f) and _has_a(f) and _ac(f).startswith("mp4a")]
        if cands:
            f = min(cands, key=lambda x: (_res(x) or 9999, _rate(x)))
            abr = int(round(f.get("abr") or 128))
            out.append({"key": "aextract", "label": "Audio", "tag": "", "kind": "audio", "mode": "extract",
                        "fmt": f["format_id"], "ext": "M4A", "size": int(abr * 125 * dur) if dur else None,
                        "src": src, "abr": abr})
    return out


def combine_options(per_src):
    """Merge the option lists of several extractions: best way per resolution, all audio streams."""
    vids, auds = {}, {}
    for src, opts in per_src:
        for o in opts:
            if o["kind"] == "video":
                cur = vids.get(o["key"])
                if not cur or (o["_s"], o["_r"]) > (cur["_s"], cur["_r"]):
                    vids[o["key"]] = o
            else:
                k = (o["ext"], o.get("abr"))
                if k not in auds:
                    auds[k] = o
    v = sorted(vids.values(), key=lambda o: -o["res"])
    if any(o["mode"] != "extract" for o in auds.values()):
        auds = {k: o for k, o in auds.items() if o["mode"] != "extract"}  # real audio streams exist
    a = sorted(auds.values(), key=lambda o: (o["ext"] != "M4A", -(o.get("abr") or 0)))
    opts = v + a
    if not opts:
        opts.append({"key": "best", "label": "Best quality", "tag": "", "kind": "video", "mode": "direct",
                     "fmt": "best", "ext": "mp4", "size": None, "src": "default"})
    for o in opts:
        o.pop("_s", None)
        o.pop("_r", None)
    return opts


def _extract(url, src, results, errors, stamps):
    try:
        # format "b*" always resolves when ANY stream exists, so listing never fails on selection
        o = base_opts(src, skip_download=True, format="b*", ignore_no_formats_error=True)
        with yt_dlp.YoutubeDL(o) as ydl:
            results[src] = ydl.extract_info(url, download=False)
        stamps[src] = time.time()
    except Exception as e:
        errors[src] = clean_err(e)


INFO_TTL = 1800  # YouTube links stay valid ~6 h; re-read after 30 min to be safe


def _build_entry(infos):
    per_src, first = [], None
    for s, i in infos.items():
        try:
            per_src.append((s, make_options(i, s)))
            if first is None or s == "default":
                first = i
        except Exception:
            pass
    first = first or next(iter(infos.values()))
    return {
        "exp": time.time() + INFO_TTL, "infos": dict(infos), "opts": combine_options(per_src),
        "small": {k: first.get(k) for k in ("title", "uploader", "duration", "thumbnail", "view_count")},
        "streams": {},
    }


def _run_sources(url, srcs, cap):
    """Ask several clients at once. Return as soon as the main one ("default") has answered
    (+ a short grace for the others), instead of always waiting 7 s after the first answer.
    Clients that answer later are merged into the cached entry in the background."""
    results, errors, stamps = {}, {}, {}
    threads = {s: threading.Thread(target=_extract, args=(url, s, results, errors, stamps), daemon=True)
               for s in srcs}
    for t in threads.values():
        t.start()
    t0 = time.time()
    main = srcs[0]
    while any(t.is_alive() for t in threads.values()):
        now = time.time()
        if main in stamps and now - stamps[main] > 1.0:
            break  # main client answered: give the rest one second, then go
        if main in errors and stamps and now - min(stamps.values()) > 1.0:
            break  # main client failed, another one answered
        if now - t0 > cap:
            break
        time.sleep(0.05)
    late = [s for s, t in threads.items() if t.is_alive()]
    return results, errors, threads, late


def _merge_late(url, threads, results):
    for t in threads:
        t.join(40)
    entry = info_cache.get(url)
    if not entry:
        return
    new = {s: i for s, i in results.items() if s not in entry["infos"]}
    if new:
        merged = _build_entry({**entry["infos"], **new})
        merged["exp"] = entry["exp"]
        info_cache[url] = merged


def _has_adaptive(infos):
    return any(_has_v(f) and not _has_a(f) for i in infos.values() for f in (i.get("formats") or []))


def get_info(url, refresh=False):
    with key_lock("i:" + url):
        hit = info_cache.get(url)
        if hit and hit["exp"] > time.time() and not refresh:
            return hit
        yt = is_youtube(url)
        srcs = YT_SOURCES if yt else ("default",)
        results, errors, threads, late = _run_sources(url, srcs, 30)
        infos = {s: results[s] for s in srcs if s in results}
        if yt and not _has_adaptive(infos):
            # only the 360p file (or nothing) came back: try the fallback client too
            r2, e2, _, _ = _run_sources(url, YT_FALLBACK, 25)
            infos.update(r2)
            errors.update(e2)
        if not infos:
            raise RuntimeError(next(iter(errors.values()), "No response from the site"))
        entry = _build_entry(infos)
        info_cache[url] = entry
        for u in sorted(info_cache, key=lambda x: info_cache[x]["exp"])[:-20]:  # keep the 20 newest
            info_cache.pop(u, None)
        if late:
            threading.Thread(target=_merge_late, args=(url, [threads[s] for s in late], results),
                             daemon=True).start()
        return entry


@app.get("/api/info")
def info():
    url = check_url(request.args.get("url", "").strip())
    try:
        e = get_info(url)
    except Exception as ex:
        return jsonify(error=f"Could not read this link: {clean_err(ex)}"), 502
    i = e["small"]
    return jsonify(
        url=url, title=i.get("title"), uploader=i.get("uploader"),
        duration=i.get("duration"), thumb=i.get("thumbnail"),
        youtube_id=youtube_id(url), views=i.get("view_count"),
        play=play_heights(e),
        options=[{k: o.get(k) for k in ("key", "label", "tag", "size", "kind", "mode", "ext")} for o in e["opts"]],
    )


@app.get("/api/preview")
def preview():
    url = check_url(request.args.get("url", "").strip())
    now = time.time()
    cached = preview_cache.get(url)
    if not cached or cached[0] < now:
        opts = base_opts(format="best[protocol^=http][ext=mp4]/best[protocol^=http]")
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                i = ydl.extract_info(url, download=False)
        except Exception:
            abort(400, "Preview unavailable")
        if not i.get("url"):
            abort(400, "Preview unavailable")
        cached = (now + 300, i["url"], i.get("http_headers", {}))
        preview_cache[url] = cached
    _, direct, headers = cached
    h = dict(headers)
    if request.headers.get("Range"):
        h["Range"] = request.headers["Range"]
    r = HTTP.get(direct, headers=h, stream=True, timeout=(8, 20))
    if r.status_code in (403, 404, 410):
        preview_cache.pop(url, None)
    return relay(r)


# ---------------------------------------------------------------- streaming (own player)

def _stream_ok(f):
    """A format the phone's player can open straight from a URL (no DASH / HLS manifests)."""
    proto = str(f.get("protocol", ""))
    return bool(f.get("url")) and f.get("format_id") and "m3u8" not in proto and "dash" not in proto \
        and "drc" not in str(f["format_id"]).lower()


def _vonly_ok(f, relaxed=False):
    """A video-only stream the WebView player can decode well: H.264 in MP4 (hardware decoding on
    every phone) or VP9 in WebM. AV1 is skipped (slow / missing on many phones)."""
    v = _vc(f)
    # Prefer the widest Android/WebView hardware compatibility: H.264 in MP4.
    # VP9/WebM support varies by device and was a common cause of decoder errors.
    if _has_v(f) and not _has_a(f) and v.startswith(("avc1", "h264")) and f.get("ext") == "mp4":
        return True
    # Last resort, only used when a video has NO H.264 stream at all: VP9 in WebM (Android WebView can
    # decode it on nearly every phone). Without this such videos ended in "not supported by this device".
    return bool(relaxed and _has_v(f) and not _has_a(f) and v.startswith(("vp9", "vp09")) and f.get("ext") == "webm")


PLAY_MAX = 1080  # higher than this stutters on most phones when played from the network


def play_heights(entry):
    """Qualities the player's quality menu shows.

    dual=False : one file with video + sound (YouTube only has 360p like this).
    dual=True  : separate video and sound streams played together (all other qualities).
    """
    dur = entry["small"].get("duration") or 0
    one, two = {}, {}
    best_a = 0
    for info in entry["infos"].values():
        for f in info.get("formats") or []:
            if not _stream_ok(f):
                continue
            if _has_a(f) and not _has_v(f):
                best_a = max(best_a, _size(f, dur) or 0) if _ac(f).startswith("mp4a") else best_a
            r = _res(f)
            if not r:
                continue
            if _has_v(f) and _has_a(f):
                one[r] = max(one.get(r, 0), _size(f, dur) or 0)
            elif _vonly_ok(f) and r <= PLAY_MAX:
                two[r] = max(two.get(r, 0), _size(f, dur) or 0)
    if not two and not one:
        for info in entry["infos"].values():
            for f in info.get("formats") or []:
                r = _res(f)
                if r and r <= PLAY_MAX and _stream_ok(f) and _vonly_ok(f, True):
                    two[r] = max(two.get(r, 0), _size(f, dur) or 0)
    out = {}
    for r, sz in two.items():
        out[r] = {"res": r, "label": f"{r}p", "size": (sz + best_a) or None, "dual": True}
    for r, sz in one.items():  # a ready-made file wins: simpler and always in sync
        out[r] = {"res": r, "label": f"{r}p", "size": sz or None, "dual": False}
    return [out[r] for r in sorted(out, reverse=True)]


def pick_stream(entry, mode, q):
    """Choose one streamable format.
    mode=audio : sound only (small, saves data, used for background play and for dual playback)
    mode=video : one file with video + sound, <= q pixels
    mode=vonly : video without sound, <= q pixels (played together with mode=audio)
    """
    cache = entry["streams"]
    if (mode, q) in cache:
        return cache[(mode, q)]
    best, best_key = None, None
    for relax in ((False, True) if mode == "vonly" else (False,)):
      if best is not None:
        break
      for src, info in entry["infos"].items():
        for f in info.get("formats") or []:
            if not _stream_ok(f):
                continue
            if mode == "audio":
                if not _has_a(f):
                    continue
                abr = f.get("abr") or f.get("tbr") or 0
                # audio-only first, AAC (plays everywhere) first, then ~128 kbit is plenty for a phone
                key = (not _has_v(f), _ac(f).startswith("mp4a"), -abs(min(abr, 192) - 128))
            elif mode in ("vonly", "vany"):
                if mode == "vany":  # any codec: only used for the FFmpeg "convert for this device" path
                    if not (_has_v(f) and not _has_a(f)) or not _res(f):
                        continue
                elif not _vonly_ok(f, relax) or not _res(f):
                    continue
                r = _res(f)
                key = (r <= q, r if r <= q else -r, _vc(f).startswith("avc1"), -_rate(f))
            else:
                if not (_has_v(f) and _has_a(f)) or not _res(f):
                    continue
                r = _res(f)
                # nearest quality that is not above the wanted one (else the lowest one above it)
                key = (r <= q, r if r <= q else -r, _vc(f).startswith(("avc1", "h264")), f.get("ext") == "mp4", _rate(f))
            if best_key is None or key > best_key:
                best, best_key = f, key
    pick = None
    if best:
        pick = {"url": best["url"], "headers": best.get("http_headers") or {}}
    cache[(mode, q)] = pick
    return pick


GV_CHUNK = 10 * 1024 * 1024  # YouTube's servers slow down / refuse very long ranges: ask in 10 MB pieces


def open_upstream(direct, headers, range_hdr):
    """Open the remote media file with proper Range support (seeking)."""
    h = dict(headers or {})
    gv = (urlparse(direct).hostname or "").endswith("googlevideo.com")
    m = re.match(r"bytes=(\d*)-(\d*)$", range_hdr or "")
    if gv:
        start = int(m.group(1)) if m and m.group(1) else 0
        end = int(m.group(2)) if m and m.group(2) else None
        cap = start + GV_CHUNK - 1
        h["Range"] = f"bytes={start}-{cap if end is None else min(end, cap)}"
    elif range_hdr:
        h["Range"] = range_hdr
    return HTTP.get(direct, headers=h, stream=True, timeout=(8, 20))


def relay(r):
    resp = Response(r.iter_content(65536), status=r.status_code)
    for k in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges"):
        if k in r.headers:
            resp.headers[k] = r.headers[k]
    resp.headers.setdefault("Accept-Ranges", "bytes")
    resp.headers["Cache-Control"] = "no-store"
    resp.call_on_close(r.close)
    return resp


@app.get("/api/stream")
def stream():
    """The player's source. ?url=<page link>&mode=video|vonly|audio&q=<max height>"""
    url = check_url(request.args.get("url", "").strip())
    mode = request.args.get("mode")
    mode = mode if mode in ("audio", "vonly", "vany") else "video"
    try:
        q = int(request.args.get("q") or 720)
    except ValueError:
        q = 720
    rng = request.headers.get("Range")
    for attempt in range(2):
        try:
            entry = get_info(url, refresh=attempt > 0)
        except Exception as ex:
            return jsonify(error=f"Could not read this link: {clean_err(ex)}"), 502
        pick = pick_stream(entry, mode, q)
        if not pick:
            if mode == "video":
                return preview()  # last resort: let yt-dlp choose a single file itself
            abort(400, "No stream of this kind for this video")
        try:
            r = open_upstream(pick["url"], pick["headers"], rng)
        except requests.RequestException:
            entry["streams"].pop((mode, q), None)
            if attempt == 0:
                continue
            return jsonify(error="The video server did not answer"), 502
        if r.status_code in (403, 404, 410) and attempt == 0:
            # the link expired or was refused: read the page again and retry ONCE, so the
            # player gets a working stream instead of an error screen
            r.close()
            info_cache.pop(url, None)
            continue
        return relay(r)
    return jsonify(error="The video server refused the stream"), 502


# ---------------------------------------------------------------- downloading

def _merge(video, audio, out):
    from java import jclass  # only exists inside the Android app
    jclass("com.mydl.app.Muxer").merge(video, audio, out)


def _extract_audio(video, out):
    from java import jclass
    jclass("com.mydl.app.Muxer").extractAudio(video, out)


def _find(prefix):
    files = [f for f in glob.glob(glob.escape(prefix) + ".*")
             if not f.endswith((".part", ".ytdl", ".json", ".temp"))]
    return files[0] if files else None


def _rm(*paths):
    for p in paths:
        try:
            if p and os.path.exists(p):
                os.remove(p)
        except OSError:
            pass


def _rm_prefix(prefix):
    for p in glob.glob(glob.escape(prefix) + ".*"):
        if not p.endswith(".json"):
            _rm(p)


def _speed(n):
    if not n:
        return ""
    return f"{n / 1e6:.1f} MB/s" if n >= 1e6 else f"{max(1, int(n / 1e3))} KB/s"


def run_job(jid, url, key):
    job = jobs[jid]
    base = os.path.join(LIB_DIR, jid)

    def make_hook(lo, hi, est):
        def hook(d):
            if job.get("cancel"):
                raise Cancelled()
            if d.get("status") == "downloading":
                total = d.get("total_bytes") or d.get("total_bytes_estimate") or est or 0
                done = d.get("downloaded_bytes") or 0
                if total and done:
                    frac = min(0.99, done / total)
                    job["progress"] = round((lo + (hi - lo) * frac) * 100, 1)
                job["speed"] = _speed(d.get("speed"))
        return hook

    def fetch(entry, src, fmt, prefix, hook, alt=None):
        """Download one format. 1) from the already-read info, 2) by reading the link again with
        the same client, 3) with the other clients. A 403 means the link was refused: the cached
        info is thrown away so every next try uses a fresh link."""
        plan = [("info", src), ("url", src)]
        if is_youtube(url):
            plan += [("url", s) for s in (*YT_SOURCES, *YT_FALLBACK) if s != src]
        errors = []
        for attempt, s in plan:
            _rm_prefix(prefix)
            want = fmt if attempt == "info" else (f"{fmt}/{alt}" if alt else fmt)
            o = base_opts(s if s in CLIENT_ARGS else "default", format=want, outtmpl=prefix + ".%(ext)s",
                          progress_hooks=[hook], http_chunk_size=10 * 1024 * 1024, overwrites=True,
                          concurrent_fragment_downloads=4)
            try:
                with yt_dlp.YoutubeDL(o) as ydl:
                    if attempt == "info":
                        if not entry["infos"].get(s):
                            continue
                        ydl.process_ie_result(copy.deepcopy(entry["infos"][s]), download=True)
                    else:
                        ydl.download([url])
                path = _find(prefix)
                if path and os.path.getsize(path) > 0:
                    return path
                errors.append("Downloaded file not found")
            except Exception as e:
                if job.get("cancel") or isinstance(e, Cancelled):
                    raise Cancelled()
                msg = str(e)
                if "403" in msg or "410" in msg:
                    info_cache.pop(url, None)
                errors.append(clean_err(e))
        raise RuntimeError(errors[-1] if errors else "Download failed")

    def alt_video(h, codec, ext):
        c = "'^(vp9|vp09)'" if codec == "vp9" else "'^(avc1|h264)'"
        return f"bv*[vcodec~={c}][ext={ext}][height<={h}]/bv*[vcodec~={c}][ext={ext}][width<={h}]"

    temps = []
    try:
        entry = get_info(url)
        i, opts = entry["small"], entry["opts"]
        opt = next((o for o in opts if o["key"] == key), None) or next((o for o in opts if o["kind"] == "video"), opts[0])
        src = opt.get("src", "default")
        qlabel = opt["label"] if opt["kind"] == "video" else f'{opt["label"]} {opt.get("ext", "")}'.strip()
        job.update(title=i.get("title"), thumb=i.get("thumbnail"), quality=qlabel)
        total = opt.get("size") or 0

        if opt["mode"] == "merge":
            # video is ~90% of the bytes, sound the rest; the last % is for joining them
            webm = opt.get("ext") == "webm"
            vpath = fetch(entry, src, opt["vid"], base + "_v", make_hook(0, 0.9, int(total * 0.9) if total else 0),
                          alt_video(opt.get("res") or 9999, "vp9" if webm else "avc1", "webm" if webm else "mp4"))
            temps.append(vpath)
            apath = fetch(entry, src, opt["aid"], base + "_a", make_hook(0.9, 0.97, int(total * 0.1) if total else 0),
                          "ba[acodec=opus]" if webm else "ba[acodec^=mp4a]")
            temps.append(apath)
            job["status"] = "processing"
            job["progress"] = 98
            out = base + "." + (opt.get("ext") or "mp4")
            try:
                _merge(vpath, apath, out)
            except Exception as e:
                _rm(out)
                raise RuntimeError("Could not join video and sound: " + clean_err(e))
            if not os.path.exists(out) or os.path.getsize(out) == 0:
                raise RuntimeError("Could not join video and sound")
        elif opt["mode"] == "extract":
            vpath = fetch(entry, src, opt["fmt"], base + "_v", make_hook(0, 0.95, 0), "b[acodec^=mp4a]")
            temps.append(vpath)
            job["status"] = "processing"
            job["progress"] = 97
            out = base + ".m4a"
            try:
                _extract_audio(vpath, out)
            except Exception as e:
                _rm(out)
                raise RuntimeError("Could not extract the sound: " + clean_err(e))
        else:
            if opt["kind"] == "audio":
                alt = "ba[acodec^=mp4a]" if opt.get("ext") == "M4A" else "ba[acodec=opus]" if opt.get("ext") == "OPUS" else "ba"
            else:
                alt = f"b[height<={opt.get('res') or 9999}]/b"
            out = fetch(entry, src, opt["fmt"], base, make_hook(0, 1, total), alt)
        _rm(*temps)

        ext = os.path.splitext(out)[1].lstrip(".")
        meta = {
            "id": jid, "title": safe_name(i.get("title")), "uploader": i.get("uploader"),
            "thumb": i.get("thumbnail"), "duration": i.get("duration"),
            "quality": qlabel, "kind": opt["kind"], "ext": ext,
            "file": os.path.basename(out), "size": os.path.getsize(out),
            "created": time.time(), "source": url,
        }
        with open(base + ".json", "w", encoding="utf-8") as fh:
            json.dump(meta, fh)
        job["item"] = meta
        job["progress"] = 100
        job["status"] = "done"
    except Exception as e:
        _rm(*temps)
        for p in glob.glob(glob.escape(base) + "*"):
            if not p.endswith(".json"):
                _rm(p)
        if job.get("cancel") or isinstance(e, Cancelled):
            job["status"] = "cancelled"
        else:
            job["status"] = "error"
            job["err"] = clean_err(e) or "Download failed"


@app.post("/api/download")
def download():
    body = request.get_json(silent=True) or {}
    url = check_url(str(body.get("url", "")).strip())
    key = str(body.get("key", ""))
    jid = uuid.uuid4().hex[:12]
    jobs[jid] = {"status": "downloading", "progress": 0, "created": time.time()}
    threading.Thread(target=run_job, args=(jid, url, key), daemon=True).start()
    return jsonify(id=jid)


@app.get("/api/progress/<jid>")
def progress(jid):
    j = jobs.get(jid)
    if not j:
        abort(400, "Unknown job")
    # NB: the failure text is sent as "err", not "error": the web UI treats an "error" field as a failed request.
    return jsonify({k: j.get(k) for k in ("status", "progress", "speed", "err", "title", "thumb", "quality", "item")})


@app.post("/api/cancel/<jid>")
def cancel(jid):
    j = jobs.get(jid)
    if j:
        j["cancel"] = True
    return jsonify(ok=True)


# ---------------------------------------------------------------- library

def _meta(item_id):
    if not ID_RE.match(item_id):
        abort(400, "Bad id")
    p = os.path.join(LIB_DIR, item_id + ".json")
    if not os.path.exists(p):
        abort(404)
    with open(p, encoding="utf-8") as fh:
        m = json.load(fh)
    path = os.path.join(LIB_DIR, m["file"])
    if not os.path.exists(path):
        abort(404)
    return m, path


@app.get("/api/library")
def library():
    items, total = [], 0
    for p in glob.glob(os.path.join(LIB_DIR, "*.json")):
        try:
            with open(p, encoding="utf-8") as fh:
                m = json.load(fh)
            if os.path.exists(os.path.join(LIB_DIR, m["file"])):
                items.append(m)
                total += m.get("size") or 0
        except Exception:
            continue
    items.sort(key=lambda m: m.get("created", 0), reverse=True)
    return jsonify(items=items, total=total)


@app.get("/api/media/<item_id>")
def media(item_id):
    m, path = _meta(item_id)
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    audio = m.get("kind") == "audio"
    # explicit types: Python's guess is missing/wrong for some (e.g. .m4a, .opus, audio .webm),
    # and a wrong type makes the player refuse the file
    mime = {"mp4": "audio/mp4" if audio else "video/mp4", "m4a": "audio/mp4", "webm": "audio/webm" if audio else "video/webm",
            "opus": "audio/ogg", "ogg": "audio/ogg", "mp3": "audio/mpeg", "mkv": "video/x-matroska",
            "mov": "video/quicktime", "3gp": "video/3gpp"}.get(ext) or mimetypes.guess_type(path)[0] or \
        ("audio/mp4" if audio else "video/mp4")
    return send_file(path, mimetype=mime, conditional=True)


@app.get("/api/file/<item_id>")
def get_file(item_id):
    m, path = _meta(item_id)
    return send_file(path, as_attachment=True, download_name=f"{m['title']}.{m['ext']}")


@app.delete("/api/library/<item_id>")
def delete_item(item_id):
    m, path = _meta(item_id)
    _rm(path, os.path.join(LIB_DIR, item_id + ".json"))
    return jsonify(ok=True)


@app.delete("/api/library")
def delete_all():
    for p in glob.glob(os.path.join(LIB_DIR, "*")):
        if os.path.isfile(p):
            _rm(p)
    return jsonify(ok=True)


# ---------------------------------------------------------------- FFmpeg compatibility conversion
# For videos the phone cannot decode (AV1 / HEVC / odd codecs): FFmpeg (the FFmpegKit library inside
# the app, see Transcoder.kt) converts them to VP9/WebM, which every Android WebView can play.
# The free FFmpegKit build has no HTTPS and no H.264 encoder, so online videos are read through this
# app's own local http://127.0.0.1 stream relay and the output is VP9 + Opus.
compat_jobs = {}
COMPAT_H = 480  # output height: keeps software VP9 encoding reasonably fast on phones


def _compat_dir():
    d = os.path.join(os.path.dirname(LIB_DIR.rstrip("/")), "compat")
    os.makedirs(d, exist_ok=True)
    return d


def _compat_cleanup():
    cutoff = time.time() - 86400
    try:
        for f in glob.glob(os.path.join(_compat_dir(), "*")):
            if os.path.getmtime(f) < cutoff:
                os.remove(f)
    except OSError:
        pass


def _compat_run(job):
    try:
        from java import jarray, jclass
        tc = jclass("com.mydl.app.Transcoder")
        if not tc.available():
            raise RuntimeError("The FFmpeg engine is not included in this build")
        out, prog = job["out"], job["out"] + ".progress"
        args = ["-y", "-hide_banner", "-nostats", "-progress", prog]
        for src in job["inputs"]:
            args += ["-i", src]
        if len(job["inputs"]) > 1:
            args += ["-map", "0:v:0", "-map", "1:a:0"]
        else:
            args += ["-map", "0:v:0", "-map", "0:a:0?"]
        args += ["-vf", f"scale=-2:min({COMPAT_H}\\,ih)", "-c:v", "libvpx-vp9", "-b:v", "0", "-crf", "36",
                 "-deadline", "realtime", "-cpu-used", "8", "-row-mt", "1", "-threads", "4",
                 "-c:a", "libopus", "-b:a", "96k", "-ac", "2", "-f", "webm", out]
        rc = tc.run(jarray(jclass("java.lang.String"))(args))
        if job.get("cancelled"):
            job["status"] = "cancelled"
        elif rc == 0 and os.path.exists(out) and os.path.getsize(out) > 1024:
            job["status"], job["pct"] = "done", 100
        else:
            raise RuntimeError("FFmpeg could not convert this video" + (" (engine missing)" if rc == -2 else ""))
    except Exception as ex:
        job["status"], job["error"] = "error", str(ex)[:200]
        try:
            os.remove(job["out"])
        except OSError:
            pass


@app.get("/api/compat/start")
def compat_start():
    """?kind=local&id=<library id>  or  ?kind=online&url=<page link>&q=<height>"""
    _compat_cleanup()
    kind = request.args.get("kind")
    jid = uuid.uuid4().hex[:12]
    base = "http://127.0.0.1:5000/api/stream?url="
    if kind == "local":
        m, path = _meta(request.args.get("id", ""))
        inputs, duration = [path], m.get("duration") or 0
    else:
        url = check_url(request.args.get("url", "").strip())
        try:
            q = int(request.args.get("q") or COMPAT_H)
        except ValueError:
            q = COMPAT_H
        q = min(q, COMPAT_H)
        try:
            entry = get_info(url)
        except Exception as ex:
            return jsonify(error=f"Could not read this link: {clean_err(ex)}"), 502
        from urllib.parse import quote
        enc = quote(url, safe="")
        duration = entry["small"].get("duration") or 0
        if pick_stream(entry, "vany", q):
            inputs = [f"{base}{enc}&mode=vany&q={q}", f"{base}{enc}&mode=audio"]
        else:
            inputs = [f"{base}{enc}&mode=video&q={q}"]
    job = {"id": jid, "status": "running", "pct": 0, "inputs": inputs, "duration": duration,
           "out": os.path.join(_compat_dir(), jid + ".webm"), "created": time.time()}
    compat_jobs[jid] = job
    threading.Thread(target=_compat_run, args=(job,), daemon=True).start()
    return jsonify(job=jid)


def _compat_progress(job):
    try:
        with open(job["out"] + ".progress", encoding="utf-8") as fh:
            vals = [ln.split("=", 1)[1].strip() for ln in fh if ln.startswith("out_time_us=") or ln.startswith("out_time_ms=")]
        if vals and job["duration"]:
            job["pct"] = max(job["pct"], min(99, int(float(vals[-1]) / 1e6 / job["duration"] * 100)))
    except (OSError, ValueError, IndexError):
        pass


@app.get("/api/compat/status")
def compat_status():
    job = compat_jobs.get(request.args.get("job", ""))
    if not job:
        abort(404)
    if job["status"] == "running":
        _compat_progress(job)
    return jsonify(status=job["status"], pct=job["pct"], error=job.get("error"))


@app.get("/api/compat/file/<jid>")
def compat_file(jid):
    job = compat_jobs.get(jid)
    if not job or job["status"] != "done":
        abort(404)
    return send_file(job["out"], mimetype="video/webm", conditional=True)


@app.get("/api/compat/cancel")
def compat_cancel():
    job = compat_jobs.get(request.args.get("job", ""))
    if job and job["status"] == "running":
        job["cancelled"] = True
        try:
            from java import jclass
            jclass("com.mydl.app.Transcoder").cancel()
        except Exception:
            pass
    return jsonify(ok=True)


def cleanup_loop():
    while True:
        time.sleep(600)
        cutoff = time.time() - 3600
        for jid, j in list(jobs.items()):
            if j["created"] < cutoff and j.get("status") in ("done", "error", "cancelled"):
                jobs.pop(jid, None)


def start(html, lib_dir, cache_dir=None):
    """Called from Kotlin. Blocks while the server runs."""
    global INDEX_HTML, LIB_DIR, CACHE_DIR
    INDEX_HTML = html
    LIB_DIR = lib_dir
    os.makedirs(LIB_DIR, exist_ok=True)
    if cache_dir:
        CACHE_DIR = os.path.join(cache_dir, "yt-dlp")
        os.makedirs(CACHE_DIR, exist_ok=True)
    threading.Thread(target=cleanup_loop, daemon=True).start()
    app.run(host="127.0.0.1", port=5000, threaded=True, use_reloader=False)
