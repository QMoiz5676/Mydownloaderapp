"""MyDownloader embedded backend (Flask + yt-dlp), runs inside the Android app via Chaquopy."""
import glob
import json
import mimetypes
import os
import re
import threading
import time
import uuid
from urllib.parse import urlparse

import requests
import yt_dlp
from flask import Flask, Response, abort, jsonify, request, send_file

app = Flask(__name__)

ALLOWED_DOMAINS = (
    "youtube.com", "youtu.be", "facebook.com", "fb.watch", "fb.com",
    "instagram.com", "snapchat.com",
)
FEEDS = {
    "trending": "trending videos today",
    "music": "new music videos",
    "movies": "movie trailers",
    "gaming": "gaming highlights",
    "funny": "funny videos",
    "news": "latest news",
    "diy": "diy craft projects",
}
ID_RE = re.compile(r"^[a-f0-9]{12}$")

INDEX_HTML = "<h1>Loading...</h1>"
LIB_DIR = "/tmp"
jobs = {}
info_cache = {}
preview_cache = {}
feed_cache = {}


class Cancelled(Exception):
    pass


def base_opts(**extra):
    o = {
        "quiet": True, "noplaylist": True, "cachedir": False, "no_warnings": True,
        # Clients that do not need a JavaScript runtime, which Android does not have.
        "extractor_args": {"youtube": {"player_client": ["android_vr", "tv"]}},
    }
    o.update(extra)
    return o


def check_url(url):
    try:
        p = urlparse(url)
    except Exception:
        abort(400, "Invalid URL")
    host = (p.hostname or "").lower()
    if p.scheme not in ("http", "https") or not any(
        host == d or host.endswith("." + d) for d in ALLOWED_DOMAINS
    ):
        abort(400, "Unsupported link. Use YouTube, Facebook, Instagram or Snapchat.")
    return url


def youtube_id(url):
    m = re.search(r"(?:v=|youtu\.be/|shorts/|embed/)([A-Za-z0-9_-]{11})", url)
    return m.group(1) if m else None


def safe_name(s):
    return re.sub(r'[\\/:*?"<>|\n\r]+', " ", s or "").strip()[:90] or "video"


@app.errorhandler(400)
def bad_request(e):
    return jsonify(error=getattr(e, "description", "Bad request")), 400


@app.errorhandler(404)
def not_found(e):
    return jsonify(error="Not found"), 404


@app.get("/")
def index():
    return Response(INDEX_HTML, mimetype="text/html")


# ---------------------------------------------------------------- search / feed

def yt_search(q, n=15):
    with yt_dlp.YoutubeDL(base_opts(extract_flat=True, skip_download=True)) as ydl:
        data = ydl.extract_info(f"ytsearch{n}:{q}", download=False)
    out = []
    for e in data.get("entries", []):
        if not e or not e.get("id"):
            continue
        out.append({
            "id": e["id"],
            "title": e.get("title"),
            "channel": e.get("channel") or e.get("uploader"),
            "duration": e.get("duration"),
            "views": e.get("view_count"),
            "thumb": f"https://i.ytimg.com/vi/{e['id']}/mqdefault.jpg",
            "url": f"https://www.youtube.com/watch?v={e['id']}",
        })
    return out


@app.get("/api/search")
def search():
    q = request.args.get("q", "").strip()
    if not q:
        abort(400, "Empty search")
    try:
        return jsonify(results=yt_search(q))
    except Exception as e:
        return jsonify(error=f"Search failed: {e}"), 502


@app.get("/api/feed")
def feed():
    cat = request.args.get("cat", "trending")
    if cat not in FEEDS:
        abort(400, "Unknown category")
    hit = feed_cache.get(cat)
    if hit and hit[0] > time.time():
        return jsonify(results=hit[1])
    try:
        res = yt_search(FEEDS[cat], 20)
    except Exception as e:
        return jsonify(error=f"Could not load videos: {e}"), 502
    feed_cache[cat] = (time.time() + 600, res)
    return jsonify(results=res)


# ---------------------------------------------------------------- info / quality options

def _size(f, dur):
    s = f.get("filesize") or f.get("filesize_approx")
    if not s and f.get("tbr") and dur:
        s = int(f["tbr"] * 125 * dur)
    return s


def _has_v(f):
    return f.get("vcodec") not in (None, "none")


def _has_a(f):
    return f.get("acodec") not in (None, "none")


def _tag(h):
    if h >= 2160:
        return "4K"
    if h >= 1440:
        return "2K"
    if h >= 1080:
        return "Full HD"
    if h >= 720:
        return "HD"
    return ""


def make_options(i):
    """Build the list of choices shown to the user.

    direct = one file that already has video and sound.
    merge  = separate H.264 video and AAC audio, joined on the phone after download.
    """
    fmts = [f for f in (i.get("formats") or [])
            if "m3u8" not in str(f.get("protocol", "")) and f.get("format_id")]
    dur = i.get("duration") or 0

    prog = [f for f in fmts if _has_v(f) and _has_a(f) and f.get("height")]
    vonly = [f for f in fmts if _has_v(f) and not _has_a(f) and f.get("height")
             and f.get("ext") == "mp4" and str(f.get("vcodec", "")).startswith(("avc1", "h264"))]
    aonly = [f for f in fmts if _has_a(f) and not _has_v(f)]
    aac = [f for f in aonly if f.get("ext") in ("m4a", "mp4") and str(f.get("acodec", "")).startswith("mp4a")]

    def rate(f):
        return f.get("tbr") or f.get("abr") or 0

    best_aac = max(aac, key=rate) if aac else None
    best_any_a = max(aonly, key=rate) if aonly else None

    by_h = {}
    for f in prog:
        if f.get("ext") != "mp4":
            continue
        cur = by_h.get(f["height"])
        if not cur or rate(f) > cur["_r"]:
            by_h[f["height"]] = {"mode": "direct", "fmt": f["format_id"], "size": _size(f, dur), "_r": rate(f)}
    if best_aac:
        best_v = {}
        for f in vonly:
            if f["height"] not in best_v or rate(f) > rate(best_v[f["height"]]):
                best_v[f["height"]] = f
        for h, f in best_v.items():
            if h in by_h:
                continue
            vs, asz = _size(f, dur), _size(best_aac, dur)
            by_h[h] = {"mode": "merge", "vid": f["format_id"], "aid": best_aac["format_id"],
                       "size": (vs + asz) if vs and asz else vs, "_r": rate(f)}
    # webm-only progressive (rare) as last resort for heights still missing
    for f in prog:
        if f["height"] not in by_h:
            by_h[f["height"]] = {"mode": "direct", "fmt": f["format_id"], "size": _size(f, dur), "_r": rate(f)}

    opts = []
    for h in sorted(by_h, reverse=True):
        o = by_h[h]
        o.pop("_r", None)
        o.update(key=str(h), label=f"{h}p", tag=_tag(h), kind="video")
        opts.append(o)

    a = best_aac or best_any_a
    if a:
        opts.append({"key": "audio", "label": "Audio only", "tag": "M4A" if a is best_aac else "",
                     "kind": "audio", "mode": "direct", "fmt": a["format_id"], "size": _size(a, dur)})
    if not opts:
        opts.append({"key": "best", "label": "Best quality", "tag": "", "kind": "video",
                     "mode": "direct", "fmt": "best", "size": None})
    return opts


def get_info(url):
    hit = info_cache.get(url)
    if hit and hit[0] > time.time():
        return hit[1], hit[2]
    with yt_dlp.YoutubeDL(base_opts(skip_download=True)) as ydl:
        i = ydl.extract_info(url, download=False)
    small = {k: i.get(k) for k in ("title", "uploader", "duration", "thumbnail")}
    opts = make_options(i)
    info_cache[url] = (time.time() + 900, small, opts)
    return small, opts


@app.get("/api/info")
def info():
    url = check_url(request.args.get("url", "").strip())
    try:
        i, opts = get_info(url)
    except Exception as e:
        return jsonify(error=f"Could not read this link: {e}"), 502
    return jsonify(
        url=url, title=i.get("title"), uploader=i.get("uploader"),
        duration=i.get("duration"), thumb=i.get("thumbnail"),
        youtube_id=youtube_id(url),
        options=[{k: o.get(k) for k in ("key", "label", "tag", "size", "kind", "mode")} for o in opts],
    )


@app.get("/api/preview")
def preview():
    url = check_url(request.args.get("url", "").strip())
    now = time.time()
    cached = preview_cache.get(url)
    if not cached or cached[0] < now:
        opts = base_opts(format="best[protocol^=http][ext=mp4]/best[protocol^=http]")
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                i = ydl.extract_info(url, download=False)
        except Exception:
            abort(400, "Preview unavailable")
        if not i.get("url"):
            abort(400, "Preview unavailable")
        cached = (now + 300, i["url"], i.get("http_headers", {}))
        preview_cache[url] = cached
    _, direct, headers = cached
    h = dict(headers)
    if request.headers.get("Range"):
        h["Range"] = request.headers["Range"]
    r = requests.get(direct, headers=h, stream=True, timeout=20)
    resp = Response(r.iter_content(65536), status=r.status_code)
    for k in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges"):
        if k in r.headers:
            resp.headers[k] = r.headers[k]
    return resp


# ---------------------------------------------------------------- downloading

def _merge(video, audio, out):
    from java import jclass  # only exists inside the Android app
    jclass("com.mydl.app.Muxer").merge(video, audio, out)


def _find(prefix):
    files = [f for f in glob.glob(glob.escape(prefix) + ".*")
             if not f.endswith((".part", ".ytdl", ".json", ".temp"))]
    return files[0] if files else None


def _rm(*paths):
    for p in paths:
        try:
            if p and os.path.exists(p):
                os.remove(p)
        except OSError:
            pass


def run_job(jid, url, key):
    job = jobs[jid]
    base = os.path.join(LIB_DIR, jid)

    def make_hook(lo, hi):
        def hook(d):
            if job.get("cancel"):
                raise Cancelled()
            if d["status"] == "downloading":
                total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
                if total:
                    frac = min(1.0, d["downloaded_bytes"] / total)
                    job["progress"] = round((lo + (hi - lo) * frac) * 100, 1)
                job["speed"] = (d.get("_speed_str") or "").strip()
        return hook

    def fetch(fmt, prefix, hook):
        o = base_opts(format=fmt, outtmpl=prefix + ".%(ext)s", progress_hooks=[hook])
        with yt_dlp.YoutubeDL(o) as ydl:
            ydl.download([url])
        path = _find(prefix)
        if not path:
            raise RuntimeError("Downloaded file not found")
        return path

    temps = []
    try:
        i, opts = get_info(url)
        opt = next((o for o in opts if o["key"] == key), opts[0])
        job.update(title=i.get("title"), thumb=i.get("thumbnail"), quality=opt["label"])
        if opt["mode"] == "merge":
            vpath = fetch(opt["vid"], base + "_v", make_hook(0, 0.85))
            temps.append(vpath)
            apath = fetch(opt["aid"], base + "_a", make_hook(0.85, 0.97))
            temps.append(apath)
            job["status"] = "processing"
            job["progress"] = 98
            out = base + ".mp4"
            _merge(vpath, apath, out)
        else:
            out = fetch(opt["fmt"], base, make_hook(0, 1))
        _rm(*temps)

        ext = os.path.splitext(out)[1].lstrip(".")
        meta = {
            "id": jid, "title": safe_name(i.get("title")), "uploader": i.get("uploader"),
            "thumb": i.get("thumbnail"), "duration": i.get("duration"),
            "quality": opt["label"], "kind": opt["kind"], "ext": ext,
            "file": os.path.basename(out), "size": os.path.getsize(out),
            "created": time.time(), "source": url,
        }
        with open(base + ".json", "w", encoding="utf-8") as fh:
            json.dump(meta, fh)
        job["item"] = meta
        job["progress"] = 100
        job["status"] = "done"
    except Exception as e:
        _rm(*temps)
        for p in glob.glob(glob.escape(base) + "*"):
            if not p.endswith(".json"):
                _rm(p)
        if job.get("cancel") or isinstance(e, Cancelled):
            job["status"] = "cancelled"
        else:
            job["status"] = "error"
            job["error"] = str(e)[:300]


@app.post("/api/download")
def download():
    body = request.get_json(silent=True) or {}
    url = check_url(str(body.get("url", "")).strip())
    key = str(body.get("key", ""))
    jid = uuid.uuid4().hex[:12]
    jobs[jid] = {"status": "downloading", "progress": 0, "created": time.time()}
    threading.Thread(target=run_job, args=(jid, url, key), daemon=True).start()
    return jsonify(id=jid)


@app.get("/api/progress/<jid>")
def progress(jid):
    j = jobs.get(jid)
    if not j:
        abort(400, "Unknown job")
    return jsonify({k: j.get(k) for k in ("status", "progress", "speed", "error", "title", "thumb", "quality", "item")})


@app.post("/api/cancel/<jid>")
def cancel(jid):
    j = jobs.get(jid)
    if j:
        j["cancel"] = True
    return jsonify(ok=True)


# ---------------------------------------------------------------- library

def _meta(item_id):
    if not ID_RE.match(item_id):
        abort(400, "Bad id")
    p = os.path.join(LIB_DIR, item_id + ".json")
    if not os.path.exists(p):
        abort(404)
    with open(p, encoding="utf-8") as fh:
        m = json.load(fh)
    path = os.path.join(LIB_DIR, m["file"])
    if not os.path.exists(path):
        abort(404)
    return m, path


@app.get("/api/library")
def library():
    items, total = [], 0
    for p in glob.glob(os.path.join(LIB_DIR, "*.json")):
        try:
            with open(p, encoding="utf-8") as fh:
                m = json.load(fh)
            if os.path.exists(os.path.join(LIB_DIR, m["file"])):
                items.append(m)
                total += m.get("size") or 0
        except Exception:
            continue
    items.sort(key=lambda m: m.get("created", 0), reverse=True)
    return jsonify(items=items, total=total)


@app.get("/api/media/<item_id>")
def media(item_id):
    m, path = _meta(item_id)
    mime = mimetypes.guess_type(path)[0] or ("audio/mp4" if m["kind"] == "audio" else "video/mp4")
    return send_file(path, mimetype=mime, conditional=True)


@app.get("/api/file/<item_id>")
def get_file(item_id):
    m, path = _meta(item_id)
    return send_file(path, as_attachment=True, download_name=f"{m['title']}.{m['ext']}")


@app.delete("/api/library/<item_id>")
def delete_item(item_id):
    m, path = _meta(item_id)
    _rm(path, os.path.join(LIB_DIR, item_id + ".json"))
    return jsonify(ok=True)


@app.delete("/api/library")
def delete_all():
    for p in glob.glob(os.path.join(LIB_DIR, "*")):
        if os.path.isfile(p):
            _rm(p)
    return jsonify(ok=True)


def cleanup_loop():
    while True:
        time.sleep(600)
        cutoff = time.time() - 3600
        for jid, j in list(jobs.items()):
            if j["created"] < cutoff and j.get("status") in ("done", "error", "cancelled"):
                jobs.pop(jid, None)


def start(html, lib_dir):
    """Called from Kotlin. Blocks while the server runs."""
    global INDEX_HTML, LIB_DIR
    INDEX_HTML = html
    LIB_DIR = lib_dir
    os.makedirs(LIB_DIR, exist_ok=True)
    threading.Thread(target=cleanup_loop, daemon=True).start()
    app.run(host="127.0.0.1", port=5000, threaded=True, use_reloader=False)
