"""MyDownloader embedded backend (Flask + yt-dlp), runs inside the Android app via Chaquopy."""
import glob
import os
import re
import threading
import time
import uuid
from urllib.parse import urlparse

import requests
import yt_dlp
from flask import Flask, Response, abort, jsonify, request, send_file

app = Flask(__name__)

ALLOWED_DOMAINS = (
    "youtube.com", "youtu.be", "facebook.com", "fb.watch", "fb.com",
    "instagram.com", "snapchat.com",
)
HAS_FFMPEG = False  # ffmpeg is not bundled in the APK

INDEX_HTML = "<h1>Loading…</h1>"
DOWNLOAD_DIR = "/tmp"
jobs = {}
preview_cache = {}


def base_opts(**extra):
    o = {"quiet": True, "noplaylist": True, "cachedir": False, "no_warnings": True}
    o.update(extra)
    return o


def check_url(url):
    try:
        p = urlparse(url)
    except Exception:
        abort(400, "Invalid URL")
    host = (p.hostname or "").lower()
    if p.scheme not in ("http", "https") or not any(
        host == d or host.endswith("." + d) for d in ALLOWED_DOMAINS
    ):
        abort(400, "Unsupported link. Use YouTube, Facebook, Instagram or Snapchat.")
    return url


def youtube_id(url):
    m = re.search(r"(?:v=|youtu\.be/|shorts/|embed/)([A-Za-z0-9_-]{11})", url)
    return m.group(1) if m else None


def safe_name(s):
    return re.sub(r'[\\/:*?"<>|\n\r]+', " ", s).strip()[:90] or "video"


@app.errorhandler(400)
def bad_request(e):
    return jsonify(error=getattr(e, "description", "Bad request")), 400


@app.get("/")
def index():
    return Response(INDEX_HTML, mimetype="text/html")


@app.get("/api/search")
def search():
    q = request.args.get("q", "").strip()
    if not q:
        abort(400, "Empty search")
    try:
        with yt_dlp.YoutubeDL(base_opts(extract_flat=True, skip_download=True)) as ydl:
            data = ydl.extract_info(f"ytsearch15:{q}", download=False)
    except Exception as e:
        return jsonify(error=f"Search failed: {e}"), 502
    out = []
    for e in data.get("entries", []):
        if not e or not e.get("id"):
            continue
        out.append({
            "id": e["id"],
            "title": e.get("title"),
            "channel": e.get("channel") or e.get("uploader"),
            "duration": e.get("duration"),
            "thumb": f"https://i.ytimg.com/vi/{e['id']}/mqdefault.jpg",
            "url": f"https://www.youtube.com/watch?v={e['id']}",
        })
    return jsonify(results=out)


@app.get("/api/info")
def info():
    url = check_url(request.args.get("url", "").strip())
    try:
        with yt_dlp.YoutubeDL(base_opts(skip_download=True)) as ydl:
            i = ydl.extract_info(url, download=False)
    except Exception as e:
        return jsonify(error=f"Could not read this link: {e}"), 502
    # Without ffmpeg only single-file (video+audio) formats can be saved.
    heights = sorted(
        {f["height"] for f in i.get("formats", [])
         if f.get("height") and f.get("vcodec") != "none" and f.get("acodec") not in (None, "none")},
        reverse=True,
    )
    return jsonify(
        url=url, title=i.get("title"), uploader=i.get("uploader"),
        duration=i.get("duration"), thumb=i.get("thumbnail"),
        youtube_id=youtube_id(url), heights=heights, ffmpeg=HAS_FFMPEG,
    )


@app.get("/api/preview")
def preview():
    url = check_url(request.args.get("url", "").strip())
    now = time.time()
    cached = preview_cache.get(url)
    if not cached or cached[0] < now:
        opts = base_opts(format="best[protocol^=http][ext=mp4]/best[protocol^=http]")
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                i = ydl.extract_info(url, download=False)
        except Exception:
            abort(400, "Preview unavailable")
        if not i.get("url"):
            abort(400, "Preview unavailable")
        cached = (now + 300, i["url"], i.get("http_headers", {}))
        preview_cache[url] = cached
    _, direct, headers = cached
    h = dict(headers)
    if request.headers.get("Range"):
        h["Range"] = request.headers["Range"]
    r = requests.get(direct, headers=h, stream=True, timeout=20)
    resp = Response(r.iter_content(65536), status=r.status_code)
    for k in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges"):
        if k in r.headers:
            resp.headers[k] = r.headers[k]
    return resp


def run_job(jid, url, quality):
    job = jobs[jid]

    def hook(d):
        if d["status"] == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            if total:
                job["progress"] = round(d["downloaded_bytes"] / total * 100, 1)
            job["speed"] = (d.get("_speed_str") or "").strip()
        elif d["status"] == "finished":
            job["progress"] = 100
            job["status"] = "processing"

    if quality == "audio":
        fmt = "bestaudio[ext=m4a]/bestaudio"
    else:
        h = int(quality) if quality.isdigit() else 720
        fmt = (f"best[height<={h}][acodec!=none][vcodec!=none][ext=mp4]/"
               f"best[height<={h}][acodec!=none][vcodec!=none]/best[acodec!=none][vcodec!=none]/best")
    opts = base_opts(
        format=fmt,
        outtmpl=os.path.join(DOWNLOAD_DIR, f"{jid}.%(ext)s"),
        progress_hooks=[hook],
    )
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            i = ydl.extract_info(url, download=True)
        files = [f for f in glob.glob(os.path.join(DOWNLOAD_DIR, f"{jid}.*"))
                 if not f.endswith((".part", ".ytdl"))]
        if not files:
            raise RuntimeError("File not found after download")
        job["path"] = files[0]
        ext = os.path.splitext(files[0])[1]
        job["name"] = safe_name(i.get("title", "video")) + ext
        job["status"] = "done"
    except Exception as e:
        job["status"] = "error"
        job["error"] = str(e)


@app.post("/api/download")
def download():
    body = request.get_json(silent=True) or {}
    url = check_url(str(body.get("url", "")).strip())
    quality = str(body.get("quality", "720"))
    jid = uuid.uuid4().hex[:12]
    jobs[jid] = {"status": "downloading", "progress": 0, "created": time.time()}
    threading.Thread(target=run_job, args=(jid, url, quality), daemon=True).start()
    return jsonify(id=jid)


@app.get("/api/progress/<jid>")
def progress(jid):
    j = jobs.get(jid)
    if not j:
        abort(400, "Unknown job")
    return jsonify({k: j.get(k) for k in ("status", "progress", "speed", "error", "name")})


@app.get("/api/file/<jid>")
def get_file(jid):
    j = jobs.get(jid)
    if not j or j.get("status") != "done":
        abort(400, "File not ready")
    return send_file(j["path"], as_attachment=True, download_name=j["name"])


def cleanup_loop():
    """The finished file is copied to the phone's Downloads folder, so remove the temp copy later."""
    while True:
        time.sleep(300)
        cutoff = time.time() - 1800
        for jid, j in list(jobs.items()):
            if j["created"] < cutoff:
                if j.get("path") and os.path.exists(j["path"]):
                    try:
                        os.remove(j["path"])
                    except OSError:
                        pass
                jobs.pop(jid, None)


def start(html, download_dir):
    """Called from Kotlin. Blocks while the server runs."""
    global INDEX_HTML, DOWNLOAD_DIR
    INDEX_HTML = html
    DOWNLOAD_DIR = download_dir
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    threading.Thread(target=cleanup_loop, daemon=True).start()
    app.run(host="127.0.0.1", port=5000, threaded=True, use_reloader=False)
