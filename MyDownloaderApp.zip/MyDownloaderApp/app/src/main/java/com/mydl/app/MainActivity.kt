package com.mydl.app

import android.annotation.SuppressLint
import android.content.ContentValues
import android.graphics.Color
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#E53935")) }
        web = WebView(this)
        root.addView(web, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                customView = view
                customCallback = callback
                web.visibility = View.GONE
                root.addView(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            }

            override fun onHideCustomView() {
                customView?.let { root.removeView(it) }
                customView = null
                customCallback?.onCustomViewHidden()
                web.visibility = View.VISIBLE
            }
        }
        web.setDownloadListener { url, _, disposition, mime, _ ->
            saveToDownloads(url, URLUtil.guessFileName(url, disposition, mime), mime)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) web.webChromeClient?.onHideCustomView() else moveTaskToBack(true)
            }
        })

        startServer()
    }

    private fun startServer() {
        Thread {
            try {
                if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                val html = assets.open("index.html").bufferedReader().readText()
                val dir = File(filesDir, "downloads").absolutePath
                val module = Python.getInstance().getModule("server")
                Thread { module.callAttr("start", html, dir) }.start()

                var ready = false
                for (i in 0 until 60) {
                    try {
                        Socket().use { it.connect(InetSocketAddress("127.0.0.1", 5000), 300) }
                        ready = true
                        break
                    } catch (_: Exception) {
                        Thread.sleep(500)
                    }
                }
                runOnUiThread {
                    if (ready) web.loadUrl("http://127.0.0.1:5000/")
                    else Toast.makeText(this, "Could not start the downloader engine", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Start error: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun saveToDownloads(url: String, name: String, mime: String?) {
        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime ?: "application/octet-stream")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MyDownloader")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Cannot create file")
                contentResolver.openOutputStream(uri)!!.use { out ->
                    conn.inputStream.use { it.copyTo(out) }
                }
                runOnUiThread {
                    Toast.makeText(this, "Saved to Downloads/MyDownloader", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }
}
