package com.mydl.app

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.nio.ByteBuffer

/** Joins a video-only MP4 and an audio-only M4A into one MP4. Called from Python. */
object Muxer {

    @JvmStatic
    fun merge(videoPath: String, audioPath: String, outPath: String) {
        val vEx = MediaExtractor()
        val aEx = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            vEx.setDataSource(videoPath)
            aEx.setDataSource(audioPath)
            val vTrack = findTrack(vEx, "video/")
            val aTrack = findTrack(aEx, "audio/")
            require(vTrack >= 0) { "No video track found" }
            require(aTrack >= 0) { "No audio track found" }

            muxer = MediaMuxer(outPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val vOut = muxer.addTrack(vEx.getTrackFormat(vTrack))
            val aOut = muxer.addTrack(aEx.getTrackFormat(aTrack))
            vEx.selectTrack(vTrack)
            aEx.selectTrack(aTrack)
            muxer.start()
            copySamples(vEx, muxer, vOut)
            copySamples(aEx, muxer, aOut)
            muxer.stop()
        } finally {
            try { muxer?.release() } catch (_: Exception) {}
            vEx.release()
            aEx.release()
        }
    }

    private fun findTrack(ex: MediaExtractor, prefix: String): Int {
        for (i in 0 until ex.trackCount) {
            val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith(prefix)) return i
        }
        return -1
    }

    private fun copySamples(ex: MediaExtractor, muxer: MediaMuxer, track: Int) {
        val buf = ByteBuffer.allocate(4 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        while (true) {
            buf.clear()
            val size = ex.readSampleData(buf, 0)
            if (size < 0) break
            val flags = if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0)
                MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
            info.set(0, size, ex.sampleTime, flags)
            muxer.writeSampleData(track, buf, info)
            ex.advance()
        }
    }
}
