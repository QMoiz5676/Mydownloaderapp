# MyDownloader (Android app)

A native Android app that bundles Python + yt-dlp inside the APK. It opens in its own window, no browser needed.
The UI is shown in an in-app WebView and the download engine runs inside the app.

## Build the APK, option A: GitHub (no Android Studio)
1. Create a free GitHub account and a new empty repository.
2. Upload ALL files and folders of this project to it (keep the structure, including the hidden `.github` folder).
3. Open the **Actions** tab, choose **Build APK**, tap **Run workflow**.
4. After about 5-10 minutes open the finished run and download the **MyDownloader-apk** artifact (a zip containing `app-debug.apk`).
5. Unzip it, open the APK on your phone and allow "Install unknown apps" when asked.

## Build the APK, option B: Android Studio (PC)
1. Install Android Studio and Python 3 (needed by the build).
2. File > Open this folder, wait for Gradle sync.
3. Build > Build APK(s). The APK is in `app/build/outputs/apk/debug/`.

## Using the app (v2)
- **Home:** search or paste a link, site shortcuts, recent downloads, trending videos.
- **Watch:** browse by category (Trending, Music, Movies, Gaming, Funny, News, DIY) and search YouTube.
- **Quality list:** every video shows its available qualities with the file size. Higher qualities (1080p and up) are downloaded as separate video and sound and joined on the phone.
- **Downloads:** your library, with a built-in player (double-tap to skip 10s, speed, loop, fill, rotate, resume where you stopped, next/previous).
- **Settings:** default quality, copy to the Downloads folder, player options, theme, storage.
- **Share to the app:** in YouTube or Facebook, tap Share and pick MyDownloader. A copied link is also detected when you open the app.
Downloaded files are kept inside the app, and a copy is placed in **Downloads/MyDownloader** if that option is on.

## Known limits
- Joining video and sound uses the phone's own media tools (H.264 video with AAC sound). Formats that don't fit that are not offered.
- YouTube changes often. If it stops working, rebuild the APK to pick up the newest yt-dlp.
- Private or login-only videos don't work.
- Keep the app open while a download runs.
- Only download content you own or have permission to save. Downloading can break a platform's terms of service.
