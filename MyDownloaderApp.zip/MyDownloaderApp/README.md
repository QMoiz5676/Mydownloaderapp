# MyDownloader (Android app)

A native Android app that bundles Python + yt-dlp inside the APK. It opens in its own window, no browser needed.
The UI is shown in an in-app WebView and the download engine runs inside the app.

## Build the APK, option A: GitHub (no Android Studio)
1. Create a free GitHub account and a new empty repository.
2. Upload ALL files and folders of this project to it (keep the structure, including the hidden `.github` folder).
3. Open the **Actions** tab, choose **Build APK**, tap **Run workflow**.
4. After about 5-10 minutes open the finished run and download the **MyDownloader-apk** artifact (a zip containing `app-debug.apk`).
5. Unzip it, open the APK on your phone and allow "Install unknown apps" when asked.

## Build the APK, option B: Android Studio (PC)
1. Install Android Studio and Python 3 (needed by the build).
2. File > Open this folder, wait for Gradle sync.
3. Build > Build APK(s). The APK is in `app/build/outputs/apk/debug/`.

## Using the app
Search YouTube or paste a Facebook / Instagram / Snapchat link, watch the preview, pick a quality and tap Download.
Files are saved to **Downloads/MyDownloader** on your phone.

## Known limits
- ffmpeg is not bundled, so only ready-made single-file formats can be saved (YouTube is often limited to 360p-720p).
- YouTube changes often. If it stops working, rebuild the APK to pick up the newest yt-dlp.
- Private or login-only videos don't work.
- Keep the app open while a download runs.
- Only download content you own or have permission to save. Downloading can break a platform's terms of service.
