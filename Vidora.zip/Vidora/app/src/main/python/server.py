"""Vidora embedded backend (Flask + yt-dlp), runs inside the Android app via Chaquopy."""
import copy
import glob
import json
import mimetypes
import os
import re
import threading
import time
import uuid
from urllib.parse import urlparse

import requests
import yt_dlp
from flask import Flask, Response, abort, jsonify, request, send_file

app = Flask(__name__)

ALLOWED_DOMAINS = (
    "youtube.com", "youtu.be", "facebook.com", "fb.watch", "fb.com",
    "instagram.com", "snapchat.com",
)
FEEDS = {
    "trending": "trending videos today",
    "music": "new music videos",
    "movies": "movie trailers",
    "gaming": "gaming highlights",
    "funny": "funny videos",
    "news": "latest news",
    "diy": "diy craft projects",
}
ID_RE = re.compile(r"^[a-f0-9]{12}$")

INDEX_HTML = "<h1>Loading...</h1>"
LIB_DIR = "/tmp"
jobs = {}
info_cache = {}
preview_cache = {}
feed_cache = {}


class Cancelled(Exception):
    pass


# YouTube player clients. None of these need a JavaScript runtime (Android has none).
# They are all tried in parallel and their formats are combined, because each one
# exposes a different set of qualities and YouTube changes which ones work.
CLIENT_ARGS = {
    "vr": {"youtube": {"player_client": ["android_vr"]}},
    "default": None,  # yt-dlp's own default clients
    "ios": {"youtube": {"player_client": ["ios"]}},
    "web": {"youtube": {"player_client": ["web_embedded", "mweb"]}},
}
YT_SOURCES = ("vr", "default", "ios", "web")


def base_opts(src=None, **extra):
    o = {
        "quiet": True, "noplaylist": True, "cachedir": False, "no_warnings": True,
        "no_color": True, "socket_timeout": 25, "retries": 8, "fragment_retries": 8,
        "extractor_retries": 2,
        # There is no ffmpeg on the phone: never try to post-process/fix containers.
        "fixup": "never", "postprocessors": [],
    }
    ea = CLIENT_ARGS.get(src)
    if ea:
        o["extractor_args"] = ea
    o.update(extra)
    return o


def clean_err(e):
    s = str(e) or e.__class__.__name__
    s = re.sub(r"\x1b\[[0-9;]*m", "", s)
    s = re.sub(r"^(ERROR:\s*)+", "", s.strip())
    s = re.sub(r"^\[[\w:]+\]\s+[\w-]{3,}:\s*", "", s)  # drop "[youtube] abc123:" prefix
    if "Sign in to confirm" in s or "not a bot" in s:
        s = "YouTube asked for a sign-in check for this video. Try again in a minute."
    return s.strip()[:300]


def is_youtube(url):
    host = (urlparse(url).hostname or "").lower()
    return host.endswith(("youtube.com", "youtu.be"))


def check_url(url):
    try:
        p = urlparse(url)
    except Exception:
        abort(400, "Invalid URL")
    host = (p.hostname or "").lower()
    if p.scheme not in ("http", "https") or not any(
        host == d or host.endswith("." + d) for d in ALLOWED_DOMAINS
    ):
        abort(400, "Unsupported link. Use YouTube, Facebook, Instagram or Snapchat.")
    return url


def youtube_id(url):
    m = re.search(r"(?:v=|youtu\.be/|shorts/|embed/)([A-Za-z0-9_-]{11})", url)
    return m.group(1) if m else None


def safe_name(s):
    return re.sub(r'[\\/:*?"<>|\n\r]+', " ", s or "").strip()[:90] or "video"


@app.errorhandler(400)
def bad_request(e):
    return jsonify(error=getattr(e, "description", "Bad request")), 400


@app.errorhandler(404)
def not_found(e):
    return jsonify(error="Not found"), 404


@app.get("/")
def index():
    return Response(INDEX_HTML, mimetype="text/html")


# ---------------------------------------------------------------- search / feed

def yt_search(q, n=15):
    with yt_dlp.YoutubeDL(base_opts(extract_flat=True, skip_download=True)) as ydl:
        data = ydl.extract_info(f"ytsearch{n}:{q}", download=False)
    out = []
    for e in data.get("entries", []):
        if not e or not e.get("id"):
            continue
        out.append({
            "id": e["id"],
            "title": e.get("title"),
            "channel": e.get("channel") or e.get("uploader"),
            "duration": e.get("duration"),
            "views": e.get("view_count"),
            "thumb": f"https://i.ytimg.com/vi/{e['id']}/mqdefault.jpg",
            "url": f"https://www.youtube.com/watch?v={e['id']}",
        })
    return out


@app.get("/api/search")
def search():
    q = request.args.get("q", "").strip()
    if not q:
        abort(400, "Empty search")
    try:
        return jsonify(results=yt_search(q))
    except Exception as e:
        return jsonify(error=f"Search failed: {e}"), 502


@app.get("/api/feed")
def feed():
    cat = request.args.get("cat", "trending")
    if cat not in FEEDS:
        abort(400, "Unknown category")
    hit = feed_cache.get(cat)
    if hit and hit[0] > time.time():
        return jsonify(results=hit[1])
    try:
        res = yt_search(FEEDS[cat], 20)
    except Exception as e:
        return jsonify(error=f"Could not load videos: {e}"), 502
    feed_cache[cat] = (time.time() + 600, res)
    return jsonify(results=res)


# ---------------------------------------------------------------- info / quality options

def _size(f, dur):
    s = f.get("filesize") or f.get("filesize_approx")
    if not s and (f.get("tbr") or f.get("abr")) and dur:
        s = int((f.get("tbr") or f.get("abr")) * 125 * dur)
    return s


def _has_v(f):
    return f.get("vcodec") not in (None, "none")


def _has_a(f):
    return f.get("acodec") not in (None, "none")


def _vc(f):
    return str(f.get("vcodec") or "").lower()


def _ac(f):
    return str(f.get("acodec") or "").lower()


def _res(f):
    """Quality label number. Portrait videos (shorts) are labelled by their short side."""
    h, w = f.get("height"), f.get("width")
    if h and w and h > w:
        return w
    return h


def _tag(h):
    if h >= 4320:
        return "8K"
    if h >= 2160:
        return "4K"
    if h >= 1440:
        return "2K"
    if h >= 1080:
        return "Full HD"
    if h >= 720:
        return "HD"
    return ""


def _rate(f):
    return f.get("tbr") or f.get("abr") or f.get("vbr") or 0


def make_options(i, src):
    """Build the choices shown to the user from one extraction result.

    direct  = one file that already has video and sound (any container).
    merge   = separate video + audio, joined on the phone after download:
              H.264 + AAC -> .mp4        VP9 + Opus -> .webm  (this is how 1440p / 4K ship)
    extract = take the sound track out of a normal video file (when no audio-only stream exists).
    """
    fmts = [f for f in (i.get("formats") or [])
            if "m3u8" not in str(f.get("protocol", "")) and f.get("format_id")]
    dur = i.get("duration") or 0

    aonly = [f for f in fmts if _has_a(f) and not _has_v(f) and "drc" not in str(f["format_id"]).lower()]
    aac = [f for f in aonly if _ac(f).startswith("mp4a")]
    opus = [f for f in aonly if _ac(f).startswith("opus")]

    def best(lst):
        return max(lst, key=lambda f: (f.get("language_preference") or 0, _rate(f))) if lst else None

    best_aac, best_opus = best(aac), best(opus)

    # ---- video: one entry per resolution, best way of getting it wins
    vids = {}

    def offer(res, score, opt, rate):
        cur = vids.get(res)
        if not cur or (score, rate) > (cur["_s"], cur["_r"]):
            opt.update(_s=score, _r=rate)
            vids[res] = opt

    for f in fmts:
        if not _has_v(f):
            continue
        res = _res(f)
        if not res:
            continue
        r = _rate(f)
        if _has_a(f):  # ready-made file with sound
            ext = f.get("ext") or "mp4"
            offer(res, 30 if ext == "mp4" else 10,
                  {"mode": "direct", "fmt": f["format_id"], "ext": ext, "size": _size(f, dur)}, r)
            continue
        vs = _size(f, dur)
        if _vc(f).startswith(("avc1", "h264")) and f.get("ext") == "mp4" and best_aac:
            asz = _size(best_aac, dur)
            offer(res, 20, {"mode": "merge", "vid": f["format_id"], "aid": best_aac["format_id"], "ext": "mp4",
                            "size": (vs + asz) if vs and asz else vs}, r)
        elif _vc(f).startswith(("vp9", "vp09", "vp8")) and best_opus:
            asz = _size(best_opus, dur)
            offer(res, 15, {"mode": "merge", "vid": f["format_id"], "aid": best_opus["format_id"], "ext": "webm",
                            "size": (vs + asz) if vs and asz else vs}, r)

    out = []
    for res, o in vids.items():
        o = {k: v for k, v in o.items()}
        o.update(key=str(res), label=f"{res}p", tag=_tag(res), kind="video", src=src, res=res)
        out.append(o)

    # ---- audio: every real audio stream (bitrate x format)
    seen = {}
    for f in aonly:
        a = _ac(f)
        name = "M4A" if a.startswith("mp4a") else "OPUS" if a.startswith("opus") else (f.get("ext") or "AUDIO").upper()
        abr = int(round(f.get("abr") or f.get("tbr") or 0))
        k = (name, abr)
        cur = seen.get(k)
        if not cur or (f.get("language_preference") or 0) > (cur.get("language_preference") or 0):
            seen[k] = f
    for (name, abr), f in seen.items():
        out.append({"key": "a" + str(f["format_id"]), "label": f"{abr}K" if abr else "Audio", "tag": "",
                    "kind": "audio", "mode": "direct", "fmt": f["format_id"], "ext": name,
                    "size": _size(f, dur), "src": src, "abr": abr})

    if not aonly:
        # no audio-only stream (Instagram, Snapchat...): pull the sound out of the smallest AAC video
        cands = [f for f in fmts if _has_v(f) and _has_a(f) and _ac(f).startswith("mp4a")]
        if cands:
            f = min(cands, key=lambda x: (_res(x) or 9999, _rate(x)))
            abr = int(round(f.get("abr") or 128))
            out.append({"key": "aextract", "label": "Audio", "tag": "", "kind": "audio", "mode": "extract",
                        "fmt": f["format_id"], "ext": "M4A", "size": int(abr * 125 * dur) if dur else None,
                        "src": src, "abr": abr})
    return out


def combine_options(per_src):
    """Merge the option lists of several extractions: best way per resolution, all audio streams."""
    vids, auds = {}, {}
    for src, opts in per_src:
        for o in opts:
            if o["kind"] == "video":
                cur = vids.get(o["key"])
                if not cur or (o["_s"], o["_r"]) > (cur["_s"], cur["_r"]):
                    vids[o["key"]] = o
            else:
                k = (o["ext"], o.get("abr"))
                if k not in auds:
                    auds[k] = o
    v = sorted(vids.values(), key=lambda o: -o["res"])
    if any(o["mode"] != "extract" for o in auds.values()):
        auds = {k: o for k, o in auds.items() if o["mode"] != "extract"}  # real audio streams exist
    a = sorted(auds.values(), key=lambda o: (o["ext"] != "M4A", -(o.get("abr") or 0)))
    opts = v + a
    if not opts:
        opts.append({"key": "best", "label": "Best quality", "tag": "", "kind": "video", "mode": "direct",
                     "fmt": "best", "ext": "mp4", "size": None, "src": "default"})
    for o in opts:
        o.pop("_s", None)
        o.pop("_r", None)
    return opts


def _extract(url, src, results, errors, stamps):
    try:
        # format "b*" always resolves when ANY stream exists, so listing never fails on selection
        o = base_opts(src, skip_download=True, format="b*", ignore_no_formats_error=True)
        with yt_dlp.YoutubeDL(o) as ydl:
            results[src] = ydl.extract_info(url, download=False)
        stamps[src] = time.time()
    except Exception as e:
        errors[src] = clean_err(e)


INFO_TTL = 1800


def get_info(url):
    hit = info_cache.get(url)
    if hit and hit["exp"] > time.time():
        return hit
    srcs = YT_SOURCES if is_youtube(url) else ("default",)
    results, errors, stamps = {}, {}, {}
    threads = [threading.Thread(target=_extract, args=(url, s, results, errors, stamps), daemon=True)
               for s in srcs]
    for t in threads:
        t.start()
    t0 = time.time()
    while any(t.is_alive() for t in threads):
        now = time.time()
        # once one client has answered, give the others a few seconds, then go with what we have
        if stamps and now - min(stamps.values()) > 7:
            break
        if now - t0 > 60:
            break
        time.sleep(0.1)
    infos = {s: results[s] for s in srcs if s in results}
    if not infos:
        raise RuntimeError(next(iter(errors.values()), "No response from the site"))
    per_src, first = [], None
    for s, i in infos.items():
        try:
            per_src.append((s, make_options(i, s)))
            first = first or i
        except Exception as e:
            errors[s] = clean_err(e)
    opts = combine_options(per_src)
    first = first or next(iter(infos.values()))
    entry = {
        "exp": time.time() + INFO_TTL, "infos": infos, "opts": opts,
        "small": {k: first.get(k) for k in ("title", "uploader", "duration", "thumbnail")},
    }
    info_cache[url] = entry
    for u in sorted(info_cache, key=lambda x: info_cache[x]["exp"])[:-5]:  # keep the 5 newest
        info_cache.pop(u, None)
    return entry


@app.get("/api/info")
def info():
    url = check_url(request.args.get("url", "").strip())
    try:
        e = get_info(url)
    except Exception as ex:
        return jsonify(error=f"Could not read this link: {clean_err(ex)}"), 502
    i = e["small"]
    return jsonify(
        url=url, title=i.get("title"), uploader=i.get("uploader"),
        duration=i.get("duration"), thumb=i.get("thumbnail"),
        youtube_id=youtube_id(url),
        options=[{k: o.get(k) for k in ("key", "label", "tag", "size", "kind", "mode", "ext")} for o in e["opts"]],
    )


@app.get("/api/preview")
def preview():
    url = check_url(request.args.get("url", "").strip())
    now = time.time()
    cached = preview_cache.get(url)
    if not cached or cached[0] < now:
        opts = base_opts(format="best[protocol^=http][ext=mp4]/best[protocol^=http]")
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                i = ydl.extract_info(url, download=False)
        except Exception:
            abort(400, "Preview unavailable")
        if not i.get("url"):
            abort(400, "Preview unavailable")
        cached = (now + 300, i["url"], i.get("http_headers", {}))
        preview_cache[url] = cached
    _, direct, headers = cached
    h = dict(headers)
    if request.headers.get("Range"):
        h["Range"] = request.headers["Range"]
    r = requests.get(direct, headers=h, stream=True, timeout=20)
    resp = Response(r.iter_content(65536), status=r.status_code)
    for k in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges"):
        if k in r.headers:
            resp.headers[k] = r.headers[k]
    return resp


# ---------------------------------------------------------------- downloading

def _merge(video, audio, out):
    from java import jclass  # only exists inside the Android app
    jclass("com.mydl.app.Muxer").merge(video, audio, out)


def _extract_audio(video, out):
    from java import jclass
    jclass("com.mydl.app.Muxer").extractAudio(video, out)


def _find(prefix):
    files = [f for f in glob.glob(glob.escape(prefix) + ".*")
             if not f.endswith((".part", ".ytdl", ".json", ".temp"))]
    return files[0] if files else None


def _rm(*paths):
    for p in paths:
        try:
            if p and os.path.exists(p):
                os.remove(p)
        except OSError:
            pass


def _rm_prefix(prefix):
    for p in glob.glob(glob.escape(prefix) + ".*"):
        if not p.endswith(".json"):
            _rm(p)


def _speed(n):
    if not n:
        return ""
    return f"{n / 1e6:.1f} MB/s" if n >= 1e6 else f"{max(1, int(n / 1e3))} KB/s"


def run_job(jid, url, key):
    job = jobs[jid]
    base = os.path.join(LIB_DIR, jid)

    def make_hook(lo, hi, est):
        def hook(d):
            if job.get("cancel"):
                raise Cancelled()
            if d.get("status") == "downloading":
                total = d.get("total_bytes") or d.get("total_bytes_estimate") or est or 0
                done = d.get("downloaded_bytes") or 0
                if total and done:
                    frac = min(0.99, done / total)
                    job["progress"] = round((lo + (hi - lo) * frac) * 100, 1)
                job["speed"] = _speed(d.get("speed"))
        return hook

    def fetch(entry, src, fmt, prefix, hook):
        """Download one format. First from the already-read info, then by reading the link again."""
        url_src = src if src in CLIENT_ARGS else "default"
        o = base_opts(url_src, format=fmt, outtmpl=prefix + ".%(ext)s", progress_hooks=[hook],
                      http_chunk_size=10 * 1024 * 1024, overwrites=True)
        errors = []
        for attempt in ("info", "url"):
            _rm_prefix(prefix)
            try:
                with yt_dlp.YoutubeDL(o) as ydl:
                    if attempt == "info" and entry["infos"].get(src):
                        ydl.process_ie_result(copy.deepcopy(entry["infos"][src]), download=True)
                    else:
                        ydl.download([url])
                path = _find(prefix)
                if path and os.path.getsize(path) > 0:
                    return path
                errors.append("Downloaded file not found")
            except Exception as e:
                if job.get("cancel") or isinstance(e, Cancelled):
                    raise Cancelled()
                errors.append(clean_err(e))
        raise RuntimeError(errors[-1] if errors else "Download failed")

    temps = []
    try:
        entry = get_info(url)
        i, opts = entry["small"], entry["opts"]
        opt = next((o for o in opts if o["key"] == key), None) or next((o for o in opts if o["kind"] == "video"), opts[0])
        src = opt.get("src", "default")
        qlabel = opt["label"] if opt["kind"] == "video" else f'{opt["label"]} {opt.get("ext", "")}'.strip()
        job.update(title=i.get("title"), thumb=i.get("thumbnail"), quality=qlabel)
        total = opt.get("size") or 0

        if opt["mode"] == "merge":
            # video is ~90% of the bytes, sound the rest; the last % is for joining them
            vpath = fetch(entry, src, opt["vid"], base + "_v", make_hook(0, 0.9, int(total * 0.9) if total else 0))
            temps.append(vpath)
            apath = fetch(entry, src, opt["aid"], base + "_a", make_hook(0.9, 0.97, int(total * 0.1) if total else 0))
            temps.append(apath)
            job["status"] = "processing"
            job["progress"] = 98
            out = base + "." + (opt.get("ext") or "mp4")
            try:
                _merge(vpath, apath, out)
            except Exception as e:
                _rm(out)
                raise RuntimeError("Could not join video and sound: " + clean_err(e))
            if not os.path.exists(out) or os.path.getsize(out) == 0:
                raise RuntimeError("Could not join video and sound")
        elif opt["mode"] == "extract":
            vpath = fetch(entry, src, opt["fmt"], base + "_v", make_hook(0, 0.95, 0))
            temps.append(vpath)
            job["status"] = "processing"
            job["progress"] = 97
            out = base + ".m4a"
            try:
                _extract_audio(vpath, out)
            except Exception as e:
                _rm(out)
                raise RuntimeError("Could not extract the sound: " + clean_err(e))
        else:
            out = fetch(entry, src, opt["fmt"], base, make_hook(0, 1, total))
        _rm(*temps)

        ext = os.path.splitext(out)[1].lstrip(".")
        meta = {
            "id": jid, "title": safe_name(i.get("title")), "uploader": i.get("uploader"),
            "thumb": i.get("thumbnail"), "duration": i.get("duration"),
            "quality": qlabel, "kind": opt["kind"], "ext": ext,
            "file": os.path.basename(out), "size": os.path.getsize(out),
            "created": time.time(), "source": url,
        }
        with open(base + ".json", "w", encoding="utf-8") as fh:
            json.dump(meta, fh)
        job["item"] = meta
        job["progress"] = 100
        job["status"] = "done"
    except Exception as e:
        _rm(*temps)
        for p in glob.glob(glob.escape(base) + "*"):
            if not p.endswith(".json"):
                _rm(p)
        if job.get("cancel") or isinstance(e, Cancelled):
            job["status"] = "cancelled"
        else:
            job["status"] = "error"
            job["err"] = clean_err(e) or "Download failed"


@app.post("/api/download")
def download():
    body = request.get_json(silent=True) or {}
    url = check_url(str(body.get("url", "")).strip())
    key = str(body.get("key", ""))
    jid = uuid.uuid4().hex[:12]
    jobs[jid] = {"status": "downloading", "progress": 0, "created": time.time()}
    threading.Thread(target=run_job, args=(jid, url, key), daemon=True).start()
    return jsonify(id=jid)


@app.get("/api/progress/<jid>")
def progress(jid):
    j = jobs.get(jid)
    if not j:
        abort(400, "Unknown job")
    # NB: the failure text is sent as "err", not "error": the web UI treats an "error" field as a failed request.
    return jsonify({k: j.get(k) for k in ("status", "progress", "speed", "err", "title", "thumb", "quality", "item")})


@app.post("/api/cancel/<jid>")
def cancel(jid):
    j = jobs.get(jid)
    if j:
        j["cancel"] = True
    return jsonify(ok=True)


# ---------------------------------------------------------------- library

def _meta(item_id):
    if not ID_RE.match(item_id):
        abort(400, "Bad id")
    p = os.path.join(LIB_DIR, item_id + ".json")
    if not os.path.exists(p):
        abort(404)
    with open(p, encoding="utf-8") as fh:
        m = json.load(fh)
    path = os.path.join(LIB_DIR, m["file"])
    if not os.path.exists(path):
        abort(404)
    return m, path


@app.get("/api/library")
def library():
    items, total = [], 0
    for p in glob.glob(os.path.join(LIB_DIR, "*.json")):
        try:
            with open(p, encoding="utf-8") as fh:
                m = json.load(fh)
            if os.path.exists(os.path.join(LIB_DIR, m["file"])):
                items.append(m)
                total += m.get("size") or 0
        except Exception:
            continue
    items.sort(key=lambda m: m.get("created", 0), reverse=True)
    return jsonify(items=items, total=total)


@app.get("/api/media/<item_id>")
def media(item_id):
    m, path = _meta(item_id)
    mime = mimetypes.guess_type(path)[0] or ("audio/mp4" if m["kind"] == "audio" else "video/mp4")
    return send_file(path, mimetype=mime, conditional=True)


@app.get("/api/file/<item_id>")
def get_file(item_id):
    m, path = _meta(item_id)
    return send_file(path, as_attachment=True, download_name=f"{m['title']}.{m['ext']}")


@app.delete("/api/library/<item_id>")
def delete_item(item_id):
    m, path = _meta(item_id)
    _rm(path, os.path.join(LIB_DIR, item_id + ".json"))
    return jsonify(ok=True)


@app.delete("/api/library")
def delete_all():
    for p in glob.glob(os.path.join(LIB_DIR, "*")):
        if os.path.isfile(p):
            _rm(p)
    return jsonify(ok=True)


def cleanup_loop():
    while True:
        time.sleep(600)
        cutoff = time.time() - 3600
        for jid, j in list(jobs.items()):
            if j["created"] < cutoff and j.get("status") in ("done", "error", "cancelled"):
                jobs.pop(jid, None)


def start(html, lib_dir):
    """Called from Kotlin. Blocks while the server runs."""
    global INDEX_HTML, LIB_DIR
    INDEX_HTML = html
    LIB_DIR = lib_dir
    os.makedirs(LIB_DIR, exist_ok=True)
    threading.Thread(target=cleanup_loop, daemon=True).start()
    app.run(host="127.0.0.1", port=5000, threaded=True, use_reloader=False)
