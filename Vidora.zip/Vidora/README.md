# Vidora (Android app)

A native Android app that bundles Python + yt-dlp inside the APK. It opens in its own window, no browser needed.
The UI is shown in an in-app WebView and the download engine runs inside the app.

## Build the APK, option A: GitHub (no Android Studio)
1. Create a free GitHub account and a new empty repository.
2. Upload ALL files and folders of this project to it (keep the structure, including the hidden `.github` folder).
3. Open the **Actions** tab, choose **Build APK**, tap **Run workflow**.
4. After about 5-10 minutes open the finished run and download the **Vidora-apk** artifact (a zip containing `app-debug.apk`).
5. Unzip it, open the APK on your phone and allow "Install unknown apps" when asked.

## Build the APK, option B: Android Studio (PC)
1. Install Android Studio and Python 3 (needed by the build).
2. File > Open this folder, wait for Gradle sync.
3. Build > Build APK(s). The APK is in `app/build/outputs/apk/debug/`.

## Using the app (v2)
- **Home:** search or paste a link, site shortcuts, recent downloads, trending videos.
- **Watch:** browse by category (Trending, Music, Movies, Gaming, Funny, News, DIY) and search YouTube.
- **Quality list:** every video shows all its qualities (144p up to 2K / 4K when the video has them) and every audio stream (M4A and Opus, several bitrates), each with its file size. Most qualities are downloaded as separate video and sound and joined on the phone: H.264 + AAC becomes `.mp4`, and 1440p / 4K (VP9 + Opus) becomes `.webm`.
- **Downloads:** your library, with a built-in player (double-tap to skip 10s, speed, loop, fill, rotate, resume where you stopped, next/previous).
- **Settings:** default quality, copy to the Downloads folder, player options, theme, storage.
- **Share to the app:** in YouTube or Facebook, tap Share and pick Vidora. A copied link is also detected when you open the app.
Downloaded files are kept inside the app, and a copy is placed in **Downloads/Vidora** if that option is on.

## Engine
Settings > Engine shows the yt-dlp version in use and whether the video joiner is ready.

## Known limits
- Joining video and sound uses the phone's own media tools (H.264 + AAC, or VP9 + Opus). AV1-only qualities are not offered. MP3 is not offered because Android has no built-in MP3 encoder; audio is saved as M4A or Opus.
- If a download fails, the reason is shown on the download card with a **Try again** button.
- YouTube changes often. If it stops working, rebuild the APK to pick up the newest yt-dlp.
- Private or login-only videos don't work.
- Downloads keep running if you switch apps or lock the screen (a "Downloading" notification shows; allow notifications when asked). Swiping the app away from recent apps still stops them.
- Only download content you own or have permission to save. Downloading can break a platform's terms of service.
