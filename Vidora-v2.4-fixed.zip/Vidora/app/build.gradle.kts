plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.mydl.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mydl.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 5
        versionName = "2.4"
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    // ONE fixed signing key for every build. Before, each GitHub build made a new random debug key,
    // so Android refused to update the app: "package conflicts with an existing package".
    signingConfigs {
        create("vidora") {
            storeFile = file("vidora-debug.p12")
            storePassword = "vidora123"
            keyAlias = "vidora"
            keyPassword = "vidora123"
            storeType = "pkcs12"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("vidora")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

chaquopy {
    defaultConfig {
        version = "3.12"
        pip {
            install("flask")
            install("yt-dlp")
            install("requests")
        }
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.13.1")
}
