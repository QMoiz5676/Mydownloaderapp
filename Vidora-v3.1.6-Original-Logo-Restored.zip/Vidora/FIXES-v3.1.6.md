# Vidora v3.1.6

- Mini-player shows the selected video thumbnail while a new stream buffers, with a loading indicator over it.
- Mini-player title is at the top; full-screen control is centered; previous/play-next controls are at the bottom.
- Mini-player chrome is hidden by default and toggles on tapping the mini-player surface.
- Replaced the generic download glyph with a Vidora-branded vector mark.
- Added launcher icon safe margins to prevent cropping in adaptive launchers and installer surfaces.

Android build and device verification are still required.

## Additional thumbnail, mini-player and branding corrections

- Keep the current video's thumbnail visible in the floating mini-player while a new stream is loading; refresh the poster from the latest video-info response instead of retaining a stale feed thumbnail.
- Keep the mini-player title at the top, the full-screen action centered, and previous/play-next controls at the bottom. Tapping the video surface toggles the overlay controls and title.
- Replace the generic downward-arrow launcher artwork with a Vidora play-mark across Android launcher densities and the in-app header. Keep the adaptive-icon foreground inside Android's safe zone to prevent clipping in installer and home-screen masks.
