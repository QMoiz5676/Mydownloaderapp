# Vidora logo restoration

Restored the original Vidora logo artwork from the supplied project asset. The exact same PNG artwork is used for the WebView header and all Android launcher density assets (`ic_launcher.png` and `ic_launcher_foreground.png`). The adaptive icon keeps its dark background and uses the same foreground artwork.
