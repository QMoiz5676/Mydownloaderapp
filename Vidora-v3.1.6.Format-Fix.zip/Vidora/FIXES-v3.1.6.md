# Vidora v3.1.6 – Mini Player Layout and Logo Fixes

Mini player
- Thumbnail is shown while the next/previous video loads (no more black screen with a play-button picture).
- Title at the top, Full Screen button exactly in the centre, Previous / Play-Pause / Next at the bottom.
- Title and buttons hide automatically ~3 s after playback starts; tap the mini player to show them again (they stay visible while paused/loading).
- Dragging still works from anywhere; pointer capture starts only after a real drag so taps always reach the buttons.

Logo
- Launcher (adaptive) icon foreground re-made with the existing Vidora logo inside the safe zone, so the installer, home screen and app drawer no longer cut the sides.
- Notification/status-bar system "download" vector icon replaced by a Vidora logo silhouette (`ic_stat_vidora`) and the full logo as large icon.
- Home header logo is a transparent PNG (no clipped corners); the Home hero "V" vector mark is replaced by the Vidora logo.

Follow-up fixes
- Mini player Full Screen button now just expands back to the normal player (no forced landscape full screen).
- "This video format is not supported by this device": the play() rejection now uses the same fallback chain as the error event (fresh-link retry, then up to 3 automatic quality step-downs).
- Server: combined files prefer H.264; for videos with no H.264 stream at all, a VP9/WebM video-only stream is offered as a last resort instead of failing.
